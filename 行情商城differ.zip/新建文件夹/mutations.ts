import { exportFile } from '@/utils'
import { BASE_URL } from '@/utils/request/config'

import { authorizedCommonJavaInst } from '../common-java-instance'
import { IJavaAPICommonResponse, IListAPIParams } from '../types'

export interface IBuyQuotationParams {
  amount: number
  customerId: number
  enableStart?: string
  /**
   * 期望生效时间类型[0:当前生效;1:下月生效]
   */
  enableStartType: number
  isGive: boolean
  packageId: string
  tradeAccount: string
  deductTimeType?: 'NOW' | 'MONTH_END' | 'NO'
}

export function buyQuotation(params: IBuyQuotationParams): Promise<IJavaAPICommonResponse> {
  return authorizedCommonJavaInst.post<IJavaAPICommonResponse>('/quotation/order/buy', params)
}

export interface IModifyQuotationOrderParams {
  orderId: string
  packageId: string
  chargeType: NonNullable<IBuyQuotationParams['deductTimeType']>
}

export function modifyQuotationOrder(params: IModifyQuotationOrderParams) {
  return authorizedCommonJavaInst.post<IJavaAPICommonResponse>('/quotation/order/modify', params)
}

export interface IReviewQuotationOrderParams {
  isPass: boolean
  orderId: string
  remark: string
}

export function reviewQuotationOrder(
  params: IReviewQuotationOrderParams
): Promise<IJavaAPICommonResponse> {
  return authorizedCommonJavaInst.post<IJavaAPICommonResponse>('/quotation/order/review', params)
}

export interface IExchangeQuotationParams {
  customerId: number
  tradeAccount: string
  oldOrderId: string
  newPackageId: string
  remark: string
  subType?: number
  userId?: number
}

export function applyQuotationExchange(params: IExchangeQuotationParams) {
  return authorizedCommonJavaInst.post<IJavaAPICommonResponse>(
    '/quotation/order/exchange/apply',
    params
  )
}

export function reviewQuotationExchange(params: IReviewQuotationOrderParams) {
  return authorizedCommonJavaInst.post<IJavaAPICommonResponse>(
    '/quotation/order/exchange/review',
    params
  )
}

export interface IReviewQuotationPackageParams {
  packageId: string
  isPass: boolean
  remark: string
}

export function reviewQuotationPackage(params: IReviewQuotationPackageParams) {
  return authorizedCommonJavaInst.post('/quotation/package/review', params)
}

export interface IChangeQuotationAutoRenewParams {
  autoRenew: boolean
  packageId: string
  tradeAccount: string
}

export function changeQuotationAutoRenew(params: IChangeQuotationAutoRenewParams) {
  return authorizedCommonJavaInst.post('/quotation/customer/switch/autoRenew', params)
}

export function fetchKycUpdateRecords(params: IListAPIParams) {
  return authorizedCommonJavaInst.post<IJavaAPICommonResponse>('/quotation/kyc/page', params)
}

export function fetchKycUpdateList(params: IListAPIParams & { id: string }) {
  return authorizedCommonJavaInst.post<IJavaAPICommonResponse>('/quotation/kyc/update/list', params)
}

export function fetchKycUrlByCos(
  params: IListAPIParams & { tradeAccount: string },
  filename: string
) {
  return exportFile(BASE_URL, '/quotation/kyc/getKycUrlByCos', params, filename)
}
