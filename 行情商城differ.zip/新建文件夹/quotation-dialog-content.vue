<template>
  <div>
    <div class="dialog-content">
      <el-alert
        v-if="operationType === OperationType.Modify && initFormValues?.staticFields.reviewRemark"
        :title="`${$t('order_reject_reason')}：${initFormValues.staticFields.reviewRemark}`"
        type="warning"
        :closable="false"
        class="review-remark"
      />
      <el-form
        ref="formRef"
        :validate-on-rule-change="false"
        :model="form"
        :rules="activeFormRules"
        label-position="right"
        label-width="auto"
        class="order-stream-quotes-form"
        :disabled="!canEditOrder"
      >
        <el-form-item :label="`${$t('internet_account')}：`">
          <el-select-v2
            v-if="operationType === OperationType.Add"
            ref="internetAccountSelectRef"
            v-model="selectedInternetAccount"
            filterable
            remote
            :remote-method="searchInternetAccount"
            clearable
            :options="internetAccountOptions"
            :loading="isSearchingInternetAccount"
            :placeholder="$t('please_enter_internet_account_or_mobile')"
            @visible-change="onInternetAccountSelectVisibleChange"
            @focus="syncInternetAccountInputMaxLength"
          />
          <div v-else class="content">{{ displayValue(cusNo) }}</div>
        </el-form-item>

        <el-form-item :label="`${$t('trading_account')}：`" prop="tradeAccount">
          <el-select
            v-model="form.tradeAccount"
            :disabled="operationType !== OperationType.Add"
            filterable
            :remote="!selectedInternetAccount"
            :remote-method="onTradeAccountSearch"
            :loading="isSearchingTradeAccount && tradeAccountOptions.length === 0"
            popper-class="trade-account-popper"
            class="m-2"
            :placeholder="operationType === OperationType.Add ? $t('trading_account') : '--'"
          >
            <el-option
              v-for="item in tradeAccountOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
              :disabled="isSearchingTradeAccount"
            />
            <template #loading>
              <div
                class="trade-account-loading"
                role="status"
                :aria-label="$t('searching_trade_accounts')"
              >
                <el-icon class="is-loading" :size="20"><Loading /></el-icon>
              </div>
            </template>
            <template v-if="isSearchingTradeAccount && tradeAccountOptions.length > 0" #footer>
              <div
                class="trade-account-loading trade-account-loading-mask"
                role="status"
                :aria-label="$t('searching_trade_accounts')"
              >
                <el-icon class="is-loading" :size="20"><Loading /></el-icon>
              </div>
            </template>
            <template #empty>
              <div class="trade-account-empty">
                <div>{{ $t('no_matching_trade_accounts') }}</div>
                <div class="trade-account-empty-tip">
                  {{ $t('try_another_trade_account_keyword') }}
                </div>
              </div>
            </template>
          </el-select>
        </el-form-item>

        <el-form-item :label="`${$t('mobile_number')}：`">
          <div class="content">{{ displayValue(mobile) }}</div>
        </el-form-item>

        <el-form-item :label="`${$t('package_selection')}：`" prop="packageId">
          <el-select
            v-model="form.packageId"
            :disabled="packagesOptions.length === 0 || !canEditOrder"
            class="m-2"
            :placeholder="operationType === OperationType.Add ? $t('package_selection') : '--'"
          >
            <el-option
              v-for="item in packagesOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>

        <div
          v-if="selectedPackage?.packageId || operationType !== OperationType.Add"
          class="full-width-block"
        >
          <el-descriptions border :column="3">
            <el-descriptions-item :label="$t('package_product')">
              {{ displayValue(selectedPackage?.productName) }}
            </el-descriptions-item>
            <el-descriptions-item :label="$t('market_uses_area')">
              {{ displayValue(selectedPackage?.regionName) }}
            </el-descriptions-item>
            <el-descriptions-item :label="$t('market_uses_terminal')">
              {{ displayValue(selectedPackage?.terminalName) }}
            </el-descriptions-item>
            <el-descriptions-item :label="$t('package_price')">
              {{ packagePriceLabel }}
            </el-descriptions-item>
            <el-descriptions-item :label="$t('effective_date')">
              {{ packageEffectiveDateLabel }}
            </el-descriptions-item>
            <el-descriptions-item>--</el-descriptions-item>
          </el-descriptions>
        </div>

        <el-form-item :label="`${$t('amount_payable')}（${currency}）：`">
          <div class="content">
            {{ displayValue(shouldPayStr) }}
          </div>
        </el-form-item>

        <el-form-item :label="`${$t('expected_deduction_time')}：`" prop="deductTimeType">
          <el-select
            v-if="canEditOrder"
            v-model="selectedDeductionType"
            :disabled="!selectedPackage"
            class="m-2"
            :placeholder="$t('please_select_deduction_time')"
          >
            <el-option
              v-for="item in deductionTypeOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-input v-else disabled :model-value="deductionTypeLabel" />
        </el-form-item>

        <el-form-item :label="`${$t('amount_paid')}（${currency}）：`" prop="amount">
          <el-input v-if="form.isGive" value="0" disabled />
          <el-input
            v-else-if="operationType !== OperationType.Add"
            :model-value="displayValue(form.amount)"
            disabled
          />
          <el-input
            v-else
            v-model="form.amount"
            :placeholder="$t('please_enter_amount_paid')"
            :disabled="!canEditPayMoney"
          />
        </el-form-item>
      </el-form>

      <div v-if="modifyRecords.length" class="modify-records">
        <div class="modify-records-title">{{ $t('order_modify_records') }}：</div>
        <el-table :data="modifyRecords" border class="modify-records-table">
          <el-table-column prop="field" :label="$t('order_modify_field')" />
          <el-table-column prop="before" :label="$t('order_modify_before')" />
          <el-table-column prop="after" :label="$t('order_modify_after')" />
        </el-table>
      </div>

      <el-card v-if="operationType === OperationType.Audit" shadow="never" style="margin-top: 15px">
        <el-form ref="auditFormRef" :model="auditForm" :rules="auditFormRules" label-width="auto">
          <el-form-item
            prop="isPass"
            :label="$t('audit_status') + ':'"
            :rules="[{ required: true, message: $t('audit_status') }]"
          >
            <el-radio-group v-model="auditForm.isPass">
              <el-radio :label="true">{{ $t('audit_approve') }}</el-radio>
              <el-radio :label="false">{{ $t('audit_reject') }} </el-radio>
            </el-radio-group>
          </el-form-item>

          <el-form-item prop="remark" :label="$t('audit_reason') + ':'">
            <el-input
              v-model="auditForm.remark"
              type="textarea"
              :autosize="{ minRows: 2, maxRows: 4 }"
              maxlength="100"
            />
          </el-form-item>
        </el-form>
      </el-card>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { reactive, ref, watch, computed, nextTick, onMounted, onBeforeUnmount } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Loading } from '@element-plus/icons-vue'
import { OperationType } from '@/utils/const'
import { SelectOption, SelectOptions } from '@/types'
import {
  fetchCustomerListWithTradeAccount,
  ICustomerListItemWithTradeAccount,
} from '@/api-v2/nuc/query'
import {
  fetchCustomerQuotationTradeAccountList,
  fetchPackageOptions,
  IPackageOptionItem,
} from '@/api-v2/quotation/query'
import { cloneDeep, debounce, isNil } from 'lodash'
import {
  buyQuotation,
  IBuyQuotationParams,
  modifyQuotationOrder,
  reviewQuotationOrder,
  reviewQuotationExchange,
} from '@/api-v2/quotation/mutations'

export interface IInitFormValues {
  form: Omit<IBuyStreamQuotationForm, 'enableStartType'>
  staticFields: {
    cusNo: string
    mobile: string
    tbcAmount: number
    orderId?: string
    isExchange?: boolean
    reviewRemark?: string
    modifyRecord?: unknown
  }
  packages: IPackageOptionItem[]
}

const props = defineProps<{
  initFormValues?: IInitFormValues
  operationType: OperationType
}>()

const emit = defineEmits<{
  (e: 'close', success: boolean): void
}>()

const { t } = useI18n()
const isSubmitting = ref(false)
const cusNo = ref(props.initFormValues?.staticFields?.cusNo || '')
const operationType = ref<OperationType>(props.operationType || OperationType.Add)
const canEditOrder = computed(
  () => operationType.value === OperationType.Add || operationType.value === OperationType.Modify
)
const modifyRecords = computed(() => {
  let records = props.initFormValues?.staticFields.modifyRecord
  if (typeof records === 'string') {
    try {
      records = JSON.parse(records)
    } catch {
      return []
    }
  }
  if (!Array.isArray(records)) return []
  return records.filter((record) => record && typeof record === 'object' && 'field' in record)
})
// eslint-disable-next-line vue/no-setup-props-destructure
const defaultTradeAccount = props.initFormValues?.form.tradeAccount
const defaultAccountOptions = defaultTradeAccount
  ? [
      {
        label: defaultTradeAccount,
        value: defaultTradeAccount,
      },
    ]
  : []
const tradeAccountOptions = ref<SelectOptions>(defaultAccountOptions)
const mobile = ref(props.initFormValues?.staticFields?.mobile || '')
const orderId = ref<string>(props.initFormValues?.staticFields?.orderId || '')

type IBuyStreamQuotationForm = Omit<IBuyQuotationParams, 'amount' | 'customerId'> & {
  amount: string | number
  customerId: number | undefined
}

function getDefaultForm(): IBuyStreamQuotationForm {
  if (props.initFormValues) {
    const initialForm = props.initFormValues.form
    // 兼容历史赠送订单，以及使用 NO 标识赠送的新订单。
    const isGive = initialForm.isGive === true || initialForm.deductTimeType === 'NO'
    return {
      ...initialForm,
      isGive,
      deductTimeType: isGive ? 'NO' : initialForm.deductTimeType,
      enableStartType: 0,
    }
  }

  return {
    amount: '',
    customerId: undefined,
    enableStartType: 0,
    isGive: false,
    packageId: '',
    tradeAccount: '',
    deductTimeType: undefined,
  }
}

const form = reactive<IBuyStreamQuotationForm>(getDefaultForm())
const selectedDeductionType = computed<IBuyStreamQuotationForm['deductTimeType']>({
  get: () => form.deductTimeType,
  set: (value) => {
    form.deductTimeType = value
    form.isGive = value === 'NO'
  },
})
const auditForm = reactive({
  isPass: true,
  remark: '',
})
const selectedPackage = computed(() => {
  return packages.value.find((item) => item.packageId === form.packageId)
})

function displayValue(value: string | number | null | undefined) {
  return isNil(value) || (typeof value === 'string' && value.trim() === '') ? '--' : value
}

const packagePriceLabel = computed(() => {
  const price = displayValue(selectedPackage.value?.price)
  if (price === '--') return '--'

  return `${price} ${displayValue(selectedPackage.value?.currency)}/${t('month')}`
})

const packageEffectiveDateLabel = computed(() => {
  const start = displayValue(selectedPackage.value?.enableStart)
  const end = displayValue(selectedPackage.value?.enableEnd)
  return start === '--' && end === '--' ? '--' : `${start}~${end}`
})

const currency = computed(() => selectedPackage.value?.currency || 'HKD')

const canEditPayMoney = computed(() => {
  return operationType.value === OperationType.Add && !form.isGive && !!selectedPackage.value
})

const packages = ref<IPackageOptionItem[]>([])
const deductionTypeOptions = computed(() => [
  { label: t('current_deduction'), value: 'NOW' },
  { label: t('end_month_deduction'), value: 'MONTH_END' },
  { label: t('presented'), value: 'NO' },
])

const deductionTypeLabel = computed(() => {
  return (
    deductionTypeOptions.value.find((item) => item.value === form.deductTimeType)?.label || '--'
  )
})

// 切换或清空套餐时重置收费方式，由用户手动选择。
watch(
  selectedPackage,
  () => {
    if (operationType.value === OperationType.Add) {
      selectedDeductionType.value = undefined
    }
  },
  { immediate: true }
)

const packagesOptions = computed(() => {
  const arr = packages.value.map((item) => ({
    label: displayValue(item.packageName),
    value: item.packageId,
  }))

  return arr
})

const formRef = ref()
const auditFormRef = ref()
const formRules = {
  tradeAccount: {
    required: true,
    trigger: 'change',
    message: `${t('please_select')}${t('trading_account')}`,
  },
  packageId: {
    required: true,
    trigger: 'change',
    message: `${t('please_select')}${t('package')}`,
  },
  amount: [
    {
      required: true,
      trigger: 'change',
      validator: (_rule: object, value: string, callback: any) => {
        if (form.isGive) {
          return callback()
        }

        if (!value) {
          return new Error(t('please_enter_amount_paid'))
        }

        const valueStr = String(value).trim()

        // 检查金额格式是否正确：不能有连续的小数点、多个小数点等
        if (valueStr.includes('..') || valueStr.split('.').length > 2) {
          return callback(new Error(t('amount_format_incorrect')))
        }

        const num = Number(valueStr)
        if (isNaN(num)) {
          return callback(new Error(t('amount_format_incorrect')))
        }

        if (num < 0 || valueStr.startsWith('-')) {
          return callback(new Error(t('amount_cannot_be_negative')))
        }

        const decimalIndex = valueStr.indexOf('.')
        if (decimalIndex !== -1 && valueStr.length - decimalIndex - 1 > 3) {
          return callback(new Error(t('amount_decimal_places_exceeded')))
        }

        const shouldPay = selectedPackage.value?.price
        if (isNil(shouldPay)) {
          return callback()
        }

        if (num > shouldPay) {
          return callback(new Error(t('amount_paid_exceed_amount_payable')))
        }
        return callback()
      },
    },
  ],
  deductTimeType: [
    {
      required: true,
      trigger: 'change',
      message: `${t('please_select')}${t('expected_deduction_time')}`,
    },
  ],
}

const auditFormRules = {
  isPass: {
    required: true,
    trigger: 'change',
    message: `${t('please_select')}${t('trading_account')}`,
  },
}

const activeFormRules = computed(() => {
  if (operationType.value === OperationType.Modify) {
    return {
      packageId: formRules.packageId,
      deductTimeType: formRules.deductTimeType,
    }
  }
  if (operationType.value === OperationType.Add) {
    return formRules
  }

  return {}
})

const INTERNET_ACCOUNT_SEARCH_MAX_LEN = 50

const internetAccountSelectRef = ref<{ $el?: HTMLElement } | null>(null)
const selectedInternetAccount = ref<number>()
const internetAccountOptions = ref<(SelectOption & { raw: ICustomerListItemWithTradeAccount })[]>(
  []
)
const isSearchingInternetAccount = ref(false)

function syncInternetAccountInputMaxLength() {
  nextTick(() => {
    const root = internetAccountSelectRef.value?.$el
    const input = root?.querySelector?.('input')
    if (input) {
      input.maxLength = INTERNET_ACCOUNT_SEARCH_MAX_LEN
    }
  })
}

function onInternetAccountSelectVisibleChange(visible: boolean) {
  if (visible) {
    syncInternetAccountInputMaxLength()
  }
}

onMounted(() => {
  syncInternetAccountInputMaxLength()
})

const isSearchingTradeAccount = ref(false)
let tradeAccountSearchId = 0
let lastTradeAccountSearchKeyword: string | null = ''
const debouncedSearchTradeAccount = debounce(searchTradeAccount, 300)

function onTradeAccountSearch(keyword: string) {
  if (operationType.value !== OperationType.Add || selectedInternetAccount.value) return
  if (keyword === lastTradeAccountSearchKeyword) return

  // 展开下拉框也会触发远程搜索，关键词未变化时复用当前结果。
  lastTradeAccountSearchKeyword = keyword
  // 输入变化时立即使旧请求失效，避免防抖等待期间被过期响应覆盖。
  tradeAccountSearchId++
  isSearchingTradeAccount.value = true
  debouncedSearchTradeAccount(keyword)
}

onBeforeUnmount(() => {
  debouncedSearchTradeAccount.cancel()
  tradeAccountSearchId++
})

async function searchTradeAccount(keyword = '') {
  if (operationType.value !== OperationType.Add || selectedInternetAccount.value) return

  lastTradeAccountSearchKeyword = keyword
  const searchId = ++tradeAccountSearchId
  isSearchingTradeAccount.value = true

  try {
    const res = await fetchCustomerQuotationTradeAccountList({
      pageNum: 1,
      pageSize: 1000,
      tradeAccount: keyword,
    })
    if (searchId !== tradeAccountSearchId) return

    const uniqueTradeAccounts = Array.from(
      new Set(res.result.records.map((item) => item.tradeAccount))
    )

    tradeAccountOptions.value = uniqueTradeAccounts.map((item) => ({
      label: item,
      value: item,
    }))
  } catch (error) {
    if (searchId === tradeAccountSearchId) {
      lastTradeAccountSearchKeyword = null
      tradeAccountOptions.value = []
      console.error('获取交易账户失败', error)
    }
  } finally {
    if (searchId === tradeAccountSearchId) {
      isSearchingTradeAccount.value = false
    }
  }
}

const searchInternetAccount = (query: string) => {
  const keyword = query.slice(0, INTERNET_ACCOUNT_SEARCH_MAX_LEN)

  if (keyword !== '') {
    isSearchingInternetAccount.value = true

    fetchCustomerListWithTradeAccount({ keyword })
      .then((res) => {
        internetAccountOptions.value = res.result.map((item: any) => ({
          label: item.cusNo,
          value: item.id,
          raw: item,
        }))
      })
      .finally(() => {
        isSearchingInternetAccount.value = false
      })
  } else {
    internetAccountOptions.value = []
  }
}

function getSubmitParams() {
  const params = cloneDeep(form)

  if (params.isGive) {
    params.amount = 0
  }

  return params as IBuyQuotationParams
}

watch(selectedInternetAccount, (newVal: number | undefined) => {
  if (operationType.value !== OperationType.Add) return

  // 切换客户后忽略未完成的全量交易账户搜索。
  debouncedSearchTradeAccount.cancel()
  tradeAccountSearchId++
  lastTradeAccountSearchKeyword = ''
  isSearchingTradeAccount.value = false
  tradeAccountOptions.value = []

  // 重置相关字段
  form.tradeAccount = ''
  packages.value = []
  form.packageId = ''

  // 如果清空选择，重置客户相关字段
  if (!newVal) {
    form.customerId = undefined
    cusNo.value = ''
    mobile.value = ''
    searchTradeAccount()
    return
  }

  const item = internetAccountOptions.value?.find((item: any) => item.value === newVal)
  if (item) {
    const raw = item.raw
    form.customerId = raw.id
    cusNo.value = `${raw.cusNo}`
    mobile.value = raw.mobile

    const tradeAccounts = raw.tradeAccounts

    if (!tradeAccounts?.length) {
      ElMessageBox.alert(t('notradeAccount'), t('tip'), {
        confirmButtonText: t('determine'),
        type: 'error',
      })
      tradeAccountOptions.value = []
      return
    }

    tradeAccountOptions.value = tradeAccounts.map((item: any) => ({
      label: item,
      value: item,
    }))
    return
  }

  form.customerId = undefined
  cusNo.value = ''
  mobile.value = ''
  searchTradeAccount()
})

// 监听选中的交易账户和变化
watch(
  () => form.tradeAccount,
  (newVal: string) => {
    if (operationType.value !== OperationType.Add) return

    if (!newVal) return
    packages.value = []
    form.packageId = ''

    fetchPackageOptions(2, newVal)
      .then((res) => {
        packages.value = res.result
      })
      .catch((error) => {
        console.error('获取行情套餐失败', error)
        packages.value = []
      })
  }
)

// 选择或切换套餐时，实付金额默认填入应付金额；清空套餐时同步清空。
watch(selectedPackage, (newPackage) => {
  if (operationType.value !== OperationType.Add) return

  form.amount = isNil(newPackage?.price) ? '' : String(newPackage.price)
})

watch(
  () => form.isGive,
  (newVal) => {
    if (!canEditOrder.value) return

    if (newVal) {
      formRef.value?.clearValidate(['amount'])
    }
  }
)

function close(success: boolean) {
  emit('close', success)
}

// 弹窗确认
function confirm() {
  if (isSubmitting.value) return

  if (operationType.value === OperationType.Modify) {
    formRef.value.validate((validate: boolean) => {
      if (!validate || !form.deductTimeType) return

      isSubmitting.value = true
      modifyQuotationOrder({
        orderId: orderId.value,
        packageId: form.packageId,
        chargeType: form.deductTimeType,
      })
        .then(() => {
          close(true)
          ElMessage.success(t('modify_success'))
        })
        .catch((error) => {
          console.error('修改订购失败', error)
        })
        .finally(() => {
          isSubmitting.value = false
        })
    })
    return
  }

  if (operationType.value === OperationType.Add) {
    formRef.value.validate((validate: boolean) => {
      if (!validate) {
        return
      }
      ElMessageBox.confirm(t('isConfirm_toke_node'), {
        confirmButtonText: t('determine'),
        cancelButtonText: t('cancel'),
      })
        .then(() => {
          const params = getSubmitParams()
          isSubmitting.value = true

          buyQuotation(params)
            .then(() => {
              close(true)
              ElMessage.success(t('order_quotation_success'))
            })
            .catch((error) => {
              console.error('新增订购失败', error)
            })
            .finally(() => {
              isSubmitting.value = false
            })
        })
        .catch(() => {
          // prevent promise error popup in development mode
          return
        })
    })

    return
  }

  if (operationType.value === OperationType.Audit) {
    auditFormRef.value.validate((validate: boolean) => {
      if (!validate) {
        return
      }
      ElMessageBox.confirm(t('is_confirm_audit'), {
        confirmButtonText: t('determine'),
        cancelButtonText: t('cancel'),
      })
        .then(() => {
          // const params = getSubmitParams()
          const params: Parameters<typeof reviewQuotationOrder>[0] = {
            orderId: orderId.value as string,
            isPass: auditForm.isPass,
            remark: auditForm.remark,
          }

          isSubmitting.value = true

          const review = props.initFormValues?.staticFields.isExchange
            ? reviewQuotationExchange
            : reviewQuotationOrder

          review(params)
            .then(() => {
              close(true)
              ElMessage.success(t('audit_success'))
            })
            .catch((error) => {
              console.error('确认审核失败', error)
            })
            .finally(() => {
              isSubmitting.value = false
            })
        })
        .catch(() => {
          // prevent promise error popup in development mode
          return
        })
    })

    return
  }
}

const shouldPayStr = computed(() => {
  if (
    operationType.value === OperationType.Add ||
    (operationType.value === OperationType.Modify &&
      form.packageId !== props.initFormValues?.form.packageId)
  ) {
    return selectedPackage.value?.price
  }

  return props.initFormValues?.staticFields.tbcAmount
})

// 监听 initFormValues?.packages，当操作类型不等于新增时，如果有数据则复制给 packages
watch(
  () => props.initFormValues?.packages,
  (newPackages) => {
    if (operationType.value !== OperationType.Add && newPackages && newPackages.length > 0) {
      packages.value = cloneDeep(newPackages)
    }
  },
  { immediate: true }
)

if (operationType.value === OperationType.Add) {
  searchTradeAccount()
}

defineExpose({ submit: confirm, isSubmitting })
</script>

<style lang="scss" scoped>
.review-remark {
  margin-bottom: 18px;
}

.modify-records {
  margin-top: 18px;
  padding: 16px;
}

.modify-records-title {
  margin-bottom: 12px;
  font-size: 14px;
  font-weight: 600;
}

.modify-records-table {
  font-size: var(--el-font-size-base);
}

.trade-account-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 8px 0;
  color: var(--el-color-primary);
}

.trade-account-loading-mask {
  position: absolute;
  z-index: 1;
  inset: 0;
  border-radius: var(--el-border-radius-base);
  background: rgb(255 255 255 / 65%);
}

.trade-account-empty {
  padding: 8px 16px;
  text-align: center;
}

.trade-account-empty-tip {
  margin-top: 6px;
  color: var(--el-text-color-secondary);
  font-size: 12px;
}

.footer {
  display: flex;
  justify-content: center;
}

$common-padding: 16px;
.dialog-content {
  padding-left: $common-padding;
}

.full-width-block {
  width: 100%;
  margin-bottom: 15px;
  padding-right: $common-padding;
}

.order-stream-quotes-form {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  row-gap: 18px;
  margin-bottom: 0;
  padding: 0 10px;

  :deep(.el-form-item) {
    width: 50%;
    margin-bottom: 0;
    padding-right: $common-padding;
  }

  :deep(.el-form-item__label) {
    font-weight: 600;
  }

  > :deep(.el-form-item:nth-of-type(even) .el-form-item__label) {
    width: 128px !important;
    justify-content: flex-end;
    white-space: nowrap;
  }

  :deep(.el-select),
  :deep(.el-input-number),
  :deep(.el-input) {
    width: 100% !important;
  }
}
</style>

<style lang="scss">
.trade-account-popper {
  .el-select-dropdown {
    position: relative;
  }

  /* stylelint-disable-next-line selector-class-pattern */
  .el-select-dropdown__footer {
    padding: 0;
    border: 0;
  }
}
</style>
