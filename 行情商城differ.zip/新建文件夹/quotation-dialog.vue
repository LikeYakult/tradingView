<template>
  <el-dialog
    v-model="dialogTableVisible"
    :close-on-click-modal="false"
    :title="title"
    width="880px"
    center
    class="dialog"
    destroy-on-close
  >
    <quotationDialogContent
      ref="contentRef"
      :="$props"
      :operation-type="operationType"
      @close="handleClose"
    />
    <template #footer>
      <CustomDialogFooter>
        <el-button
          v-if="operationType !== OperationType.Detail"
          type="primary"
          :loading="contentRef?.isSubmitting"
          @click="contentRef?.submit()"
        >
          {{ $t('determine') }}
        </el-button>
        <el-button @click="handleClose(false)">
          {{ $t(operationType === OperationType.Detail ? 'close' : 'cancel') }}
        </el-button>
      </CustomDialogFooter>
    </template>
  </el-dialog>
</template>

<script lang="ts" setup>
import { computed, ref } from 'vue'
import quotationDialogContent, { IInitFormValues } from './quotation-dialog-content.vue'
import CustomDialogFooter from '@/components/custom-dialog-footer.vue'
import { OperationType } from '@/utils/const'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()
const operationType = ref<OperationType>(OperationType.Add)
const contentRef = ref<InstanceType<typeof quotationDialogContent>>()

const title = computed(() => {
  if (operationType.value === OperationType.Add) {
    return t('order_stream_quotes')
  }

  if (operationType.value === OperationType.Audit) {
    return t('audit_order')
  }

  if (operationType.value === OperationType.Modify) {
    return t('modify')
  }

  return t('details')
})

defineProps<{
  initFormValues?: IInitFormValues
}>()

const emit = defineEmits<{
  (e: 'callback'): void
}>()

const dialogTableVisible = ref(false)

function open(op: OperationType) {
  operationType.value = op
  dialogTableVisible.value = true
}

function handleClose(success: boolean) {
  dialogTableVisible.value = false

  if (success) {
    emit('callback')
  }
}

defineExpose({
  open,
})
</script>
