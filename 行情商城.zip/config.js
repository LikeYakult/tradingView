window.BASE_URL = 'http://10.10.11.148:6003/'

window.APP_CONFIG = {
  title: '国际行情商城管理平台',
  login_title_cn: '',
  login_title_hk: '',
  login_title_en: '',
  COMMON_SERVERS: {
    base: 'http://10.10.11.148:6003' // 中信-开发
  },
  LANGUAGE_LIST: [
    ['zh-CN', '简体'],
    ['zh-TW', '繁体'],
    ['en-US', 'English']
  ],
  subModuleList: {}
}
