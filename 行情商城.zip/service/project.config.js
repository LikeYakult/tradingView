'use strict'

module.exports = {
  outputDir: 'dist',

  dev: {
    publicPath: '/',
    port: 11107,
  },

  build: {
    publicPath: '/dms/quotation-subscription/',
  },
}
