const crypto = require('crypto')

const granularChunks = (options) => {
  const { frameworkBundles = [] } = options || {}

  const FRAMEWORK_BUNDLES = [
    // React Series
    'vue',
    'vue-router',
    'vuex',
    'vue-i18n',
    'element-plus',
    'axios',
    'classnames',
    //
    'lodash',
    'dayjs',
    ...frameworkBundles
  ]

  return {
    chunks: 'all',
    name: 'vendor',
    minChunks: 2,
    cacheGroups: {
      default: false,
      defaultVendors: false,
      framework: {
        name: 'framework',
        chunks: 'all',
        test: new RegExp(`[\\\\/]node_modules[\\\\/](${FRAMEWORK_BUNDLES.join(`|`)})[\\\\/]`),
        priority: 40,
        enforce: true
      },
      lib: {
        test(module) {
          return (
            !isModuleCSS(module) &&
            module.size() > 160000 &&
            /node_modules[/\\]/.test(module.identifier())
          )
        },
        name(module) {
          const rawRequest = module.rawRequest && module.rawRequest.replace(/^@(\w+)[/\\]/, '$1-')
          if (rawRequest) {
            return `${
              // when `require()` a package with relative path,
              // need remove leading `.` and `/`, otherwise will not found `.js` file
              // e.g. require('../../lib/codemirror')
              rawRequest.replace(/\./g, '_').replace(/\//g, '-')
            }-lib`
          }

          const identifier = module.identifier()
          const trimmedIdentifier = /(?:^|[/\\])node_modules[/\\](.*)/.exec(identifier)
          const processedIdentifier = trimmedIdentifier?.[1].replace(/^@(\w+)[/\\]/, '$1-')

          return `${processedIdentifier || identifier}-lib`
        },
        priority: 30,
        minChunks: 1,
        reuseExistingChunk: true,
        chunks: 'async'
      },
      shared: {
        name(_module, chunks) {
          const cryptoName = crypto
            .createHash('sha1')
            .update(
              chunks.reduce((acc, chunk) => {
                return acc + chunk.name
              }, '')
            )
            .digest('base64')
            .replace(/\//g, '')
            .replace(/\+/g, '-')
            .replace(/=/g, '_')
          return `shared-${cryptoName}`
        },
        priority: 10,
        minChunks: 2,
        reuseExistingChunk: true,
        chunks: 'async'
      }
    }
  }
}

function isModuleCSS(module) {
  return (
    // mini-css-extract-plugin
    module.type === `css/mini-extract` ||
    // extract-css-chunks-webpack-plugin (old)
    module.type === `css/extract-chunks` ||
    // extract-css-chunks-webpack-plugin (new)
    module.type === `css/extract-css-chunks`
  )
}

module.exports = {
  granularChunks,
}
