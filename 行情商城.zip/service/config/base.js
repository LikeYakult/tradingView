'use strict'

const { DefinePlugin } = require('webpack')
const { VueLoaderPlugin } = require('vue-loader')
const CaseSensitivePathsPlugin = require('case-sensitive-paths-webpack-plugin')
const ESLintPlugin = require('eslint-webpack-plugin')
const HTMLPlugin = require('html-webpack-plugin')
const CopyPlugin = require('copy-webpack-plugin')
// const SVGSpritePlugin = require('svg-sprite-loader/plugin')

const resolveClientEnv = require('../utils/resolveClientEnv')
const paths = require('../utils/paths')
const pkg = require('../../package.json')

const config = require('../project.config')
const isProd = process.env.NODE_ENV === 'production'
const outputFileName = `js/[name]${isProd ? '.[contenthash:8]' : ''}.js`

const publicPath = isProd ? config.build.publicPath : config.dev.publicPath

module.exports = {
  context: process.cwd(),

  entry: {
    app: './src/main.ts',
  },

  output: {
    path: paths.resolve(config.outputDir),
    publicPath: publicPath,
    filename: outputFileName,
    chunkFilename: outputFileName,
    library: {
      name: `${pkg.name}-[name]`,
      type: 'umd',
    },
    uniqueName: `webpackJsonp_${pkg.name}`,
  },

  resolve: {
    alias: {
      '@': paths.resolve('src'),
    },
    extensions: ['.ts', '.tsx', '.js', '.jsx', '.vue', '.json'],
  },

  plugins: [
    // new ESLintPlugin({
    //   emitError: true,
    //   emitWarning: true,
    //   extensions: ['.ts', '.tsx', '.js', '.jsx', '.vue'],
    //   formatter: require('eslint-formatter-friendly'),
    // }),
    new VueLoaderPlugin(),
    new CaseSensitivePathsPlugin(),
    new HTMLPlugin({
      template: paths.resolve('public/index.html'),
      templateParameters: {
        version: process.env.BUILD_VERSION || pkg.version,
        publicPath: publicPath,
      },
    }),
    // new SVGSpritePlugin(),
    new CopyPlugin({
      patterns: [
        {
          from: paths.resolve('public'),
          toType: 'dir',
          globOptions: {
            ignore: ['.DS_Store', '**/index.html'],
          },
          noErrorOnMissing: true,
        },
        {
          from: 'config.js',
          to: 'config.js',
        },
      ],
    }),
    new DefinePlugin({
      // vue3 feature flags <http://link.vuejs.org/feature-flags>
      __VUE_OPTIONS_API__: 'true',
      __VUE_PROD_DEVTOOLS__: 'false',
      __VUE_PROD_HYDRATION_MISMATCH_DETAILS__: 'false',

      ...resolveClientEnv({
        publicPath: publicPath,
      }),
    }),
  ],

  module: {
    noParse: /^(vue|vue-router|vuex|vuex-router-sync)$/,

    rules: [
      {
        test: /\.vue$/,
        loader: 'vue-loader',
      },
      {
        test: /\.m?js/,
        resolve: {
          fullySpecified: false,
        },
      },
      // babel
      {
        test: /\.m?jsx?$/,
        exclude: (file) => {
          // always transpile js in vue files
          if (/\.vue\.jsx?$/.test(file)) {
            return false
          }
          // Don't transpile node_modules
          return /node_modules/.test(file)
        },
        use: ['thread-loader', 'babel-loader'],
      },

      // ts
      {
        test: /\.tsx?$/,
        use: [
          'thread-loader',
          'babel-loader',
          {
            loader: 'ts-loader',
            options: {
              transpileOnly: true,
              appendTsSuffixTo: ['\\.vue$'],
              happyPackMode: true,
            },
          },
        ],
      },

      // images
      {
        test: /\.(png|jpe?g|gif|webp)(\?.*)?$/,
        type: 'asset',
        generator: { filename: 'img/[contenthash:8][ext][query]' },
      },

      // do not base64-inline SVGs.
      // https://github.com/facebookincubator/create-react-app/pull/1180
      // {
      //   test: /\.svg$/,
      //   loader: 'svg-sprite-loader',
      //   include: [paths.resolve('src/svg-icons')],
      //   options: {
      //     symbolId: 'svg-icon-[name]',
      //   },
      // },
      {
        test: /\.(svg)(\?.*)?$/,
        type: 'asset/resource',
        generator: { filename: 'img/[contenthash:8][ext][query]' },
      },

      // media
      {
        test: /\.(mp4|webm|ogg|mp3|wav|flac|aac)(\?.*)?$/,
        type: 'asset',
        generator: { filename: 'media/[contenthash:8][ext][query]' },
      },

      // fonts
      {
        test: /\.(woff2?|eot|ttf|otf)(\?.*)?$/i,
        type: 'asset',
        generator: { filename: 'fonts/[contenthash:8][ext][query]' },
      },
    ],
  },
}
