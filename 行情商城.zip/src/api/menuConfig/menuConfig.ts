import request from '@/utils/request/request'

// 初始配置树
export const getInitTree = (data?: object, loading?: boolean) => {
  return request('/uc/menu/config/initTree', 'post', data, loading)
}

// 恢复初始菜单
export const restoreInit = (data?: object, loading?: boolean) => {
  return request('/uc/menu/config/restoreInit', 'post', data, loading)
}

// 个性化配置树
export const getCostomTree = (data?: object, loading?: boolean) => {
  return request('/uc/menu/config/tree', 'post', data, loading)
}

// 更新个性化配置树
export const updateCostomTree = (tree: any[], loading?: boolean) => {
  return request('/uc/menu/config/updateTree', 'post', { tree }, loading)
}

export interface ModifyNameParam {
  id: number // 菜单ID
  moduleCode: string // 模块编码
  lang: string
  name: string
}

// 修改菜单名称
export const modifyMenuName = (data: ModifyNameParam, loading?: boolean) => {
  return request('/uc/menu/config/modifyName', 'post', data, loading)
}

/** 文件icon */
export const uploadFiles = (data?: any) => {
  return request('/uc/sys/file/upload/menu_icon', 'post', data, null, {
    headers: {
      'content-type': 'multipart/form-data',
    },
  })
}
