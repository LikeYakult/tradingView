/* eslint-disable no-unused-vars */
/* eslint-disable no-shadow */
import { microAppDict } from './constants/micro-app'

const internalModuleDictTemp: Record<string, string> = {}

const entryUrl = (url: string, key: string): string => {
  return url || key
}

// 单体应用模式下，内部模块路由 = 模块路由基座 + 菜单 path
// （micro-app 子应用基座为空字符串，路径保持后端菜单原始 path）
Object.keys(microAppDict).forEach((key: string) => {
  const targetModule = microAppDict[key]

  if (!targetModule) return
  const { routerBase } = targetModule

  internalModuleDictTemp[targetModule.beCode] = routerBase || ''
})

export const internalModuleDict = internalModuleDictTemp

export const createInternalPath = (list: any[] = [], code: string): any => {
  return list.map((item) => ({
    ...item,
    internalPath: `${internalModuleDict[item.routeModule || code] || ''}${item.path}`,
    children: createInternalPath(item.children, code)
  }))
}

export default entryUrl
