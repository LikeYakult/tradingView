import request from '@/utils/request/request'
import { authorizedCommonJavaInst, commonJavaInst } from '../common-java-instance'

// 验证码
export const getIdentifyingCode = (data: object) => {
  return commonJavaInst.post('/uc/login/getCode', data)
}

// 登录
export const login = (data?: object) => {
  return commonJavaInst.post('/uc/login/byPwd', data)
}
// 登录信息
export const loginInfo = (data?: object) => {
  return authorizedCommonJavaInst.post('/uc/login/data', data)
}
// 模块列表
export const getModulesListApi = (data?: object) => {
  return authorizedCommonJavaInst.post('/uc/login/modules', data)
}
// 获取权限菜单、按钮
export const getMenuBtnList = (data?: object) => {
  return authorizedCommonJavaInst.post('/uc/home/moduleInfo', data)
}
// 首页数据 - 登录信息
export const systemLoginInfo = (data?: object) => {
  return authorizedCommonJavaInst.post('/uc/home/loginInfo', data)
}

// 获取外部模块链接
export const getExternalModuleUrl = (data?: object) => {
  return authorizedCommonJavaInst.post('/uc/user/getModuleUrl', data)
}
// 模块列表（多模块）
export const getMultiModuleList = (data?: object) => {
  return authorizedCommonJavaInst.post('/uc/home/moduleList', data)
}

// 获取语言列表
export const getLanguageList = (data?: object) => {
  return authorizedCommonJavaInst.post('/uc/common/dictList', data)
}

// 获取语言列表 - 不需要token
export const getLanguageConfig = (data?: object) => {
  return commonJavaInst.post('/uc/common/dictLang', data)
}

// 修改密码
export const changePassword = (data?: object) => {
  return authorizedCommonJavaInst.post('/uc/my/modifyPwd', data)
}

// 登出
export const logout = (data?: object) => {
  return authorizedCommonJavaInst.post('/uc/login/logout', data)
}
