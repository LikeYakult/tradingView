import { BASE_URL } from '@/utils/request/config'
import { authorizedCommonJavaInst } from '../common-java-instance'
import { IJavaAPICommonResponse, IListAPIParams } from '../types'
import { exportFile } from '@/utils'

export type ITradeLoginLogsListParams = IListAPIParams & {
  beginTime: string
  channelType: string
  country: string
  endTime: string
  keyword: string
  terminal: string
}

export function fetchDicts(
  types: string[]
): Promise<IJavaAPICommonResponse<Record<string, [any, string][]>>> {
  return authorizedCommonJavaInst.post('/nuc/sys/dict/getByTypes', { types })
}

export const tradeLoginLogsList = (data: ITradeLoginLogsListParams) => {
  return authorizedCommonJavaInst.post('/nuc/customer/trade/loginLog/list', data)
}

export const exportTradeLoginLogsList = (data: Record<string, any>) => {
  return exportFile(BASE_URL, '/nuc/customer/trade/loginLog/export', data, '交易登录日志列表.xls')
}

export const loginLogsList = (data: ITradeLoginLogsListParams) => {
  return authorizedCommonJavaInst.post('/nuc/customer/loginLog/list', data)
}

export const exportLoginLogsList = (data: Record<string, any>) => {
  return exportFile(BASE_URL, '/nuc/customer/loginLog/export', data, '登录日志列表.xls')
}

export const riskList = (data: ITradeLoginLogsListParams) => {
  return authorizedCommonJavaInst.post('/nuc/monitor/report/list', data)
}

export const exportRiskList = (data: Record<string, any>) => {
  return exportFile(BASE_URL, '/nuc/monitor/report/export', data, '风险列表.xls')
}

export const exportCustomerList = (data: Record<string, any>, filename?: string) => {
  return exportFile(BASE_URL, '/nuc/internet/export', data, '互联网账户列表.xls')
}

export const fetchRelatedTradeAccount = (id: number) => {
  return authorizedCommonJavaInst.post('/nuc/internet/getTradeAccount', { id })
}

// ========== quotation 视图（take-nodes）使用的互联网账户查询 ==========

export type IFetchCustomerListWithTradeAccountParams = IListAPIParams &
  Partial<{
    keyword: string
  }>

export type ICustomerListItemWithTradeAccount = {
  id: number
  cusNo: number
  areaCode: string
  mobile: string
  nickName: string
  userName: string
  email: string
  registerFrom: string
  status: string
  statusName: string
  isDeactivate: string
  createTime: string
  tradeAccount: any
  accountType: any
  preRegister: any
  preBind: any
  tradeAccounts: string[]
  accountTypeName: any
}

export function fetchCustomerListWithTradeAccount(
  params: IFetchCustomerListWithTradeAccountParams
): Promise<IJavaAPICommonResponse<ICustomerListItemWithTradeAccount[]>> {
  return authorizedCommonJavaInst.post('/nuc/internet/getCustomerList', params)
}
