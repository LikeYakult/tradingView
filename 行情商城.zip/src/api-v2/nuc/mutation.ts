import {
  authorizedCommonJavaInst,
  authorizedCommonJavaInstSuppressErrorTips,
} from '../common-java-instance'

export type IBatchChangeInternetAccountStatusParams = {
  ids: number[]
  status: '1' | '0'
}

export function batchChangeInternetAccountStatus(params: IBatchChangeInternetAccountStatusParams) {
  return authorizedCommonJavaInst.post('/nuc/internet/change/enable', params)
}

export type IChangeInternetAccountStatusParams = {
  id: number
} & Pick<IBatchChangeInternetAccountStatusParams, 'status'>

export function changeInternetAccountStatus(params: IChangeInternetAccountStatusParams) {
  return batchChangeInternetAccountStatus({ ids: [params.id], status: params.status })
}

export interface IBindTradeAccountParams {
  accountInfo: {
    tradeAccount: string
  }[]
  id: number
}

export function bindTradeAccount(params: IBindTradeAccountParams) {
  return authorizedCommonJavaInstSuppressErrorTips.post('/nuc/internet/bindTradeAccount', params)
}
