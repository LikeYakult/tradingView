import { BASE_URL } from '@/utils/request/config'
import { authorizedCommonJavaInst } from '../common-java-instance'
import { IJavaAPICommonResponse, IJavaListResponse, IListAPIParams } from '../types'
import { exportFile } from '@/utils'

export function fetchDicts(
  types: string[]
): Promise<IJavaAPICommonResponse<Record<string, [any, string][]>>> {
  return authorizedCommonJavaInst.post('/quotation/sys/dict/getByTypes', { types })
}

export type IFetchCustomerQuotationListParams = IListAPIParams & {
  createDateEnd: string
  createDateStart: string
  keyword: string
  packageId: string
}

export interface IFetchCustomerQuotationListItem {
  accountTypeName: string
  createTime: string
  cusNo: string
  email: string
  mobile: string
  nickName: string
  tradeAccount: string
  tradeAccountName: string
  userName: string
}

export type IFetchCustomerQuotationTradeAccountListParams = IListAPIParams &
  Partial<{
    tradeAccount: string
    packageId: string
    createDateStart: string
    createDateEnd: string
  }>

export function fetchCustomerQuotationTradeAccountList(
  params: IFetchCustomerQuotationTradeAccountListParams
): Promise<IJavaListResponse<IFetchCustomerQuotationListItem>> {
  return authorizedCommonJavaInst.post('/quotation/customer/quo/list', params)
}

export interface IPackageOptionItem {
  productId?: number | string
  marketName: string
  currency: string
  packageId: string
  packageName: string
  productName: string
  price: number
  createTime: string
  enableStart: string
  enableEnd: string
  enableDate: string
  enable: string
  enableName: string
  terminal: string
  region: string
  terminalName: string
  regionName: string
  status: string
  statusName: string
}

/**
 * 下拉框类型[1:审核通过套餐 ; 2:生效套餐(订单申购)]
 */
export function fetchPackageOptions(
  type: 1 | 2 = 1,
  tradeAccount = ''
): Promise<IJavaAPICommonResponse<IPackageOptionItem[]>> {
  return authorizedCommonJavaInst
    .post('/quotation/package/condition/list', {
      type,
      tradeAccount,
    })
    .then((res) => {
      return {
        ...res,
        result: res.result.map((item: IPackageOptionItem) => ({
          ...item,
          packageId: item.packageId?.toString(),
        })),
      }
    })
}

export function fetchQuotationOrderDetail(orderId: string): Promise<IJavaAPICommonResponse> {
  return authorizedCommonJavaInst.post('/quotation/order/detail', {
    orderId,
  })
}

export const exportCustomerQuotationList = (data: Record<string, any>) => {
  return exportFile(BASE_URL, '/quotation/customer/export/quo/list', data, '客户行情权限列表.xls')
}

export const exportUnifiedReport = (data: Record<string, any>) => {
  return exportFile(BASE_URL, '/quotation/report/export/unify/list', data, '统一上报报表.xls')
}

export const exportCustomerQuotationUsageList = (data: Record<string, any>) => {
  return exportFile(
    BASE_URL,
    '/quotation/customer/export/quo/use/list',
    data,
    '行情使用日志查询.xls'
  )
}

export interface IProductListItem {
  name: string
  productId: number
}

export function fetchProductList() {
  return authorizedCommonJavaInst.post<IJavaAPICommonResponse<IProductListItem[]>>(
    '/quotation/package/product/list'
  )
}

export interface IPackageI18nListItem {
  lang: string
  name: string
  remark: string
}

export interface IPackageExemptionRuleItem {
  exemptionType: string
  numberAmount: number | undefined
  directGift: boolean
  waiveAmount: number | undefined
  redemptionValidityPeriod: number | undefined
  freeQuote: number | undefined
}

export interface IPackageDetailBase {
  accountType: string
  calculationMethod?: string
  calculationPeriod?: string
  currency: string
  defaultAuthorize?: boolean
  enable: string
  enableEnd: string
  enableWaive?: boolean
  enableStart: string
  waiveList?: IPackageExemptionRuleItem[]
  feeId?: string
  chargeMethod?: string
  isPi?: boolean
  snapshotMonthlyBasicFreeQuote?: number | undefined
  packageId?: string
  price: number
  productId?: number
  region: string
  targetCustomer?: string
  terminal: string[]
  rtq: string
  vipPackage?: string
  i18nMap?: Record<string, IPackageI18nListItem>
  isDefault?: boolean
  waiveOnRenew?: boolean
}

export interface ISavePackageParams extends IPackageDetailBase {
  i18nList: IPackageI18nListItem[]
}

export interface IPackageDetail extends IPackageDetailBase {
  i18nMap: Record<string, IPackageI18nListItem>
  reviewRemark: string
  status: string
}

export function savePackage(params: ISavePackageParams) {
  return authorizedCommonJavaInst.post('/quotation/package/save', params)
}

export function fetchPackageDetail(
  packageId: string
): Promise<IJavaAPICommonResponse<IPackageDetail>> {
  return authorizedCommonJavaInst.post('/quotation/package/detail', {
    packageId,
  })
}

export interface IAccountQuotationItem {
  isGive: boolean
  packageId: string
  tradeAccount: string
  accountTypeName: string | null
  autoRenew: boolean
  packageName: string
  rtq: string
  status: string
  enableStart: string
  enableEnd: string
  quotationName: string
  orderEnableStatus: string
}

export interface IAccountQuotationsResult {
  buyList: IAccountQuotationItem[]
  giveList: IAccountQuotationItem[]
}

export function fetchAccountQuotations(
  tradeAccount: string
): Promise<IJavaAPICommonResponse<IAccountQuotationsResult>> {
  return authorizedCommonJavaInst.post('/quotation/customer/quo/packages', {
    tradeAccount,
  })
}

export interface IFetchQuotationChangeRecordsParams {
  packageId: string
  tradeAccount: string
}

export function fetchQuotationChangeRecords(params: IFetchQuotationChangeRecordsParams) {
  return authorizedCommonJavaInst.post('/quotation/customer/switch/autoRenew/flow', params)
}
