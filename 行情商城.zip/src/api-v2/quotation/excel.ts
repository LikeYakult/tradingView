import { exportFile } from '@/utils'
import { authorizedCommonJavaInst } from '../common-java-instance'
import { baseUrl } from '.'

// 导入-列表
export const importList = (data: object) => {
  return authorizedCommonJavaInst.post(`${baseUrl}/excel/importLog/list`, data)
}

// 导出模板
export const importLogDownload = (
  data: Record<string, any> = {},
  filename = '批量导入模板.xls'
) => {
  return exportFile(baseUrl, '/excel/importLog/downloadLog', data, filename)
}
