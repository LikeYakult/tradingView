import { authorizedCommonJavaInst } from '../common-java-instance'
import { IJavaAPICommonResponse, IJavaListResponse, IListAPIParams } from '../types'

/** 费用列表查询参数 */
export type IFeeListQueryParams = IListAPIParams &
  Partial<{
    id: string
    name: string
    createDateStart: string
    createDateEnd: string
  }>

/** 费用列表项 */
export interface IFeeListItem {
  id: string
  name: string
  fixAmount: number
  currency: string
  createTime: string
}

/** 新增/编辑费用保存参数 */
export interface IFeeSaveParams {
  id: string
  isStandard?: boolean
  name: string
  otherLanguage?: string
  roundingMethod: string
  roundingDecimal: number
  feeCurrency: string
  feeCategory: string
  subTransactionType?: string
  currency: string
  country?: string
  formatSelection?: string
  applyMultipleChannelsMinimumMaximum?: boolean
  showZeroAmountInStatementPreconf?: boolean
  generateBrokerSettlementGl?: boolean
  channelId?: string
  defaultFlag?: boolean
  channelClassId?: string
  brokerId?: string
  chargeOperation: string
  defaultOnlineChannelFeeSetting?: boolean
  chargeType: string
  minimumFeeAmount?: number
  maximumFeeAmount?: number
  fixAmount: number
  dollarUnit?: number
  fixRate?: number
  interestRate?: string
  amountNoOfOrders?: number
  rateAmount?: number
  applyMinimumMaximumBeforeApplyQty?: boolean
}

/** 费用详情接口返回 */
export type IFeeDetail = IFeeSaveParams

/** 费用删除参数 */
export interface IFeeDeleteParams {
  id: string
}

/** 费用详情查询参数 */
export interface IFeeDetailParams {
  id: string
}

/** 查询费用列表 */
export function fetchFeeList(
  params: IFeeListQueryParams
): Promise<IJavaListResponse<IFeeListItem>> {
  return authorizedCommonJavaInst.post('/quotation/fee/list', params)
}

/** 新增或编辑费用保存 */
export function saveFee(params: IFeeSaveParams): Promise<IJavaAPICommonResponse<null>> {
  return authorizedCommonJavaInst.post('/quotation/fee/save', params)
}

/** 删除费用 */
export function deleteFee(id: string): Promise<IJavaAPICommonResponse<null>> {
  return authorizedCommonJavaInst.post('/quotation/fee/delete', { id })
}

/** 查询费用详情 */
export function fetchFeeDetail(id: string): Promise<IJavaAPICommonResponse<IFeeDetail>> {
  return authorizedCommonJavaInst.post('/quotation/fee/detail', { id })
}

/** 费用条件列表项 */
export interface IFeeConditionListItem {
  id: string
  name: string
  fixAmount: number
  currency: string
  createTime: string
}

/** 查询费用下拉条件列表 */
export function fetchFeeConditionList(): Promise<IJavaAPICommonResponse<IFeeConditionListItem[]>> {
  return authorizedCommonJavaInst.post('/quotation/fee/condition/list')
}
