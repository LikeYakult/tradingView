import request from '@/utils/request/request'
import { exportFile } from '@/utils'
import { authorizedCommonJavaInst } from '../common-java-instance'
import { baseUrl } from '.'

// 取消自动续期
export const autoRenewReq = (data: object) => {
  return request(`${baseUrl}/order/auto/renew`, 'post', data)
}

// 串流行情订购记录-订购记录-列表
export const orderListReq = (data: object) => {
  return request(`${baseUrl}/order/list`, 'post', data, undefined, { returnResponse: true }).then(
    (res) => ({
      ...res.data,
      serverDate: res.headers?.date,
    })
  )
}
// 点击报价订购记录-点击报价-列表
export const orderListReqClick = (data: object) => {
  return request(`${baseUrl}/order/list/click`, 'post', data)
}

// 导出订购记录
export const orderListExpor = (data: Record<string, any>, filename = '订购记录.xls') => {
  return exportFile(baseUrl, '/order/export/list', data, filename)
}

// 导出模板
export const templateExport = (data: Record<string, any> = {}, filename = '批量导入模板.xls') => {
  return exportFile(baseUrl, '/order/export/template', data, filename)
}

// 查询订单详情
export const orderDetail = (data: object) => {
  return authorizedCommonJavaInst.post(`${baseUrl}/order/detail`, data)
}

// 导入订单进度查询
export const orderImportProgress = (data: object) => {
  return authorizedCommonJavaInst.post(`${baseUrl}/order/import/progress`, data)
}

// 导出扣费记录
export const reportExportPayList = (data: Record<string, any>, filename = '扣费记录.xls') => {
  return exportFile(baseUrl, '/report/export/pay/list', data, filename)
}

// 订购管理-点击记录-列表
export const clickList = (data: object, loading?: boolean) => {
  return request(`${baseUrl}/click/log/list`, 'post', data, loading)
}

// 订购管理-点击记录-导出
export const clickExportList = (data: Record<string, any>, filename = '点击记录.xls') => {
  return exportFile(baseUrl, '/click/log/export/list', data, filename)
}

// 订购管理-点击报价订购记录-审核
export const orderReview = (data: object) => {
  return request(`${baseUrl}/order/review`, 'post', data)
}
// 点击报价订购记录-批量审核
export const orderBatchReview = (data: object) => {
  return request(`${baseUrl}/order/batch_review`, 'post', data)
}

// 获取维护时间
export const requestMaintainTime = () => {
  return request(`${baseUrl}/system/maintainTime`, 'post', {})
}
