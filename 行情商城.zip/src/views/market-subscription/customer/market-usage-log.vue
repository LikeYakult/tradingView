<script setup lang="ts">
import { reactive, onBeforeMount, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage } from 'element-plus'
import baseFilter from '@/components/base-filter/base-filter'
import dzTable from '@/components/dz-table/dz-table'

import { cloneDeep, timeDiff } from '@/utils/common'
import { exportCustomerQuotationUsageList, fetchDicts } from '@/api-v2/quotation/query'
import useTableData from '@/hooks/useTableData'
import ConfigType from '@/types/requestType'
import { SelectOptions } from '@/types'
import { extractDict } from '@/utils/options-dictionary'

const { t } = useI18n()

// #region options
const terminalOptions = ref<SelectOptions>([])

function initDicts() {
  fetchDicts(['terminal']).then((res) => {
    extractDict(res?.result?.terminal, terminalOptions)
  })
}
// #endregion

onBeforeMount(() => {
  initDicts()
})

// #region table

const ordering = reactive<Record<string, any>>({
  asc: true,
  column: '',
})

const reqConfig = reactive<ConfigType>({
  url: '/quotation/customer/quo/use/list',
  method: 'POST',
  data: {},
})

// 选中行数
let tableSelectionRows: any[] = []
const tableSelectionChange = (selection: []) => {
  tableSelectionRows = selection
}

const { tableData, pagination, loading } = useTableData(reqConfig)

function getSearchParams() {
  const params: Record<string, any> = cloneDeep(filterConfig.formProps.model)
  if (params.createDate) {
    const [startDate, endDate] = params.createDate
    params.createDateStart = startDate
    params.createDateEnd = endDate

    delete params.createDate
  }
  if (ordering.column) {
    params.orders = [ordering]
  }

  return params
}

const searchDataList = () => {
  reqConfig.data = getSearchParams()
}

// #endregion
const tableConfig = reactive({
  tableProps: {
    data: tableData,
    height: '580',
  },
  tableEvent: {
    onSelectionChange: tableSelectionChange,
    onSortChange: (column: Record<string, any>) => {
      const { order, prop } = column
      ordering.column = prop
      if (!order) {
        ordering.column = undefined
        ordering.asc = undefined
      } else {
        ordering.asc = order === 'ascending' ? true : false
      }
      searchDataList()
    },
  },
  customColumns: [
    { label: t('market_uses_id'), prop: 'id', minWidth: 120 },
    { label: t('market_uses_time'), prop: 'createTime', minWidth: 180, sortable: 'custom' },
    { label: t('mobile_number'), prop: 'mobile', minWidth: 120 },
    { label: t('internet_account'), prop: 'cusNo', sortable: 'custom', minWidth: 120 },
    { label: t('trading_name'), prop: 'tradeAccount', minWidth: 120 },
    { label: t('market_authorization'), prop: 'quotationName', minWidth: 200 },
    { label: t('device_number'), prop: 'deviceId', minWidth: 200 },
    { label: t('client'), prop: 'terminal' },
    { label: t('version_number'), prop: 'version', minWidth: 120 },
    { label: t('operating_system'), prop: 'os', minWidth: 120 },
    { label: t('ip_address'), prop: 'ip', minWidth: 120 },
    { label: t('country_region'), prop: 'country', minWidth: 120 },
    { slot: 'status' },
  ],
})

// 表单配置
const formItems = [
  {
    prop: 'keyword',
    label: t('user_account_keyword'),
    innerEl: { elType: 'input', props: { placeholder: t('please_enter_user_account_phone') } },
  },
  {
    prop: 'terminal',
    label: t('client'),
    innerEl: {
      elType: 'select',
      options: terminalOptions,
    },
  },
  {
    prop: 'country',
    label: t('country_region'),
    innerEl: { elType: 'input', props: { placeholder: t('please_enter_country_area_keyword') } },
  },
  {
    prop: 'createDate',
    label: t('market_uses_time'),
    innerEl: { elType: 'datePicke', props: { type: 'daterange', 'value-format': 'YYYY-MM-DD' } },
  },
]

/** 表单数据 */
const filterConfig = reactive({
  formProps: {
    model: {
      keyword: '',
      channelType: '',
      country: '',
      createDate: [],
      accountType: 1,
    },
  },
  formItems,
})

/** 导出接口 */
const isExportLoading = ref(false)
function exportFunc() {
  const { createDate = [] } = filterConfig.formProps.model
  if (!createDate || !createDate.length) {
    ElMessage.warning(t('export_message'))
    return
  }

  const [beginTime, endTime] = createDate
  if (timeDiff(beginTime, endTime)) {
    ElMessage.warning(t('export_month_message'))
    return
  }

  isExportLoading.value = true

  const params = getSearchParams()

  exportCustomerQuotationUsageList(params).finally(() => {
    isExportLoading.value = false
  })
}

const statusText = (status: boolean) => {
  return status ? t('succeed') : t('failure')
}
</script>

<template>
  <el-card>
    <base-filter :loading="loading" :config="filterConfig" @on-search="searchDataList" @on-reset="searchDataList" />
    <div class="operate-buttons">
      <el-button plain
        v-permission="'quo:use:list:export'"
        type="primary"
        :loading="isExportLoading"
        class="export-button"
        @click="exportFunc"
        >{{ $t('export') }}</el-button
      >
    </div>
    <div class="table">
      <dz-table :config="tableConfig" :pagination="pagination" :is-table-loading="loading">
        <template #subaccount_type>
          <el-table-column :label="$t('trading_name')">
            <template #default="scope">
              <span>{{ scope.row.accountType === 1 && t('market') }}</span>
            </template>
          </el-table-column>
        </template>
        <template #status>
          <el-table-column :label="$t('state')" width="100">
            <template #default="scope">
              <span>{{ statusText(scope.row.status) }}</span>
            </template>
          </el-table-column>
        </template>
      </dz-table>
    </div>
  </el-card>
</template>
