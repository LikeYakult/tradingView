<script setup lang="ts">
import { reactive, onBeforeMount, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage } from 'element-plus'
import baseFilter from '@/components/base-filter/base-filter'
import marketAuthDialog from './market-auth-dialog.vue'

// 套餐列表

import { cloneDeep, timeDiff } from '@/utils/common'
import useTableData from '@/hooks/useTableData'
import dzTable from '@/components/dz-table/dz-table'
import ConfigType from '@/types/requestType'
import { SelectOptions } from '@/types'
import { exportCustomerQuotationList, fetchPackageOptions } from '@/api-v2/quotation/query'

const { t } = useI18n()

// #region options
const quotationPermissionsOptions = ref<SelectOptions>([])

function initDicts() {
  fetchPackageOptions(1).then((res) => {
    quotationPermissionsOptions.value = res.result.map((v: any) => ({
      label: v.packageName,
      value: v.packageId,
    }))
  })
}
// #endregion

onBeforeMount(() => {
  initDicts()
})

// #region table

const ordering = reactive<Record<string, any>>({
  asc: true,
  column: '',
})

const reqConfig = reactive<ConfigType>({
  url: '/quotation/customer/quo/list',
  method: 'POST',
  data: {},
})

// 选中行数
let tableSelectionRows: any[] = []
const tableSelectionChange = (selection: []) => {
  tableSelectionRows = selection
}

const { tableData, pagination, loading } = useTableData(reqConfig)

function getSearchParams() {
  const params: Record<string, any> = cloneDeep(filterConfig.formProps.model)
  if (params.createDate) {
    const [startDate, endDate] = params.createDate
    params.createDateStart = startDate
    params.createDateEnd = endDate

    delete params.createDate
  }
  if (ordering.column) {
    params.orders = [ordering]
  }

  return params
}

const searchDataList = () => {
  reqConfig.data = getSearchParams()
}

// #endregion
function renderEmptyValue(value: unknown) {
  return value === null || value === undefined || value === '' ? '--' : value
}

function renderColumn(prop: string) {
  return (scope: { row: Record<string, unknown> }) => renderEmptyValue(scope.row[prop])
}

const tableConfig = reactive({
  tableProps: {
    data: tableData,
    height: '580',
  },
  tableEvent: {
    onSelectionChange: tableSelectionChange,
    onSortChange: (column: Record<string, any>) => {
      const { order, prop } = column
      ordering.column = prop
      if (!order) {
        ordering.column = undefined
        ordering.asc = undefined
      } else {
        ordering.asc = order === 'ascending' ? true : false
      }
      searchDataList()
    },
  },
  customColumns: [
    { slot: 'tradeAccount' },
    {
      label: t('customer_name'),
      prop: 'userName',
      minWidth: '140',
      render: renderColumn('userName'),
    },
    { label: t('mobile_number'), prop: 'mobile', minWidth: '160', render: renderColumn('mobile') },
    { label: t('name'), prop: 'userName', minWidth: '180', render: renderColumn('userName') },
    { label: t('email'), prop: 'email', minWidth: '240', render: renderColumn('email') },
    { label: t('branch_id'), prop: 'branchId', minWidth: '160', render: renderColumn('branchId') },
    {
      label: t('customer_manager_id'),
      prop: 'customerManagerId',
      minWidth: '170',
      render: renderColumn('customerManagerId'),
    },
    {
      label: t('registration_time'),
      prop: 'createTime',
      minWidth: '170',
      sortable: 'custom',
      render: renderColumn('createTime'),
    },
    { slot: 'marketAuthorization' },
  ],
})

// #region filter form

// 表单配置
const formItems = [
  {
    prop: 'createDate',
    label: t('registration_time'),
    innerEl: { elType: 'datePicke', props: { type: 'daterange', valueFormat: 'YYYY-MM-DD' } },
  },
  {
    prop: 'packageId',
    label: t('market_authorization'),
    innerEl: {
      elType: 'select',
      options: quotationPermissionsOptions,
      props: { placeholder: t('please_select') },
    },
  },
  {
    prop: 'keyword',
    label: t('user_account_keyword'),
    innerEl: {
      elType: 'input',
      props: { style: { width: '260px' }, placeholder: t('please_enter_middle_account_keyword') },
    },
  },
]

/** 表单数据 */
const filterConfig = reactive({
  formProps: {
    model: {
      createDate: [],
      packageId: '',
      keyword: '',
    },
  },
  formItems,
})

// #endregion

/** 导出接口 */
const isExportLoading = ref(false)
function exportFunc() {
  const { createDate = [] } = filterConfig.formProps.model
  if (!createDate || !createDate.length) {
    ElMessage.warning(t('export_message'))
    return
  }

  const [beginTime, endTime] = createDate
  if (timeDiff(beginTime, endTime)) {
    ElMessage.warning(t('export_month_message'))
    return
  }

  isExportLoading.value = true

  const params = getSearchParams()

  exportCustomerQuotationList(params).finally(() => {
    isExportLoading.value = false
  })
}

const dialogRef = ref()

function openMarketAuthorizationDetail(row: Record<string, any>) {
  dialogRef.value.open(row.tradeAccount)
}

// 弹窗确认
function dialogSure() {
  searchDataList()
}
</script>

<template>
  <el-card>
    <base-filter :loading="loading" :config="filterConfig" @on-search="searchDataList" @on-reset="searchDataList" />
    <div class="operate-buttons">
      <el-button plain
        v-permission="'quo:cus:list:export'"
        type="primary"
        size="small"
        :loading="isExportLoading"
        class="export-button"
        @click="exportFunc"
        >{{ $t('export') }}</el-button
      >
    </div>
    <div class="table">
      <dzTable :config="tableConfig" :pagination="pagination" :is-table-loading="loading">
        <!-- <template #meal>
          <el-table-column :label="$t('market_package_text')" align="center">
            <template #default="scope">
              <div v-permission:disabled="'order:auto:renew'" style="color: blue; cursor: pointer">
                <span
                  v-for="(item, i) in scope.row.orders"
                  :key="i"
                  class="market-package"
                  @click="openOrderSetting(scope.row, item)"
                >
                  {{ item.packageName }}
                </span>
              </div>
            </template>
          </el-table-column>
        </template> -->

        <template #tradeAccount>
          <el-table-column :label="$t('trading_account')" min-width="180" align="center">
            <template #default="scope">
              <div>
                {{ renderEmptyValue(scope.row.tradeAccount) }}
              </div>
            </template>
          </el-table-column>
        </template>

        <template #marketAuthorization>
          <el-table-column :label="$t('market_authorization')" align="center" fixed="right">
            <template #default="scope">
              <el-button
                v-permission="'quo:cus:list:detail'"
                type="text"
                size="small"
                @click="openMarketAuthorizationDetail(scope.row)"
              >
                {{ $t('details') }}
              </el-button>
            </template>
          </el-table-column>
        </template>
      </dzTable>
    </div>

    <marketAuthDialog ref="dialogRef" :sure="dialogSure" />
  </el-card>
</template>

<style scoped>
.market-package {
  display: block;
}
</style>
