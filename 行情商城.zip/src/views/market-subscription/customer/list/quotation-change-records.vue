<template>
  <el-dialog
    v-model="dialogTableVisible"
    destroy-on-close
    :close-on-click-modal="false"
    :title="$t('quotation_change_records')"
    center
    width="800px"
    class="renewal-set-dialog"
    @closed="onClosed"
  >
    <div class="table">
      <dz-table :config="tableConfig" :is-table-loading="isLoading">
        <template #cancelStatusName>
          <el-table-column :label="$t('changed_content')" align="center">
            <template #default="scope">
              <div v-html="scope.row.cancelStatusNameHTML" />
            </template>
          </el-table-column>
        </template>
      </dz-table>
    </div>
    <template #footer>
      <div>
        <el-button @click="dialogTableVisible = false">{{ $t('close') }}</el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script lang="ts" setup>
import { ref, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import dzTable from '@/components/dz-table/dz-table'
import {
  fetchQuotationChangeRecords,
  IFetchQuotationChangeRecordsParams,
} from '@/api-v2/quotation/query'

const { t } = useI18n()
const dialogTableVisible = ref(false)
const isLoading = ref(false)

const params = ref<IFetchQuotationChangeRecordsParams>()

function open(_params: IFetchQuotationChangeRecordsParams) {
  params.value = _params
  dialogTableVisible.value = true
}

function onClosed() {
  params.value = undefined
}

const tableConfig = {
  tableProps: {
    emptyText: t('no_market_auth_data'),
    maxHeight: 400,
    data: [],
  },
  customColumns: [
    { label: t('serial_number'), type: 'index', minWidth: 30 },
    { label: t('changed_time'), prop: 'createTime' },
    { slot: 'cancelStatusName' },
    { label: t('operator'), prop: 'createByUser' },
  ],
}

const fetchTableData = () => {
  if (!params.value) return

  isLoading.value = true

  fetchQuotationChangeRecords(params.value)
    .then((res: any) => {
      tableConfig.tableProps.data = res.result?.map((item: any) => ({
        ...item,
        cancelStatusNameHTML: item.cancelStatusName.replace(/\\n/g, '<br />'),
      }))

      console.log(tableConfig.tableProps.data)
    })
    .finally(() => {
      isLoading.value = false
    })
}

watch(
  params,
  (newVal) => {
    if (newVal) {
      fetchTableData()
    } else {
      tableConfig.tableProps.data = []
    }
  },
  { immediate: true }
)
defineExpose({
  open,
})
</script>

<style lang="scss" scoped>
.auto-renew-cell {
  display: flex;
  align-items: center;
  flex-direction: column;
}
</style>
