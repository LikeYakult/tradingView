<template>
  <el-dialog
    v-model="dialogTableVisible"
    destroy-on-close
    :close-on-click-modal="false"
    :title="$t('market_authorization')"
    center
    width="1000px"
    class="renewal-set-dialog"
    @closed="onClosed"
  >
    <div>
      <el-form>
        <el-form-item :label="$t('trading_name') + ':'">
          <span>{{ tradeAccount }}</span>
        </el-form-item>
      </el-form>

      <div
        v-if="buyTableConfig.tableProps.data && buyTableConfig.tableProps.data.length > 0"
        class="auth-table-section"
      >
        <div class="auth-table-title">{{ $t('permission_list') }}</div>
        <dz-table :config="buyTableConfig" :is-table-loading="isLoading">
          <template #autoRenew>
            <el-table-column
              v-if="canViewAutoRenew"
              :label="$t('auto_renewal')"
              align="center"
              min-width="130"
            >
              <template #default="scope">
                <div class="auto-renew-cell">
                  <el-switch
                    v-if="canUpdateAutoRenew && hasAutoRenewValue(scope.row)"
                    :model-value="isAutoRenewEnabled(scope.row)"
                    class="ml-2"
                    style="--el-switch-on-color: #13ce66"
                    @click="handleChangeAutoRenew(scope.row)"
                  />
                  <span v-else-if="hasAutoRenewValue(scope.row)">
                    {{ isAutoRenewEnabled(scope.row) ? $t('yes') : $t('no') }}
                  </span>
                  <el-text class="mx-1" type="warning">{{ scope.row.cancelStatusName }}</el-text>
                </div>
              </template>
            </el-table-column>
          </template>

          <template #changeRecord>
            <el-table-column :label="$t('change_record')" align="center" min-width="100">
              <template #default="scope">
                <el-button type="text" @click="openChangeRecord(scope.row)">
                  {{ $t('details') }}
                </el-button>
              </template>
            </el-table-column>
          </template>
        </dz-table>
      </div>

      <div
        v-if="giftTableConfig.tableProps.data && giftTableConfig.tableProps.data.length > 0"
        class="auth-table-section"
      >
        <div class="auth-table-title">{{ $t('gift_list') }}</div>
        <dz-table :config="giftTableConfig" :is-table-loading="isLoading">
          <template #autoRenew>
            <el-table-column
              v-if="canViewAutoRenew"
              :label="$t('auto_renewal')"
              align="center"
              min-width="130"
            >
              <template #default="scope">
                <div class="auto-renew-cell">
                  <el-switch
                    v-if="canUpdateAutoRenew && hasAutoRenewValue(scope.row)"
                    :model-value="isAutoRenewEnabled(scope.row)"
                    class="ml-2"
                    style="--el-switch-on-color: #13ce66"
                    @click="handleChangeAutoRenew(scope.row)"
                  />
                  <span v-else-if="hasAutoRenewValue(scope.row)">
                    {{ isAutoRenewEnabled(scope.row) ? $t('yes') : $t('no') }}
                  </span>
                  <el-text class="mx-1" type="warning">{{ scope.row.cancelStatusName }}</el-text>
                </div>
              </template>
            </el-table-column>
          </template>
          <template #changeRecord>
            <el-table-column :label="$t('change_record')" align="center" min-width="100">
              <template #default="scope">
                <el-button type="text" @click="openChangeRecord(scope.row)">
                  {{ $t('details') }}
                </el-button>
              </template>
            </el-table-column>
          </template>
        </dz-table>
      </div>

      <el-empty
        v-if="
          !isLoading &&
          buyTableConfig.tableProps.data.length === 0 &&
          giftTableConfig.tableProps.data.length === 0
        "
        :description="$t('no_market_auth_data')"
      />
    </div>

    <template #footer>
      <div>
        <el-button @click="dialogTableVisible = false">{{ $t('close') }}</el-button>
      </div>
    </template>

    <quotationChangeRecords ref="quotationChangeRecordsRef" />
  </el-dialog>
</template>

<script lang="ts" setup>
import { computed, ref, reactive, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessageBox } from 'element-plus'
import { useAppStore } from '@/store'

const appStore = useAppStore()
import dzTable from '@/components/dz-table/dz-table'
import {
  fetchAccountQuotations,
  IAccountQuotationItem,
  IAccountQuotationsResult,
} from '@/api-v2/quotation/query'
import { changeQuotationAutoRenew } from '@/api-v2/quotation/mutations'
import quotationChangeRecords from './quotation-change-records.vue'

const { t } = useI18n()
const quotationChangeRecordsRef = ref()
const dialogTableVisible = ref(false)
const tradeAccount = ref('')
const isLoading = ref(false)

const canUpdateAutoRenew = computed(() =>
  Boolean(appStore.permissions['quo:cus:list:autoRenew:update'])
)
const canViewAutoRenew = computed(
  () => Boolean(appStore.permissions['quo:cus:list:autoRenew']) || canUpdateAutoRenew.value
)

function open(_tradeAccount: string) {
  tradeAccount.value = _tradeAccount
  dialogTableVisible.value = true
}

function onClosed() {
  tradeAccount.value = ''
  buyTableConfig.tableProps.data = []
  giftTableConfig.tableProps.data = []
}

const buyTableConfig = reactive<{
  tableProps: {
    emptyText: string
    maxHeight: number
    data: IAccountQuotationItem[]
  }
  customColumns: Record<string, any>[]
}>({
  tableProps: {
    emptyText: t('no_market_auth_data'),
    maxHeight: 280,
    data: [],
  },
  customColumns: [
    { label: t('serial_number'), type: 'index', minWidth: 50 },
    { label: t('market_auth_name'), prop: 'quotationName', minWidth: 150 },
    { label: t('effective_time'), prop: 'enableStart', minWidth: 150 },
    { label: t('expiration_time'), prop: 'enableEnd', minWidth: 150 },
    { slot: 'autoRenew' },
    { label: t('status'), prop: 'orderEnableStatus', minWidth: 100 },
    { slot: 'changeRecord' },
  ],
})

const giftTableConfig = reactive<{
  tableProps: {
    emptyText: string
    maxHeight: number
    data: IAccountQuotationItem[]
  }
  customColumns: Record<string, any>[]
}>({
  tableProps: {
    emptyText: t('no_market_auth_data'),
    maxHeight: 280,
    data: [],
  },
  customColumns: [
    { label: t('serial_number'), type: 'index', minWidth: 50 },
    { label: t('market_auth_name'), prop: 'quotationName', minWidth: 150 },
    { label: t('effective_time'), prop: 'enableStart', minWidth: 150 },
    { label: t('expiration_time'), prop: 'enableEnd', minWidth: 150 },
    { slot: 'autoRenew' },
    { label: t('status'), prop: 'orderEnableStatus', minWidth: 100 },
    { slot: 'changeRecord' },
  ],
})

function getTableLists(result?: IAccountQuotationsResult | Record<string, any>) {
  if (Array.isArray(result?.buyList) || Array.isArray(result?.giveList)) {
    return {
      buyList: result?.buyList || [],
      giftList: result?.giveList || [],
    }
  }

  return {
    buyList: [],
    giftList: [],
  }
}

const fetchTableData = () => {
  isLoading.value = true

  fetchAccountQuotations(tradeAccount.value)
    .then((res) => {
      const { buyList, giftList } = getTableLists(res.result)
      buyTableConfig.tableProps.data = buyList
      giftTableConfig.tableProps.data = giftList
    })
    .finally(() => {
      isLoading.value = false
    })
}

watch(
  tradeAccount,
  (newVal) => {
    if (newVal) {
      fetchTableData()
    } else {
      buyTableConfig.tableProps.data = []
      giftTableConfig.tableProps.data = []
    }
  },
  { immediate: true }
)

function hasAutoRenewValue(row: IAccountQuotationItem) {
  return typeof row.autoRenew === 'boolean'
}

function isAutoRenewEnabled(row: IAccountQuotationItem) {
  return Boolean(row.autoRenew)
}

/**
 * 自动续费切换
 */
function handleChangeAutoRenew(row: IAccountQuotationItem) {
  if (!canUpdateAutoRenew.value || !hasAutoRenewValue(row)) return

  const { tradeAccount, packageId } = row
  const currentlyEnabled = isAutoRenewEnabled(row)
  const targetAutoRenew = !currentlyEnabled

  const message = targetAutoRenew
    ? t('enable_auto_renewal_warning')
    : t('disable_auto_renewal_warning')

  ElMessageBox.confirm(message, t('tip'), {
    customClass: 'list-action-message-box',
    confirmButtonText: t('determine'),
    cancelButtonText: t('cancel'),
    type: 'warning',
  })
    .then(() => {
      const params = {
        autoRenew: targetAutoRenew,
        tradeAccount,
        packageId,
      }

      return changeQuotationAutoRenew(params)
    })
    .then(() => {
      fetchTableData()
    })
    .catch((error) => {
      // 用户点击取消或请求失败
      if (error !== 'cancel') {
        console.error(error)
      }
    })
}

function openChangeRecord(row: IAccountQuotationItem) {
  const { packageId, tradeAccount } = row
  const params = {
    packageId,
    tradeAccount,
  }

  quotationChangeRecordsRef.value.open(params)
}

defineExpose({
  open,
})
</script>

<style lang="scss" scoped>
.auth-table-section {
  margin-top: 14px;
}

.auth-table-title {
  margin-bottom: 8px;
  font-weight: 600;
}

.auto-renew-cell {
  display: flex;
  align-items: center;
  flex-direction: column;
}
</style>
