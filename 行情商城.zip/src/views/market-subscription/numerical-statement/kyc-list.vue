<template>
  <el-card>
    <base-filter :loading="isLoading" :config="filterConfig" @on-search="getData" @on-reset="resetHandle" />

    <div class="table">
      <base-table
        ref="tableRef"
        :height="600"
        :config="tableConfig"
        :pagination="pagination"
        :is-table-loading="isLoading"
      >
        <template #operation>
          <el-table-column :label="t('operate')" align="center">
            <template #default="scope">
              <el-button type="primary" link @click="toggleExpand(scope.row)">
                {{
                  expandedRows.includes(scope.row.tradeAccount)
                    ? t('collapse_details')
                    : t('expand_details')
                }}
              </el-button>
              <el-button type="primary" link @click="openUpdateRecordDialog(scope.row)">
                {{ t('update_records') }}
              </el-button>
              <el-button type="primary" link @click="downloadAgreement(scope.row)">
                {{ t('download_agreement') }}
              </el-button>
            </template>
          </el-table-column>
        </template>

        <template #expand>
          <el-table-column type="expand">
            <template #default="scope">
              <div class="expand-detail">
                <!-- 联络信息 -->
                <div class="detail-section">
                  <div class="detail-row">
                    <span class="detail-label">{{ t('contact_information') }}</span>
                    <div class="detail-content">
                      <div class="info-grid">
                        <div class="info-item">
                          <span class="info-label">{{ t('contact_phone') }}</span>
                          <span class="info-value">
                            {{ scope.row.mobile || EMPTY_PLACEHOLDER }}
                          </span>
                        </div>
                        <div class="info-item">
                          <span class="info-label">{{ t('contact_email') }}</span>
                          <span class="info-value">
                            {{ scope.row.email || EMPTY_PLACEHOLDER }}
                          </span>
                        </div>
                        <div class="info-item">
                          <span class="info-label">{{ t('contact_residential_address') }}</span>
                          <span class="info-value">
                            {{ scope.row.address || EMPTY_PLACEHOLDER }}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- 工作信息 -->
                <div class="detail-section">
                  <div class="detail-row">
                    <span class="detail-label">{{ t('work_information') }}</span>
                    <div class="detail-content">
                      <div
                        v-for="(group, groupIndex) in getWorkInfoList(scope.row)"
                        :key="groupIndex"
                        class="info-grid work-grid"
                        :class="{ 'mt-10': groupIndex > 0 }"
                      >
                        <div v-for="item in group" :key="item.key" class="info-item">
                          <span class="info-label">{{ item.label }}</span>
                          <span class="info-value">{{ item.value }}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- 问卷信息 -->
                <div class="detail-section">
                  <div class="detail-row">
                    <span class="detail-label">{{ t('questionnaire_information') }}</span>
                    <div class="detail-content">
                      <div
                        v-for="(group, groupIndex) in getAnswerGroups(scope.row.answer)"
                        :key="groupIndex"
                        class="info-grid questionnaire-grid"
                        :class="{ 'mt-10': groupIndex > 0 }"
                      >
                        <div v-for="item in group" :key="item.key" class="info-item">
                          <span class="info-label">{{ item.label }}</span>
                          <span class="info-value">
                            {{ item.value === true || item.value === 'true' ? t('yes') : t('no') }}
                          </span>
                        </div>
                      </div>
                      <div v-if="!scope.row.answer" class="no-data">
                        {{ t('no_questionnaire_data') }}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </template>
          </el-table-column>
        </template>
      </base-table>
    </div>

    <!-- 更新记录弹窗 -->
    <el-dialog
      v-model="updateRecordDialogVisible"
      :title="t('update_records')"
      width="800px"
      :close-on-click-modal="false"
    >
      <div class="update-record-header">
        <strong>{{ t('trading_account_colon') }} {{ currentRow?.tradeAccount }}</strong>
      </div>
      <el-table :data="updateRecordList" border max-height="400">
        <el-table-column type="index" :label="t('serial_number')" width="60" align="center" />
        <el-table-column
          prop="isPi"
          :label="t('system_evaluation_result')"
          width="120"
          align="center"
        >
          <template #default="{ row }">
            {{ row.isPi ? t('professional') : t('non_professional') }}
          </template>
        </el-table-column>
        <el-table-column prop="updateTime" :label="t('update_time')" width="160" align="center" />
        <el-table-column prop="isAgree" :label="t('user_agreement')" width="120" align="center">
          <template #default="{ row }">
            {{
              row.isAgree == null ? t('wait_to_agree') : row.isAgree ? t('agreed') : t('disagreed')
            }}
          </template>
        </el-table-column>
        <el-table-column
          prop="contentChangeDetail"
          :label="t('user_change_content')"
          align="center"
        >
          <template #default="{ row }">
            <div v-if="row.contentChangeDetail">
              <div v-for="(item, index) in parseChangeDetail(row.contentChangeDetail)" :key="index">
                {{ item }}
              </div>
            </div>
            <span v-else>-</span>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </el-card>
</template>

<script setup lang="ts">
import { reactive, onBeforeMount, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage } from 'element-plus'
import baseFilter from '@/components/base-filter/base-filter'
import baseTable from '@/components/base-table/base-table'
import {
  fetchKycUpdateRecords,
  fetchKycUpdateList,
  fetchKycUrlByCos,
} from '@/api-v2/quotation/mutations'
import { downloadFile } from '@/utils'

const { t } = useI18n()

/** 空值占位符 */
const EMPTY_PLACEHOLDER = '--'

const isLoading = ref(false)

// #region 展开行功能
const tableRef = ref<any>(null)
const expandedRows = ref<string[]>([])

/** 切换展开/收起详情 */
function toggleExpand(row: any) {
  const index = expandedRows.value.indexOf(row.tradeAccount)
  const isExpanded = index > -1
  if (isExpanded) {
    expandedRows.value.splice(index, 1)
  } else {
    expandedRows.value.push(row.tradeAccount)
  }
  // 使用 el-table 的 toggleRowExpansion 方法来控制展开
  tableRef.value?.baseTable?.toggleRowExpansion(row, !isExpanded)
}
// #endregion

// #region 更新记录弹窗
const updateRecordDialogVisible = ref(false)
const currentRow = ref<any>(null)
const updateRecordList = ref<any[]>([])

/** 打开更新记录弹窗 */
function openUpdateRecordDialog(row: any) {
  currentRow.value = row
  updateRecordDialogVisible.value = true
  // 获取更新记录数据
  fetchUpdateRecords(row.id)
}

/** 获取更新记录 */
function fetchUpdateRecords(id: string) {
  fetchKycUpdateList({
    id,
    pageNum: 1,
    pageSize: 1000,
  }).then((res: any) => {
    updateRecordList.value = res.result.records || []
  })
}

/** 解析userData字段 */
function parseUserData(userData: string): Record<string, any> {
  if (!userData) return {}
  try {
    return JSON.parse(userData)
  } catch (e) {
    console.error('Parse userData field failed:', e)
    return {}
  }
}

/** 解析用户变更内容 */
function parseChangeDetail(detail: string): string[] {
  if (!detail) return []
  // 移除首尾的方括号，然后按 ", " 分割
  const content = detail.replace(/^\[|\]$/g, '')
  return content.split(', ').filter((item) => item.trim())
}

/** 解析answer字段，返回问卷问题列表 */
function parseAnswerQuestions(answer: string): { key: string; label: string; value: boolean }[] {
  if (!answer) return []
  try {
    const parsed = JSON.parse(answer)
    const questions: { key: string; label: string; value: boolean; index: number }[] = []

    for (const key in parsed) {
      // 匹配 question_1, question_2 等格式
      const match = key.match(/question_(\d+)/)
      if (match) {
        const index = parseInt(match[1], 10)
        questions.push({
          key,
          label: `${t('questionnaire_question')}${index}`,
          value: parsed[key],
          index,
        })
      }
    }

    // 按问题序号排序
    questions.sort((a, b) => a.index - b.index)
    return questions.map(({ key, label, value }) => ({ key, label, value }))
  } catch (e) {
    console.error('Parse answer field failed:', e)
    return []
  }
}

/** 将问卷问题按每组5个分组显示 */
function getAnswerGroups(
  answer: string
): { key: string; label: string; value: boolean | string }[][] {
  const questions = parseAnswerQuestions(answer)
  const groups: { key: string; label: string; value: boolean }[][] = []
  const groupSize = 7

  for (let i = 0; i < questions.length; i += groupSize) {
    groups.push(questions.slice(i, i + groupSize))
  }

  return groups
}
// #endregion

// #region 表格配置
/** 空值占位符格式化 */
const emptyFormatter = (_: any, __: any, val: any) => val || EMPTY_PLACEHOLDER

const tableConfig = reactive({
  tableProps: {
    data: [] as any[],
    rowKey: (row: any) => row.tradeAccount,
  },
  customColumns: [
    { label: t('client_id'), prop: 'tradeAccount', formatter: emptyFormatter },
    {
      label: t('user_status_identity'),
      prop: 'isPi',
      formatter: (row: any) =>
        row.isPi ? t('professional_investor') : t('non_professional_investor'),
    },
    { label: t('first_submission_time'), prop: 'firstAuthTime', formatter: emptyFormatter },
    { label: t('last_update_time'), prop: 'updateTime', formatter: emptyFormatter },
    { slot: 'operation' },
    { slot: 'expand' },
  ],
})
// #endregion

// 表单配置
const formItems = [
  {
    prop: 'createDate',
    label: t('first_submission_time'),
    innerEl: { elType: 'datePicke', props: { type: 'daterange', valueFormat: 'YYYY-MM-DD' } },
  },
  {
    prop: 'keyword',
    label: '',
    innerEl: {
      elType: 'input',
      props: { placeholder: t('please_enter_user_account_keywords') },
    },
  },
  {
    prop: 'isPi',
    label: '',
    innerEl: {
      elType: 'select',
      options: [
        { label: t('professional_investor'), value: 1 },
        { label: t('non_professional_investor'), value: 0 },
      ],
      props: { placeholder: t('please_select_user_identity') },
    },
  },
]

/** 表单数据 */
const filterConfig = reactive({
  formProps: {
    model: {},
  },
  formItems,
})

const pagination: Record<string, any> = reactive({
  paginationProps: {
    currentPage: 1,
    pageSize: 20,
    total: 0,
  },
  paginationEvent: {
    onSizeChange: (v: number | string) => {
      pagination.paginationProps.pageSize = v
      getData()
    },
    onCurrentChange: (v: number | string) => {
      pagination.paginationProps.currentPage = v
      getData()
    },
  },
})

/**
 * 获取表格数据
 * @param data 传入数据
 */
function getData() {
  isLoading.value = true
  const page: Record<string, any> = {}
  page.pageNum = pagination.paginationProps.currentPage
  page.pageSize = pagination.paginationProps.pageSize

  const params: any = { ...filterConfig.formProps.model }
  // 格式化时间
  if (params.createDate) {
    params.beginDate = params.createDate[0]
    params.endDate = params.createDate[1]
    delete params.createDate
  }

  fetchKycUpdateRecords({ ...page, ...params })
    .then((res: Record<string, any>) => {
      tableConfig.tableProps.data = res.result.records
      pagination.paginationProps.currentPage = res.result.current
      pagination.paginationProps.pageSize = res.result.size
      pagination.paginationProps.total = res.result.total
      isLoading.value = false
      // 清空展开行状态
      expandedRows.value = []
    })
    .catch((err) => {
      console.log(err)
      isLoading.value = false
    })
}

function resetHandle() {
  const page: Record<string, any> = {}
  page.pageNum = pagination.paginationProps.currentPage
  page.pageSize = pagination.paginationProps.pageSize

  const data: Record<string, any> = filterConfig.formProps.model
  delete data.createDate
  delete data.keyword
  getData()
}

async function downloadAgreement(row: Record<string, any>) {
  try {
    await fetchKycUrlByCos(
      {
        tradeAccount: row.tradeAccount,
      },
      `Electronic Subscriber Agreement B-1_${row.tradeAccount}.pdf`
    )
  } catch (error) {
    console.error('下载协议文件请求错误：', error)
  }
}

function getWorkInfoList(row: any) {
  const userData = parseUserData(row.userData)
  const occupationLowerCase = String(userData.occupation).toLowerCase()

  // employed：受雇 Employed(full-time)
  if (occupationLowerCase === 'employed' || userData.occupation === 0) {
    return [
      [
        {
          key: 'subscriberName',
          label: t('subscriber_name'),
          value: userData.subscriberName || EMPTY_PLACEHOLDER,
        },
        {
          key: 'subscriberAddress',
          label: t('subscriber_residential_address'),
          value: userData.subscriberAddress || EMPTY_PLACEHOLDER,
        },
        {
          key: 'occupationName',
          label: t('occupations'),
          value: userData.occupationName || EMPTY_PLACEHOLDER,
        },
        {
          key: 'industry',
          label: t('industry_business'),
          value: userData.industry || EMPTY_PLACEHOLDER,
        },
      ],
      [
        {
          key: 'department',
          label: t('department_name_en'),
          value: userData.department || EMPTY_PLACEHOLDER,
        },
        {
          key: 'title',
          label: t('position_name'),
          value: userData.title || EMPTY_PLACEHOLDER,
        },
        {
          key: 'employerName',
          label: t('name_of_employer'),
          value: userData.employerName || EMPTY_PLACEHOLDER,
        },
        {
          key: 'employerAddress',
          label: t('address_of_employer'),
          value: userData.employerAddress || EMPTY_PLACEHOLDER,
        },
      ],
    ]
  }

  // selfEmployed: 自雇Self-employed
  if (occupationLowerCase === 'selfemployed' || userData.occupation === 1) {
    return [
      [
        {
          key: 'subscriberName',
          label: t('subscriber_name'),
          value: userData.subscriberName || EMPTY_PLACEHOLDER,
        },
        {
          key: 'subscriberAddress',
          label: t('subscriber_residential_address'),
          value: userData.subscriberAddress || EMPTY_PLACEHOLDER,
        },
        {
          key: 'occupationName',
          label: t('occupations'),
          value: userData.occupationName || EMPTY_PLACEHOLDER,
        },
        {
          key: 'industry',
          label: t('industry_business'),
          value: userData.industry || EMPTY_PLACEHOLDER,
        },
      ],
      [
        {
          key: 'employerName',
          label: t('name_of_employer'),
          value: userData.employerName || EMPTY_PLACEHOLDER,
        },
        {
          key: 'employerAddress',
          label: t('address_of_employer'),
          value: userData.employerAddress || EMPTY_PLACEHOLDER,
        },
        {
          key: 'selfEmploymentStatus',
          label: t('self_employed_information'),
          value: userData.selfEmploymentStatus || EMPTY_PLACEHOLDER,
        },
      ],
    ]
  }

  return [
    [
      {
        key: 'subscriberName',
        label: t('subscriber_name'),
        value: userData.subscriberName || EMPTY_PLACEHOLDER,
      },
      {
        key: 'subscriberAddress',
        label: t('subscriber_residential_address'),
        value: userData.subscriberAddress || EMPTY_PLACEHOLDER,
      },
      {
        key: 'occupationName',
        label: t('occupations'),
        value: userData.occupationName || EMPTY_PLACEHOLDER,
      },
    ],
  ]
}

onBeforeMount(() => {
  getData()
})
</script>

<style lang="scss" scoped>
// 隐藏 expand 列的箭头图标
:deep(.el-table__expand-column) {
  .cell {
    display: none;
  }
}

.expand-detail {
  width: 90%;
  margin: 10px auto;

  .mt-10 {
    margin-top: 10px;
  }
}

.detail-section {
  margin-bottom: 15px;

  &:last-child {
    margin-bottom: 0;
  }
}

.detail-row {
  display: flex;
  align-items: flex-start;
}

.detail-label {
  width: 80px;
  padding-top: 8px;
  color: #666;
  font-size: 14px;
}

.detail-content {
  flex: 1;

  .no-data {
    text-align: center;
    color: #999;
    padding: 10px;
  }
}

.info-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  overflow: hidden;

  &.questionnaire-grid {
    grid-template-columns: repeat(7, 1fr);
  }

  &.work-grid {
    grid-template-columns: repeat(4, 1fr);
  }
}

.info-item {
  display: flex;
  flex-direction: column;
  border: 1px solid #ebeef5;

  & + & {
    border-left: none;
  }
}

.info-label,
.info-value {
  padding: 10px 12px;
}

.info-label {
  border-bottom: 1px solid #ebeef5;
  background-color: #fafafa;
  color: #909399;
}

.info-value {
  color: #303133;
}

.update-record-header {
  padding: 10px 0 20px;
  color: #333;
  font-size: 14px;
}
</style>
