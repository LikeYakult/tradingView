<template>
  <!-- 统计报表-套餐订购报表 -->
  <el-card>
    <base-filter :loading="isLoading" :config="filterConfig" @on-search="getData" @on-reset="resetHandle" />

    <div class="operate-buttons">
      <el-button plain
        v-permission="'quo:packageBuy:list:export'"
        :loading="exportLoading"
        type="primary"
        size="small"
        class="export-button"
        @click="exportFunc"
        >{{ $t('export') }}</el-button
      >
    </div>
    <div class="table">
      <base-table :config="tableConfig" :pagination="pagination" :is-table-loading="isLoading">
        <template #state>
          <el-table-column :label="$t('state')" width="100">
            <template #default="scope">
              <span>{{
                packageEnableStatusOptions.find((item) => item.value === scope.row.enable)?.label ||
                scope.row.state
              }}</span>
            </template>
          </el-table-column>
        </template>
        <template #currency>
          <el-table-column :label="$t('currency')" width="100">
            <template #default="scope">
              <span>{{
                currencyOptions.find((item) => item.value === scope.row.currency)?.label ||
                scope.row.currency
              }}</span>
            </template>
          </el-table-column>
        </template>
      </base-table>
    </div>
  </el-card>
</template>

<script setup lang="ts">
import { reactive, onBeforeMount, ref, Ref } from 'vue'
import { useI18n } from 'vue-i18n'
import baseFilter from '@/components/base-filter/base-filter'
import baseTable from '@/components/base-table/base-table'

import { packageBuyList, orderListExport } from '@/api-v2/quotation'
import { fetchDicts } from '@/api-v2/quotation/query'
import { SelectOptions } from '@/types'
import { extractDict } from '@/utils/options-dictionary'

// #region options
const packageEnableStatusOptions = ref<SelectOptions>([])
const currencyOptions = ref<SelectOptions>([])

function initDicts() {
  const dictPairs: [string, Ref<SelectOptions>][] = [
    ['package_enable_staus', packageEnableStatusOptions],
    ['currency', currencyOptions],
  ]

  const keys = dictPairs.map((item) => item[0])

  fetchDicts(keys).then((res) => {
    dictPairs.forEach((item) => {
      extractDict(res?.result?.[item[0]], item[1])
    })
  })
}
// #endregion

const { t } = useI18n()

const isLoading = ref(false)
const ordering = ref({
  asc: true,
  column: '',
})

// 表单配置
const formItems = [
  {
    prop: 'createDate',
    label: t('statistical_interval'),
    innerEl: { elType: 'datePicke', props: { type: 'daterange', valueFormat: 'YYYY-MM-DD' } },
  },
  {
    prop: 'keyword',
    label: t('package_info'),
    innerEl: {
      elType: 'input',
      props: { placeholder: t('please_enter_package_name_id'), maxlength: 32 },
    },
  },
  {
    prop: 'enable',
    label: t('state'),
    innerEl: {
      elType: 'select',
      options: packageEnableStatusOptions,
    },
  },
  {
    prop: 'currency',
    label: t('currency'),
    innerEl: {
      elType: 'select',
      options: currencyOptions,
    },
  },
]

const tableConfig = reactive({
  tableProps: {
    data: [],
    height: '580',
  },
  tableEvent: {
    onSortChange: (column: Record<string, any>) => {
      const { order, prop } = column
      ordering.value.column = ''
      pagination.paginationProps.currentPage = 1

      if (order) {
        ordering.value = {
          asc: order === 'ascending',
          column: prop,
        }
      }
      return getData()
    },
  },
  customColumns: [
    { label: t('package_id'), prop: 'packageId' },
    { label: t('package_name'), prop: 'packageName' },
    { slot: 'state' },
    { label: t('related_products'), prop: 'marketName' },
    { label: t('total_ordering_quantity'), prop: 'buyNum', sortable: 'custom' },
    { label: t('presented_total_number'), prop: 'giveNum', sortable: 'custom' },
    { slot: 'currency' },
    { label: t('presented_total_money'), prop: 'giveAmount', sortable: 'custom' },
    { label: t('total_amount_payable_package'), prop: 'tbcAmount', sortable: 'custom' },
    { label: t('total_amount_paid_package'), prop: 'buyAmount', sortable: 'custom' },
  ],
})

/** 表单数据 */
const filterConfig = reactive({
  formProps: {
    model: {},
  },
  formItems,
})
const exportLoading = ref(false)

/** 导出接口 */
function exportFunc() {
  exportLoading.value = true

  const params: any = { ...filterConfig.formProps.model }
  if (ordering.value.column) {
    Object.assign(params, {
      orders: [ordering.value],
    })
  }
  // 格式化时间
  if (params.createDate) {
    params.createDateStart = params.createDate[0]
    params.createDateEnd = params.createDate[1]
    delete params.createDate
  }

  orderListExport(params, `${t('package_order_report')}.xls`).then(() => {
    exportLoading.value = false
  })
}

const pagination: Record<string, any> = reactive({
  paginationProps: {
    currentPage: 1,
    pageSize: 20,
    total: 0,
  },
  paginationEvent: {
    onSizeChange: (v: number | string) => {
      pagination.paginationProps.pageSize = v
      getData()
    },
    onCurrentChange: (v: number | string) => {
      pagination.paginationProps.currentPage = v
      getData()
    },
  },
})

/**
 * 获取表格数据
 * @param data 传入数据
 */
function getData() {
  isLoading.value = true
  const page: Record<string, any> = {}
  page.pageNum = pagination.paginationProps.currentPage
  page.pageSize = pagination.paginationProps.pageSize

  if (ordering.value.column) {
    Object.assign(page, {
      orders: [ordering.value],
    })
  }

  const params: any = { ...filterConfig.formProps.model }
  // 格式化时间
  if (params.createDate) {
    params.createDateStart = params.createDate[0]
    params.createDateEnd = params.createDate[1]
    delete params.createDate
  }

  packageBuyList({ ...page, ...params })
    .then((res: Record<string, any>) => {
      tableConfig.tableProps.data = res.result.records
      pagination.paginationProps.currentPage = res.result.current
      pagination.paginationProps.pageSize = res.result.size
      pagination.paginationProps.total = res.result.total
      isLoading.value = false
    })
    .catch((err) => {
      console.log(err)
      isLoading.value = false
    })
}

function resetHandle() {
  const page: Record<string, any> = {}
  page.pageNum = pagination.paginationProps.currentPage
  page.pageSize = pagination.paginationProps.pageSize
  const data: Record<string, any> = filterConfig.formProps.model
  delete data.createDate
  packageBuyList({ ...page, ...data }).then((res) => {
    tableConfig.tableProps.data = res.result.records
    pagination.paginationProps.currentPage = res.result.current
    pagination.paginationProps.pageSize = res.result.size
    pagination.paginationProps.total = res.result.total
  })
}

onBeforeMount(() => {
  getData()
  initDicts()
})
</script>
