<template>
  <!-- 统计报表-扣费记录 -->
  <el-card>
    <base-filter :loading="isLoading" :config="filterConfig" @on-search="searchHandle" @on-reset="resetHandle" />
    <div class="operate-buttons">
      <el-button plain
        v-permission="'quo:pay:list:export'"
        :loading="exportLoading"
        type="primary"
        size="small"
        class="export-button"
        @click="exportFunc"
        >{{ $t('export') }}</el-button
      >
    </div>
    <div class="table">
      <base-table :config="tableConfig" :pagination="pagination" :is-table-loading="isLoading">
        <template #channel>
          <el-table-column :label="$t('deduction_channels')" width="100">
            <template #default="scope">
              <span>{{ channelText(scope.row.channel) }}</span>
            </template>
          </el-table-column>
        </template>
        <template #currency>
          <el-table-column :label="$t('currency')" width="100">
            <template #default="scope">
              <span>{{
                currencyOptions.find((item) => item.value === scope.row.currency)?.label ||
                scope.row.currency
              }}</span>
            </template>
          </el-table-column>
        </template>
        <template #amountSlot>
          <el-table-column :label="$t('amount')" width="100">
            <template #default="scope">
              <span>{{ scope.row.amount ? Number(scope.row.amount).toFixed(2) : '--' }}</span>
            </template>
          </el-table-column>
        </template>
      </base-table>
    </div>
  </el-card>
</template>

<script setup lang="ts">
import { reactive, onBeforeMount, ref, Ref } from 'vue'
import { useI18n } from 'vue-i18n'
import baseFilter from '@/components/base-filter/base-filter'
import baseTable from '@/components/base-table/base-table'

import { payList } from '@/api-v2/quotation/statistics'
import { reportExportPayList } from '@/api-v2/quotation/order'

import { formToParams } from '@/utils'
import { fetchDicts } from '@/api-v2/quotation/query'
import { SelectOptions } from '@/types'
import { extractDict } from '@/utils/options-dictionary'

// #region options
const payChannelOptions = ref<SelectOptions>([])
const currencyOptions = ref<SelectOptions>([])

function initDicts() {
  const dictPairs: [string, Ref<SelectOptions>][] = [
    ['pay_channel', payChannelOptions],
    ['currency', currencyOptions],
  ]

  const keys = dictPairs.map((item) => item[0])

  fetchDicts(keys).then((res) => {
    dictPairs.forEach((item) => {
      extractDict(res?.result?.[item[0]], item[1])
    })
  })
}
// #endregion

const { t } = useI18n()
const isLoading = ref(false)
const ordering = ref({
  asc: true,
  column: '',
})

// 表单配置
const formItems = [
  {
    prop: 'keyword',
    label: t('user_account_keyword'),
    innerEl: {
      elType: 'input',
      props: { placeholder: t('please_enter_user_account_phone'), maxlength: 32 },
    },
  },
  {
    prop: 'packageKeyword',
    label: t('package'),
    innerEl: {
      elType: 'input',
      props: { placeholder: t('please_enter_package_name'), maxlength: 32 },
    },
  },
  {
    prop: 'payDate',
    label: t('deduction_time'),
    innerEl: { elType: 'datePicke', props: { type: 'daterange', valueFormat: 'YYYY-MM-DD' } },
  },
  {
    prop: 'channel',
    label: t('deduction_channels'),
    innerEl: {
      elType: 'select',
      options: payChannelOptions,
    },
  },
  {
    prop: 'currency',
    label: t('currency'),
    innerEl: {
      elType: 'select',
      options: currencyOptions,
    },
  },
  {
    prop: 'orderId',
    label: t('order_number'),
    innerEl: {
      elType: 'input',
      props: { placeholder: t('please_enter_order_number'), maxlength: 32 },
    },
  },
  {
    prop: 'payId',
    label: t('deductions_order'),
    innerEl: {
      elType: 'input',
      props: { placeholder: t('please_enter_deductions_order'), maxlength: 32 },
    },
  },
]

const tableConfig = reactive({
  tableProps: {
    data: [],
    height: '580',
  },
  tableEvent: {
    onSortChange: (column: Record<string, any>) => {
      const { order, prop } = column
      ordering.value.column = ''
      pagination.paginationProps.currentPage = 1

      if (order) {
        ordering.value = {
          asc: order === 'ascending',
          column: prop,
        }
      }
      return getData()
    },
  },
  customColumns: [
    { label: t('deductions_order'), prop: 'payId' },
    { label: t('order_number'), prop: 'orderId' },
    { label: t('mobile_number'), prop: 'mobile', sortable: 'custom' },
    { label: t('internet_account'), prop: 'cusNo', sortable: 'custom' },
    { label: t('transaction_account'), prop: 'tradeAccount', sortable: 'custom' },
    { label: t('package_name'), prop: 'packageName', sortable: 'custom' },
    {
      label: t('amount'),
      prop: 'amount',
      sortable: 'custom',
      slot: 'amountSlot',
    },
    { slot: 'currency' },
    { label: t('deduction_time'), prop: 'payTime', sortable: 'custom', width: 160 },
    { slot: 'channel' },
    { label: t('state'), prop: 'statusName' },
  ],
})

/** 表单数据 */
const filterConfig = reactive({
  formProps: {
    model: {
      registerTime: '',
      registerSource: '',
      status: '',
      account: '',
      keyword: '',
      payStart: '',
      payEnd: '',
      payDate: [],
    },
  },
  formItems,
})
const exportLoading = ref(false)

/** 导出接口 */
function exportFunc() {
  exportLoading.value = true

  const aParams = formToParams(filterConfig.formProps.model)

  const params = { ...aParams }
  if (ordering.value.column) {
    Object.assign(params, {
      orders: [ordering.value],
    })
  }
  // 格式化时间
  if (params.payDate) {
    params.payDateStart = params.payDate[0]
    params.payDateEnd = params.payDate[1]
    delete params.payDate
  }

  console.log('params>>>', params)
  reportExportPayList(params).then(() => {
    exportLoading.value = false
  })
}

const pagination: Record<string, any> = reactive({
  paginationProps: {
    currentPage: 1,
    pageSize: 20,
    total: 0,
  },
  paginationEvent: {
    onSizeChange: (v: number | string) => {
      pagination.paginationProps.pageSize = v
      getData()
    },
    onCurrentChange: (v: number | string) => {
      pagination.paginationProps.currentPage = v
      getData()
    },
  },
})

/**
 * 获取表格数据
 * @param data 传入数据
 */
function getData() {
  isLoading.value = true
  const data = formToParams(filterConfig.formProps.model)
  const page: Record<string, any> = {}
  page.pageNum = pagination.paginationProps.currentPage
  page.pageSize = pagination.paginationProps.pageSize

  if (ordering.value.column) {
    Object.assign(page, {
      orders: [ordering.value],
    })
  }
  // 格式化时间
  if (data.payDate) {
    data.payDateStart = data.payDate[0]
    data.payDateEnd = data.payDate[1]
    delete data.payDate
  }

  payList({ ...page, ...data })
    .then((res) => {
      tableConfig.tableProps.data = res.result.records
      pagination.paginationProps.currentPage = res.result.current
      pagination.paginationProps.pageSize = res.result.size
      pagination.paginationProps.total = res.result.total
      isLoading.value = false
    })
    .catch((err) => {
      console.log(err)
      isLoading.value = false
    })
}

function searchHandle() {
  getData()
}

function resetHandle() {
  getData()
}

onBeforeMount(() => {
  initDicts()
  getData()
})
const channelText = (channel: number) => {
  const text = [t('counter'), t('artificial')]
  return text[channel - 1]
}
</script>
