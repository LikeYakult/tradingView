<template>
  <div class="page-container">
    操作日志
    <el-button v-permission="'sys:home:add'">123</el-button>
    <el-icon><i-alarm-clock /></el-icon>
  </div>
</template>
