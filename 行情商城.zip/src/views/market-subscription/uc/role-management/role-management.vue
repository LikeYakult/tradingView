<template>
  <div class="page-container">
    <baseFilter :loading="isLoading" :config="filterConfig" @onSearch="searchHandle" @onReset="resetHandle"></baseFilter>
    <div class="operate-buttons">
      <el-button class="toolbar-add-button" type="primary" @click="openNewRolesDialog">{{
        $t('new')
      }}</el-button>
      <action-confirm :title="$t('sure_to_batch_deleted')" @confirm="batchDeleteConfirm">
        <template #reference
          ><el-button plain type="info">{{ $t('batch_deleted') }}</el-button></template
        >
      </action-confirm>
    </div>
    <baseTable :is-table-loading="isLoading" ref="tablePaginationRef" :config="tableConfig" :pagination="paginationConfig">
      <template v-slot:operate>
        <el-table-column :label="$t('operate')" align="center">
          <template v-slot>
            <span @click="openModifyPermissionsDialog" class="text-primary mr10">{{
              $t('permissions')
            }}</span>
            <span @click="openEditRolesDialog" class="text-primary mr10">{{ $t('modify') }}</span>
            <action-confirm :title="$t('determine_deleted')" @confirm="deleteRoleConfirm">
              <template #reference>
                <span class="text-primary mr10">{{ $t('delete') }}</span>
              </template>
            </action-confirm>
          </template>
        </el-table-column>
      </template>
    </baseTable>
    <!-- 新建/修改角色 -->
    <el-dialog
      v-model="isShowNewEditRoles"
      width="30%"
      :title="newEditRolesType === 'new' ? $t('new_role') : $t('modify_role')"
      center
      append-to-body
    >
      <el-form
        ref="newEditRolesRef"
        :model="newEditRolesForm"
        :rules="newEditRolesRule"
        label-width="100px"
        style="width: 80%; margin: 0 auto"
      >
        <el-form-item :label="`${$t('superior_role')}：`" prop="parentId">
          <el-select v-model="newEditRolesForm.parentId">
            <el-option
              v-for="roleItem of superiorRoleList"
              :key="roleItem.value"
              :label="roleItem.label"
              :value="roleItem.value"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="`${$t('role_name')}：`" prop="name">
          <el-input v-model="newEditRolesForm.name"></el-input>
        </el-form-item>
        <el-form-item
          :label="`${$t('permissions')}：`"
          prop="menuIds"
          v-if="newEditRolesType === 'new'"
        >
          <el-button @click="clickSettingPermission">{{ $t('click_settings') }}</el-button>
        </el-form-item>
        <el-form-item :label="`${$t('remarks')}：`" prop="remark">
          <el-input v-model="newEditRolesForm.remark"></el-input>
        </el-form-item>
      </el-form>
      <el-dialog v-model="isShowNewEditRolesInner" :title="$t('permissions')" center append-to-body>
        <el-tree
          ref="permissionsTreeRef"
          node-key="id"
          :data="permissionsTree"
          :default-checked-keys="treeCheckedList"
          :props="defaultTreeProps"
          show-checkbox
        />
        <template #footer>
          <span class="dialog-footer">
            <el-button type="primary" @click="permissionsTreeConfirm">{{
              $t('determine')
            }}</el-button>
            <el-button type="primary" @click="isShowNewEditRolesInner = false">{{
              $t('cancel')
            }}</el-button>
          </span>
        </template>
      </el-dialog>
      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" @click="toNewEditRoles">{{ $t('determine') }}</el-button>
          <el-button @click="isShowNewEditRoles = false">{{ $t('cancel') }}</el-button>
        </span>
      </template>
    </el-dialog>
    <!-- 修改权限 -->
    <el-dialog
      v-model="isShowModifyPermissions"
      :title="$t('modify_permissions')"
      @close="modifyPermissionsClose"
      center
      append-to-body
    >
      <el-tree
        ref="permissionsTreeRef"
        node-key="id"
        :data="permissionsTree"
        :default-checked-keys="treeCheckedList"
        :props="defaultTreeProps"
        show-checkbox
      />
      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" @click="modifyPermissionsConfirm">{{
            $t('determine')
          }}</el-button>
          <el-button type="primary" @click="isShowModifyPermissions = false">{{
            $t('cancel')
          }}</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>
<script lang="ts">
import { defineComponent, reactive, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage, ElMessageBox } from 'element-plus'
import baseFilter from '@/components/base-filter/base-filter'
import baseTable from '@/components/base-table/base-table'

import {
  getUserRoleList,
  getUserManagementRoleList,
  deleteRole,
  batchDeleteRole,
  getRolePermissions,
  newRolesApi,
  editRolesApi,
  modifyPermissions,
} from '@/api/subPro/subPro'

export default defineComponent({
  name: 'account-role-management',
  components: {
    baseFilter,
    baseTable,
  },
  setup() {
    const { t } = useI18n()
    const isLoading = ref(false)
    const tablePaginationRef = ref()
    const pageSize = ref(20)
    const currentPage = ref(1)
    const searchData = ref()

    /* 表格-start */
    // 选中行数
    let tableSelectionRows: any[] = []
    const tableSelectionChange = (selection: []) => {
      tableSelectionRows = selection
    }
    // 选中行
    const selectedRow = ref()
    const tableConfig = reactive({
      tableProps: {
        data: <{ date: string; name: string; address: string }[]>[],
      },
      tableEvent: {
        onSelectionChange: tableSelectionChange,
        onRowClick: (row: object) => {
          selectedRow.value = row
        },
      },
      customColumns: [
        { type: 'selection', align: 'center' },
        { label: t('add_time'), prop: 'createTime' },
        { label: t('role_name'), prop: 'name' },
        { label: t('superior_role'), prop: 'parentName' },
        { label: t('remarks'), prop: 'remark' },
        { slot: 'operate' },
      ],
    })
    /* 表格-end */

    /* 分页-start */
    const paginationConfig = ref({
      paginationProps: { total: 0, 'page-size': 20 },
      paginationEvent: {
        onSizeChange: handleSizeChange,
        onCurrentChange: handleCurrentChange,
      },
    })
    function handleSizeChange(currentSize: number) {
      paginationConfig.value.paginationProps['page-size'] = currentSize
      tablePaginationRef.value?.toFirstPage()
      currentPage.value = 1
      pageSize.value = currentSize
      toGetUserRoleList()
    }
    function handleCurrentChange(theCurrentPage: number) {
      currentPage.value = theCurrentPage
      toGetUserRoleList()
    }
    /* 分页-end */

    function toGetUserRoleList() {
      isLoading.value = true
      const params = {
        ...searchData.value,
        pageSize: pageSize.value,
        pageNum: currentPage.value,
      }
      getUserRoleList(params).then((res: { [key: string]: any }) => {
        tableConfig.tableProps.data = res.result?.records
        paginationConfig.value.paginationProps.total = res.result?.total || 0
      }).finally(() => {
        isLoading.value = false
      })
    }
    toGetUserRoleList()

    /* 过滤表单-start */
    const filterConfig = ref({
      formProps: {
        model: {
          keyword: '',
          parentId: '',
        },
      },
      formItems: [
        {
          prop: 'keyword',
          label: t('role_name'),
          innerEl: {
            elType: 'input',
            props: { placeholder: t('please_enter_role_name') },
          },
        },
        {
          prop: 'parentId',
          label: t('superior_role'),
          innerEl: {
            elType: 'select',
            options: [],
          },
        },
      ],
    })
    const superiorRoleList = ref()
    getUserManagementRoleList({
      pageSize: 100000,
    }).then((res) => {
      const options = res.result?.records.map((record: { [key: string]: any }) => ({
        label: record.name,
        value: record.id,
      }))
      superiorRoleList.value = options
      filterConfig.value.formItems[1].innerEl.options = options
    })
    const searchHandle = (data: { [name: string]: any }) => {
      currentPage.value = 1
      tablePaginationRef.value?.toFirstPage()
      // 携带自定义插槽数据并请求查询
      searchData.value = { ...data }
      toGetUserRoleList()
    }
    const resetHandle = (data: { [name: string]: any }) => {
      currentPage.value = 1
      tablePaginationRef.value?.toFirstPage()
      // 重置自定义插槽数据并请求查询
      searchData.value = { ...data }
      toGetUserRoleList()
    }
    /* 过滤表单-end */

    // 批量删除
    const toBatchDeleteRole = () => {
      if (tableSelectionRows?.length === 0) {
        ElMessageBox.alert(t('select_batch_delete_data'), t('tip'), {
          confirmButtonText: t('determine'),
          type: 'error',
        })
        return
      }
      const ids = tableSelectionRows.map((item) => item.id)
      return batchDeleteRole({ ids }).then(() => {
        ElMessage.success(t('delete_success'))
        toGetUserRoleList()
      })
    }
    const batchDeleteConfirm = () => {
      toBatchDeleteRole()
      return true
    }

    /* 新建/修改角色-start */
    const isShowNewEditRoles = ref(false)
    const isShowNewEditRolesInner = ref(false)
    const newEditRolesRef = ref()
    const newEditRolesForm = ref({
      parentId: '',
      name: '',
      remark: '',
    })
    const newEditRolesRule = {
      parentId: [{ required: true, message: t('please_select_superior_role'), trigger: 'change' }],
      name: [{ required: true, message: t('please_enter_role_name'), trigger: 'blur' }],
    }
    // 权限树
    const permissionsTreeRef = ref()
    const defaultTreeProps = {
      children: 'children',
      label: 'name',
      disabled: 'disabled',
    }
    // 选中的树节点
    const treeCheckedList = ref([])
    const permissionsTree = ref()
    const toGetRolePermissions = (params?: object) => {
      getRolePermissions(params).then((res) => {
        permissionsTree.value = res.result?.permissions
        treeCheckedList.value = res.result?.checkedList || []
      })
    }
    const clickSettingPermission = () => {
      isShowNewEditRolesInner.value = true
    }
    const permissionsTreeConfirm = () => {
      const checkedKeys = permissionsTreeRef.value.getCheckedKeys()
      treeCheckedList.value = checkedKeys
      isShowNewEditRolesInner.value = false
    }
    // 打开新建角色对话框
    const newEditRolesType = ref('new')
    const openNewRolesDialog = () => {
      newEditRolesType.value = 'new'
      isShowNewEditRoles.value = true
      newEditRolesRef.value?.resetFields()
      toGetRolePermissions()
    }
    const toNewEditRoles = () => {
      newEditRolesRef.value.validate((validate: boolean) => {
        if (validate) {
          const params = {
            menuIds: treeCheckedList.value,
            ...newEditRolesForm.value,
          }
          if (newEditRolesType.value === 'new') {
            if (treeCheckedList.value?.length === 0 || treeCheckedList.value === null) {
              ElMessageBox.alert(t('please_select_permissions'), t('tip'), {
                confirmButtonText: t('determine'),
                type: 'error',
              })
              return
            }
            newRolesApi(params).then(() => {
              ElMessage.success(t('add_success'))
              isShowNewEditRoles.value = false
              toGetUserRoleList()
            })
          } else if (newEditRolesType.value === 'edit') {
            const { id } = selectedRow.value
            editRolesApi({ id, ...params }).then(() => {
              ElMessage.success(t('modify_success'))
              isShowNewEditRoles.value = false
              toGetUserRoleList()
            })
          }
        }
      })
    }

    const openEditRolesDialog = () => {
      newEditRolesType.value = 'edit'
      setTimeout(() => {
        const { parentId, name, remark } = selectedRow.value
        isShowNewEditRoles.value = true
        newEditRolesForm.value.parentId = parentId
        newEditRolesForm.value.name = name
        newEditRolesForm.value.remark = remark
      }, 20)
    }
    /* 新建/修改角色-end */

    /* 操作列 */
    // 修改权限
    const isShowModifyPermissions = ref(false)
    const openModifyPermissionsDialog = () => {
      treeCheckedList.value = []
      setTimeout(() => {
        const { id } = selectedRow.value
        toGetRolePermissions({ id })
        isShowModifyPermissions.value = true
      }, 20)
    }
    const modifyPermissionsConfirm = () => {
      const { id } = selectedRow.value
      const treeCheckedArr = permissionsTreeRef.value.getCheckedKeys()
      modifyPermissions({ id, menuIds: treeCheckedArr }).then(() => {
        ElMessage.success(t('modify_permissions_success'))
        toGetUserRoleList()
        isShowModifyPermissions.value = false
      })
    }
    const modifyPermissionsClose = () => {
      treeCheckedList.value = []
    }

    const toDeleteRole = () => {
      const { id } = selectedRow.value
      deleteRole({ id }).then(() => {
        ElMessage.success(t('delete_success'))
        toGetUserRoleList()
      })
    }
    const deleteRoleConfirm = () => {
      toDeleteRole()
      return true
    }

    return {
      isLoading,
      tableConfig,
      paginationConfig,
      filterConfig,
      searchHandle,
      resetHandle,
      superiorRoleList,
      batchDeleteConfirm,
      isShowModifyPermissions,
      openModifyPermissionsDialog,
      modifyPermissionsConfirm,
      modifyPermissionsClose,
      deleteRoleConfirm,
      isShowNewEditRoles,
      newEditRolesRef,
      newEditRolesForm,
      newEditRolesRule,
      permissionsTreeRef,
      defaultTreeProps,
      treeCheckedList,
      permissionsTree,
      clickSettingPermission,
      permissionsTreeConfirm,
      newEditRolesType,
      openNewRolesDialog,
      openEditRolesDialog,
      isShowNewEditRolesInner,
      toNewEditRoles,
    }
  },
})
</script>
<style lang="scss" scoped>
.mr10 {
  margin-right: 10px;
}
</style>
