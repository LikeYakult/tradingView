<template>
  <div class="page-container">
    <baseFilter :loading="isLoading" :config="filterConfig" @onSearch="searchHandle" @onReset="resetHandle"></baseFilter>
    <div class="operate-buttons">
      <el-button class="toolbar-add-button" type="primary" @click="openNewDepartmentDialog">{{
        $t('new')
      }}</el-button>
    </div>
    <baseTable :is-table-loading="isLoading" ref="tablePaginationRef" :config="tableConfig" :pagination="paginationConfig">
      <template v-slot:operate>
        <el-table-column :label="$t('operate')" align="center">
          <template v-slot:default>
            <span @click="openEditDepartmentDialog" class="text-primary mr10">{{
              $t('modify')
            }}</span>
            <action-confirm :title="$t('determine_deleted')" @confirm="deleteRoleConfirm">
              <template #reference>
                <span class="text-primary mr10">{{ $t('delete') }}</span>
              </template>
            </action-confirm>
          </template>
        </el-table-column>
      </template>
    </baseTable>
    <el-dialog
      v-model="isShowNewEditDepartment"
      width="30%"
      :title="newEditDepartmentType === 'new' ? $t('add_department') : $t('modify_department')"
      center
      append-to-body
    >
      <el-form
        ref="newEditDepartmentRef"
        :model="newEditDepartmentForm"
        :rules="newEditDepartmentRule"
        label-width="100px"
        style="width: 80%; margin: 0 auto;"
      >
        <el-form-item
          :label="`${$t('department_number')}：`"
          prop="code"
          v-if="newEditDepartmentType === 'new'"
        >
          <el-input v-model="newEditDepartmentForm.code"></el-input>
        </el-form-item>
        <el-form-item :label="`${$t('department_name')}：`" prop="name">
          <el-input v-model="newEditDepartmentForm.name"></el-input>
        </el-form-item>
        <el-form-item :label="`${$t('remarks')}：`" prop="remark">
          <el-input v-model="newEditDepartmentForm.remark"></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" @click="newEditDepartmentConfirm">{{
            $t('determine')
          }}</el-button>
          <el-button @click="isShowNewEditDepartment = false">{{ $t('cancel') }}</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>
<script lang="ts">
import { defineComponent, reactive, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage } from 'element-plus'
import baseFilter from '@/components/base-filter/base-filter'
import baseTable from '@/components/base-table/base-table'
import {
  getDepartmentList,
  newDepartment,
  editDepartment,
  deleteDepartment,
} from '@/api/subPro/subPro'

export default defineComponent({
  name: 'department-management',
  components: {
    baseFilter,
    baseTable,
  },
  setup() {
    const { t } = useI18n()
    const isLoading = ref(false)
    const tablePaginationRef = ref()
    const pageSize = ref(20)
    const currentPage = ref(1)
    const searchData = ref()

    /* 表格-start */
    // 选中行数
    // 选中行
    const selectedRow = ref()
    const tableConfig = reactive({
      tableProps: {
        data: <{ date: string; name: string; address: string }[]>[],
      },
      tableEvent: {
        onRowClick: (row: object) => {
          selectedRow.value = row
        },
      },
      customColumns: [
        { label: t('add_time'), prop: 'createTime' },
        { label: t('department_number'), prop: 'code' },
        { label: t('department_name'), prop: 'name' },
        { label: t('remarks'), prop: 'remark' },
        { slot: 'operate' },
      ],
    })
    /* 表格-end */

    /* 分页-start */
    const paginationConfig = ref({
      paginationProps: { total: 0, 'page-size': 20 },
      paginationEvent: {
        onSizeChange: handleSizeChange,
        onCurrentChange: handleCurrentChange,
      },
    })
    function handleSizeChange(currentSize: number) {
      paginationConfig.value.paginationProps['page-size'] = currentSize
      tablePaginationRef.value?.toFirstPage()
      currentPage.value = 1
      pageSize.value = currentSize
      toGetDepartmentList()
    }
    function handleCurrentChange(theCurrentPage: number) {
      currentPage.value = theCurrentPage
      toGetDepartmentList()
    }
    /* 分页-end */

    function toGetDepartmentList() {
      isLoading.value = true
      const params = {
        ...searchData.value,
        pageSize: pageSize.value,
        pageNum: currentPage.value,
      }
      getDepartmentList(params).then((res: { [key: string]: any }) => {
        tableConfig.tableProps.data = res.result?.records
        paginationConfig.value.paginationProps.total = res.result?.total || 0
      }).finally(() => {
        isLoading.value = false
      })
    }
    toGetDepartmentList()

    /* 过滤表单-start */
    const filterConfig = ref({
      formProps: {
        model: {
          keyword: '',
        },
      },
      formItems: [
        {
          prop: 'keyword',
          label: t('department_name'),
          innerEl: {
            elType: 'input',
            props: { placeholder: t('please_enter_department_name', 1) },
          },
        },
      ],
    })
    const searchHandle = (data: { [name: string]: any }) => {
      currentPage.value = 1
      tablePaginationRef.value?.toFirstPage()
      // 携带自定义插槽数据并请求查询
      searchData.value = { ...data }
      toGetDepartmentList()
    }
    const resetHandle = (data: { [name: string]: any }) => {
      currentPage.value = 1
      tablePaginationRef.value?.toFirstPage()
      // 重置自定义插槽数据并请求查询
      searchData.value = { ...data }
      toGetDepartmentList()
    }
    /* 过滤表单-end */

    const isShowNewEditDepartment = ref(false)
    const newEditDepartmentType = ref('new')
    const newEditDepartmentRef = ref()
    const newEditDepartmentForm = ref({
      code: '',
      name: '',
      remark: '',
    })
    const newEditDepartmentRule = {
      code: [{ required: true, message: t('please_enter_department_number'), trigger: 'blur' }],
      name: [{ required: true, message: t('please_enter_department_name', 2), trigger: 'blur' }],
    }
    const openNewDepartmentDialog = () => {
      isShowNewEditDepartment.value = true
      newEditDepartmentType.value = 'new'
      newEditDepartmentForm.value.code = ''
      newEditDepartmentForm.value.name = ''
      newEditDepartmentForm.value.remark = ''
    }
    const openEditDepartmentDialog = () => {
      isShowNewEditDepartment.value = true
      newEditDepartmentType.value = 'edit'
      setTimeout(() => {
        const { code, name, remark } = selectedRow.value
        newEditDepartmentForm.value.code = code
        newEditDepartmentForm.value.name = name
        newEditDepartmentForm.value.remark = remark
      }, 20)
    }
    const newEditDepartmentConfirm = () => {
      newEditDepartmentRef.value.validate((validate: boolean) => {
        if (validate) {
          if (newEditDepartmentType.value === 'new') {
            newDepartment({ parentId: 0, ...newEditDepartmentForm.value }).then(() => {
              ElMessage.success(t('add_success'))
              isShowNewEditDepartment.value = false
              toGetDepartmentList()
            })
          } else if (newEditDepartmentType.value === 'edit') {
            const { id } = selectedRow.value
            const { code, ...params } = newEditDepartmentForm.value
            editDepartment({ id, parentId: 0, ...params }).then(() => {
              ElMessage.success(t('modify_success'))
              isShowNewEditDepartment.value = false
              toGetDepartmentList()
            })
          }
        }
      })
    }

    // 操作列
    const deleteRoleConfirm = () => {
      const { id } = selectedRow.value
      deleteDepartment({ id }).then(() => {
        ElMessage.success(t('delete_success'))
        toGetDepartmentList()
      })
      return true
    }
    return {
      isLoading,
      tableConfig,
      paginationConfig,
      filterConfig,
      searchHandle,
      resetHandle,
      openNewDepartmentDialog,
      openEditDepartmentDialog,
      isShowNewEditDepartment,
      newEditDepartmentRef,
      newEditDepartmentForm,
      newEditDepartmentRule,
      newEditDepartmentType,
      newEditDepartmentConfirm,
      deleteRoleConfirm,
    }
  },
})
</script>
<style lang="scss" scoped>
.mr10 {
  margin-right: 10px;
}
</style>
