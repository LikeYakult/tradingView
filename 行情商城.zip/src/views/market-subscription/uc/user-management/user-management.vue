<template>
  <div class="page-container">
    <baseFilter :loading="isLoading" :config="filterConfig" @onSearch="searchHandle" @onReset="resetHandle"></baseFilter>
    <div class="operate-buttons">
      <el-button class="toolbar-add-button" type="primary" @click="toNewUser">{{
        $t('new')
      }}</el-button>
      <action-confirm :title="$t('sure_to_batch_deleted')" @confirm="batchDeleteConfirm">
        <template #reference
          ><el-button plain type="info">{{ $t('batch_deleted') }}</el-button></template
        >
      </action-confirm>
      <action-confirm :title="$t('sure_to_batch_enable')" @confirm="batchStartupConfirm">
        <template #reference
          ><el-button plain type="info">{{ $t('batch_enabled') }}</el-button></template
        >
      </action-confirm>
      <action-confirm :title="$t('sure_to_batch_disable')" @confirm="batchForbidConfirm">
        <template #reference
          ><el-button plain type="info">{{ $t('batch_disabled') }}</el-button></template
        >
      </action-confirm>
      <el-button plain type="info" @click="openBatchAssignRolesDialog">{{
        $t('assigning_roles_in_batches')
      }}</el-button>
    </div>
    <baseTable :is-table-loading="isLoading" ref="tablePaginationRef" :config="tableConfig" :pagination="paginationConfig">
      <template v-slot:status>
        <el-table-column :label="$t('state')" align="center">
          <template #default="scope">
            {{ statusText(scope.row.status) }}
          </template>
        </el-table-column>
      </template>
      <template v-slot:operate>
        <el-table-column :label="$t('operate')" width="270" align="center" fixed="right">
          <template #default="scope">
            <span @click="toModifyUser" class="text-primary mr10">{{ $t('modify') }}</span>
            <action-confirm :title="$t('determine_deleted')" @confirm="userDeleteConfirm">
              <template #reference>
                <span class="text-primary mr10">{{ $t('delete') }}</span>
              </template>
            </action-confirm>
            <template v-if="statusText(scope.row.status) === $t('disabled')">
              <action-confirm :title="$t('determine_enabled')" @confirm="startupConfirm">
                <template #reference>
                  <span class="text-primary mr10">{{ $t('enable') }}</span>
                </template>
              </action-confirm>
            </template>
            <template v-else-if="statusText(scope.row.status) === $t('enable')">
              <action-confirm :title="$t('determine_disabled')" @confirm="forbidConfirm">
                <template #reference>
                  <span class="text-primary mr10">{{ $t('disabled') }}</span>
                </template>
              </action-confirm>
            </template>
            <span @click="openResetPassDialog" class="text-primary mr10">{{
              $t('reset_password')
            }}</span>
            <span @click="openAssignRolesDialog" class="text-primary mr10">{{
              $t('assign_roles')
            }}</span>
          </template>
        </el-table-column>
      </template>
    </baseTable>
    <!-- 新建/修改用户 -->
    <el-dialog
      v-model="isShowNewEditUser"
      :title="userNewEditType === 'new' ? $t('new_user') : $t('modify_user')"
      width="800px"
      center
    >
      <el-form
        ref="newEditUserRef"
        :inline="true"
        :model="newEditUserForm"
        :rules="newEditUserRule"
        label-width="100px"
        style="width: 90%; margin: 0 auto"
      >
        <el-form-item :label="`${$t('user_name')}：`" prop="nickname">
          <el-input v-model="newEditUserForm.nickname"></el-input>
        </el-form-item>
        <el-form-item :label="`${$t('mobile_number')}：`" prop="mobile">
          <el-input v-model="newEditUserForm.mobile" class="suffix-mobile">
            <template #prepend>
              <el-select v-model="newEditUserForm.areaCode">
                <el-option value="+86" label="86"></el-option>
                <el-option value="+852" label="852"></el-option>
              </el-select>
            </template>
          </el-input>
        </el-form-item>
        <el-form-item :label="`${$t('email')}：`" prop="email">
          <el-input v-model="newEditUserForm.email"></el-input>
        </el-form-item>
        <el-form-item :label="`${$t('login_account')}：`" prop="username">
          <el-input v-model="newEditUserForm.username"></el-input>
        </el-form-item>
        <el-form-item
          :label="`${$t('login_password')}：`"
          prop="password"
          v-if="userNewEditType === 'new'"
        >
          <el-input v-model="newEditUserForm.password" type="password"></el-input>
        </el-form-item>
        <el-form-item :label="`${$t('current_department')}：`" prop="deptId">
          <el-select v-model="newEditUserForm.deptId">
            <el-option
              v-for="item of userDeptList"
              :key="item.value"
              :value="item.value"
              :label="item.label"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item
          :label="`${$t('confirm_password')}：`"
          prop="confirmPassword"
          v-if="userNewEditType === 'new'"
        >
          <el-input v-model="newEditUserForm.confirmPassword" type="password"></el-input>
        </el-form-item>
        <el-form-item :label="`${$t('current_role')}：`" prop="roleIds">
          <el-button @click="isShowNewEditUserRole = true">{{ $t('click_select_role') }}</el-button>
        </el-form-item>
        <el-form-item :label="`${$t('state')}：`" prop="status">
          <el-radio v-model="newEditUserForm.status" :label="1" size="large">{{
            $t('enable')
          }}</el-radio>
          <el-radio v-model="newEditUserForm.status" :label="0" size="large">{{
            $t('disabled')
          }}</el-radio>
        </el-form-item>
      </el-form>
      <el-dialog
        v-model="isShowNewEditUserRole"
        width="30%"
        :title="$t('current_role')"
        center
        append-to-body
      >
        <assign-roles :data="userAssignRoles" @roleChange="roleChangeHandle" />
        <template #footer>
          <span class="dialog-footer">
            <el-button type="primary" @click="isShowNewEditUserRole = false">{{
              $t('determine')
            }}</el-button>
            <!-- <el-button @click="isShowNewEditUserRole = false">取消</el-button> -->
          </span>
        </template>
      </el-dialog>
      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" @click="confirmNewEditUser">{{ $t('determine') }}</el-button>
          <el-button @click="isShowNewEditUser = false">{{ $t('cancel') }}</el-button>
        </span>
      </template>
    </el-dialog>
    <!-- 重置密码 -->
    <el-dialog v-model="isShowResetPass" :title="$t('reset_password')" width="800px" center>
      <el-form
        ref="resetPassRef"
        :model="resetPassForm"
        :rules="resetPassRule"
        label-width="100px"
        style="width: 50%; margin: 0 auto"
      >
        <el-form-item :label="`${$t('user_name')}：`">
          <span>{{ selectedRow?.nickname }}</span>
        </el-form-item>
        <el-form-item :label="`${$t('login_account')}：`">
          <span>{{ selectedRow?.username }}</span>
        </el-form-item>
        <el-form-item :label="`${$t('enter_password')}：`" prop="password">
          <el-input v-model="resetPassForm.password" type="password"></el-input>
        </el-form-item>
        <el-form-item :label="`${$t('confirm_password')}：`" prop="confirmPassword">
          <el-input v-model="resetPassForm.confirmPassword" type="password"></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" @click="confirmResetPass">{{ $t('determine') }}</el-button>
          <el-button @click="isShowResetPass = false">{{ $t('cancel') }}</el-button>
        </span>
      </template>
    </el-dialog>
    <!-- 分配角色 -->
    <el-dialog v-model="isShowAssignRoles" :title="$t('assign_roles')" width="800px" center>
      <!-- :model="assignRolesForm" -->
      <el-form ref="assignRolesRef" label-width="100px" style="width: 50%; margin: 0 auto">
        <el-form-item :label="`${$t('user_name')}：`">
          <span>{{ selectedRow?.nickname }}</span>
        </el-form-item>
        <el-form-item :label="`${$t('login_account')}：`">
          <span>{{ selectedRow?.username }}</span>
        </el-form-item>
        <el-form-item label="">
          <el-button @click="toAssignRoles">{{ $t('current_role') }}</el-button>
        </el-form-item>
      </el-form>
      <el-dialog
        v-model="isShowAssignRolesInner"
        width="30%"
        :title="$t('current_role')"
        center
        append-to-body
      >
        <assign-roles :data="userAssignRoles" @roleChange="roleChangeHandle" />
        <template #footer>
          <span class="dialog-footer">
            <el-button type="primary" @click="isShowAssignRolesInner = false">{{
              $t('determine')
            }}</el-button>
          </span>
        </template>
      </el-dialog>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="assignRolesConfirm" type="primary">{{ $t('determine') }}</el-button>
          <el-button @click="isShowAssignRoles = false">{{ $t('cancel') }}</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 批量分配角色 -->
    <el-dialog
      v-model="isShowBatchAssignRoles"
      width="30%"
      :title="$t('assigning_roles_in_batches')"
      center
      append-to-body
    >
      <assign-roles :data="userAssignRoles" @roleChange="roleChangeHandle" />
      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" @click="batchAssignRolesConfirm">{{
            $t('determine')
          }}</el-button>
          <el-button @click="isShowBatchAssignRoles = false">{{ $t('cancel') }}</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>
<script lang="ts">
import { defineComponent, reactive, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage, ElMessageBox } from 'element-plus'
import baseFilter from '@/components/base-filter/base-filter'
import baseTable from '@/components/base-table/base-table'
import assignRoles from '@/components/assign-roles/assign-roles.vue'
import {
  getUserManagementList,
  getUserManagementRoleList,
  userBatchDelete,
  userBatchStartup,
  userBatchForbid,
  getUserDeptList,
  newUserApi,
  modifyUserApi,
  userDelete,
  userStartup,
  userForbid,
  userResetPass,
  getUserAssignRoles,
  roleAssignConfirm,
  batchRolesAssignConfirm,
} from '@/api/subPro/subPro'

export default defineComponent({
  name: 'account-user-management',
  components: {
    baseFilter,
    baseTable,
    assignRoles,
  },
  setup() {
    const { t } = useI18n()
    const isLoading = ref(false)
    const tablePaginationRef = ref()
    const pageSize = ref(20)
    const currentPage = ref(1)
    const searchData = ref()

    /* 表格-start */
    // 选中行数
    let tableSelectionRows: any[] = []
    const tableSelectionChange = (selection: []) => {
      tableSelectionRows = selection
    }
    // 选中行
    const selectedRow = ref()
    const tableConfig = reactive({
      tableProps: {
        data: <{ date: string; name: string; address: string }[]>[],
      },
      tableEvent: {
        onSelectionChange: tableSelectionChange,
        onRowClick: (row: object) => {
          selectedRow.value = row
        },
      },
      customColumns: [
        { type: 'selection', align: 'center' },
        { label: t('add_time'), prop: 'createTime', width: '160' },
        { label: t('login_account'), prop: 'username', width: '120' },
        { label: t('fullName'), prop: 'name' },
        { label: t('mobile_number'), prop: 'mobile', width: '150' },
        { label: t('current_role'), prop: 'roleName' },
        { label: t('current_department'), prop: 'deptName' },
        { label: t('email'), prop: 'email', width: '150' },
        { label: t('last_login_ip'), prop: 'lastLoginIp', width: '120' },
        { label: t('last_login_time'), prop: 'lastLoginTime', width: '160' },
        { slot: 'status' },
        { slot: 'operate' },
      ],
    })
    const statusText = (num: number) => {
      const text = [t('disabled'), t('enable')]
      return text[num]
    }
    /* 表格-end */

    /* 分页-start */
    const paginationConfig = ref({
      paginationProps: { total: 0, 'page-size': 20 },
      paginationEvent: {
        onSizeChange: handleSizeChange,
        onCurrentChange: handleCurrentChange,
      },
    })
    function handleSizeChange(currentSize: number) {
      paginationConfig.value.paginationProps['page-size'] = currentSize
      tablePaginationRef.value?.toFirstPage()
      currentPage.value = 1
      pageSize.value = currentSize
      toGetUserManagementList()
    }
    function handleCurrentChange(theCurrentPage: number) {
      currentPage.value = theCurrentPage
      toGetUserManagementList()
    }
    /* 分页-end */

    function toGetUserManagementList() {
      isLoading.value = true
      const params = {
        ...searchData.value,
        pageSize: pageSize.value,
        pageNum: currentPage.value,
      }
      getUserManagementList(params).then((res: { [key: string]: any }) => {
        tableConfig.tableProps.data = res.result?.records
        paginationConfig.value.paginationProps.total = res.result?.total || 0
      }).finally(() => {
        isLoading.value = false
      })
    }
    toGetUserManagementList()

    /* 过滤表单-start */
    const filterConfig = ref({
      formProps: {
        model: {
          keyword: '',
          roleId: '',
        },
      },
      formItems: [
        {
          prop: 'keyword',
          label: '',
          innerEl: {
            elType: 'input',
            props: { placeholder: t('keyword_placeholder') },
          },
        },
        {
          prop: 'roleId',
          label: t('current_role'),
          innerEl: {
            elType: 'select',
            options: [{ value: '', label: t('all') }],
          },
        },
      ],
    })
    const searchHandle = (data: { [name: string]: any }) => {
      currentPage.value = 1
      tablePaginationRef.value?.toFirstPage()
      // 携带自定义插槽数据并请求查询
      searchData.value = { ...data }
      toGetUserManagementList()
    }
    const resetHandle = (data: { [name: string]: any }) => {
      currentPage.value = 1
      tablePaginationRef.value?.toFirstPage()
      // 重置自定义插槽数据并请求查询
      searchData.value = { ...data }
      console.log(data)

      toGetUserManagementList()
    }
    // 获取角色列表
    getUserManagementRoleList({ pageSize: 100000 }).then((res) => {
      const options = res.result?.records.map((item: { [key: string]: any }) => ({
        value: item.id,
        label: item.name,
      }))
      const preOption = filterConfig.value.formItems[1].innerEl.options
      filterConfig.value.formItems[1].innerEl.options = preOption?.concat(options)
    })
    /* 过滤表单-end */

    const toBatchDelete = () => {
      if (tableSelectionRows?.length === 0) {
        ElMessageBox.alert(t('select_batch_delete_data'), t('tip'), {
          confirmButtonText: t('determine'),
          type: 'error',
        })
        return
      }
      const ids = tableSelectionRows.map((item) => item.id)
      return userBatchDelete({ ids }).then(() => {
        ElMessage.success(t('delete_success'))
        toGetUserManagementList()
      })
    }
    const batchDeleteConfirm = () => {
      toBatchDelete()
      return true
    }
    const toBatchStartup = () => {
      if (tableSelectionRows?.length === 0) {
        ElMessageBox.alert(t('select_batch_enable_data'), t('tip'), {
          confirmButtonText: t('determine'),
          type: 'error',
        })
        return
      }
      const ids = tableSelectionRows.map((item) => item.id)
      return userBatchStartup({ ids }).then(() => {
        ElMessage.success(t('enable_success'))
        toGetUserManagementList()
      })
    }
    const batchStartupConfirm = () => {
      toBatchStartup()
      return true
    }
    const toBatchForbid = () => {
      if (tableSelectionRows?.length === 0) {
        ElMessageBox.alert(t('select_batch_disable_data'), t('tip'), {
          confirmButtonText: t('determine'),
          type: 'error',
        })
        return
      }
      const ids = tableSelectionRows.map((item) => item.id)
      return userBatchForbid({ ids }).then(() => {
        ElMessage.success(t('disable_success'))
        toGetUserManagementList()
      })
    }
    const batchForbidConfirm = () => {
      toBatchForbid()
      return true
    }

    // 添加/修改用户
    const isShowNewEditUser = ref(false)
    const isShowNewEditUserRole = ref(false)
    const userNewEditType = ref('new')
    const newEditUserRef = ref()
    const userAssignRoles = ref()
    const toGetUserAssignRoles = (params?: object) => {
      return getUserAssignRoles(params).then((res) => {
        userAssignRoles.value = res.result
      })
    }

    const newEditUserForm = ref<{ [key: string]: any }>({
      nickname: '',
      areaCode: '+86',
      mobile: '',
      email: '',
      username: '',
      password: '',
      roleIds: [],
      confirmPassword: '',
      deptId: '',
      status: '',
    })
    const newEditUserRule = {
      nickname: [{ required: true, message: t('please_enter_user_name'), trigger: 'blur' }],
      mobile: [{ required: true, message: t('please_enter_mobile_number'), trigger: 'blur' }],
      username: [{ required: true, message: t('please_enter_login_password'), trigger: 'blur' }],
      password: [{ required: true, message: t('please_enter_login_password'), trigger: 'blur' }],
      // roleIds: [{ required: true, message: '请选择角色', trigger: 'click' }],
      confirmPassword: [
        { required: true, message: t('please_enter_confirm_password'), trigger: 'blur' },
      ],
      deptId: [{ required: true, message: t('please_select_department'), trigger: 'change' }],
      status: [{ required: true, message: t('please_select_state'), trigger: 'change' }],
    }
    const toNewUser = () => {
      isShowNewEditUser.value = true
      userNewEditType.value = 'new'
      newEditUserRef.value?.resetFields()
      toGetUserAssignRoles()
    }

    const roleChangeHandle = (roles: string[]) => {
      newEditUserForm.value.roleIds = roles
    }
    const confirmNewEditUser = () => {
      newEditUserRef.value.validate((validate: boolean) => {
        if (validate) {
          if (userNewEditType.value === 'new') {
            newUserApi(newEditUserForm.value).then(() => {
              ElMessage.success(t('new_user_success'))
              isShowNewEditUser.value = false
              toGetUserManagementList()
            })
          } else if (userNewEditType.value === 'edit') {
            const { id } = selectedRow.value
            modifyUserApi({ id, ...newEditUserForm.value }).then(() => {
              ElMessage.success(t('modify_user_success'))
              isShowNewEditUser.value = false
              toGetUserManagementList()
            })
          }
        }
      })
    }

    // 获取部门列表
    const userDeptList = ref()
    getUserDeptList().then((res) => {
      const options = res.result?.records.map((item: { [key: string]: any }) => ({
        value: item.id,
        label: item.name,
      }))
      userDeptList.value = options
    })

    /* 操作列-start */
    // 修改
    const setRoleIdsOfNewEditUserForm = () => {
      const { superAdmin, modules } = userAssignRoles.value
      if (superAdmin.checked) {
        newEditUserForm.value.roleIds = [superAdmin.id]
      } else {
        const roleIds: string[] = []
        modules?.forEach((module: { [key: string]: any }) => {
          module.roles?.forEach((role: { [key: string]: any }) => {
            if (role.checked) {
              roleIds.push(role.id)
            }
          })
        })
        newEditUserForm.value.roleIds = roleIds
      }
    }
    const toModifyUser = () => {
      setTimeout(() => {
        userNewEditType.value = 'edit'
        const { id, nickname, areaCode, mobile, email, username, deptId, status } =
          selectedRow.value
        newEditUserForm.value.nickname = nickname
        newEditUserForm.value.areaCode = areaCode
        newEditUserForm.value.mobile = mobile
        newEditUserForm.value.email = email
        newEditUserForm.value.username = username
        newEditUserForm.value.deptId = deptId
        newEditUserForm.value.status = status

        isShowNewEditUser.value = true
        toGetUserAssignRoles({ id }).then(() => {
          setRoleIdsOfNewEditUserForm()
        })
      }, 20)
    }
    // 删除
    const toUserDelete = () => {
      const { id } = selectedRow.value
      userDelete({ id }).then(() => {
        ElMessage.success(t('delete_success'))
        toGetUserManagementList()
      })
    }
    const userDeleteConfirm = () => {
      toUserDelete()
      return true
    }
    // 启动、删除
    const startupConfirm = () => {
      const { id } = selectedRow.value
      userStartup({ id }).then(() => {
        ElMessage.success(t('enable_success'))
        toGetUserManagementList()
      })
      return true
    }
    const forbidConfirm = () => {
      const { id } = selectedRow.value
      userForbid({ id }).then(() => {
        ElMessage.success(t('disable_success'))
        toGetUserManagementList()
      })
      return true
    }
    // 重置密码
    const isShowResetPass = ref(false)
    const resetPassRef = ref()
    const resetPassForm = ref({
      password: '',
      confirmPassword: '',
    })
    const validatePass = (rule: any, value: any, callback: any) => {
      if (value === '') {
        callback(new Error(t('please_enter_password')))
      } else {
        if (resetPassForm.value.confirmPassword !== '') {
          if (!resetPassRef.value) return
          resetPassRef.value.validateField('confirmPassword', () => null)
        }
        callback()
      }
    }
    const validatePass2 = (rule: any, value: any, callback: any) => {
      if (value === '') {
        callback(new Error(t('please_enter_password_again')))
      } else if (value !== resetPassForm.value.password) {
        callback(new Error(t('password_check', 2)))
      } else {
        callback()
      }
    }
    const resetPassRule = ref({
      password: [{ required: true, validator: validatePass, trigger: 'blur' }],
      confirmPassword: [{ required: true, validator: validatePass2, trigger: 'blur' }],
    })
    const openResetPassDialog = () => {
      isShowResetPass.value = true
      resetPassRef.value?.resetFields()
    }
    const confirmResetPass = () => {
      resetPassRef.value.validate((validate: boolean) => {
        if (validate) {
          const { id } = selectedRow.value
          userResetPass({ id, ...resetPassForm.value }).then(() => {
            ElMessage.success(t('reset_password_success'))
            isShowResetPass.value = false
          })
        }
      })
    }
    /* 操作列-end */

    // 分配角色
    const isShowAssignRoles = ref(false)
    const isShowAssignRolesInner = ref(false)
    const openAssignRolesDialog = () => {
      isShowAssignRoles.value = true
      setTimeout(() => {
        const { id } = selectedRow.value
        toGetUserAssignRoles({ id }).then(() => {
          setRoleIdsOfNewEditUserForm()
        })
      }, 20)
    }
    const toAssignRoles = () => {
      isShowAssignRolesInner.value = true
    }
    const assignRolesConfirm = () => {
      setTimeout(() => {
        const { id } = selectedRow.value
        roleAssignConfirm({ id, roleIds: newEditUserForm.value.roleIds }).then(() => {
          ElMessage.success(t('assigning_roles_success'))
          isShowAssignRoles.value = false
        })
      }, 20)
    }

    // 批量分配角色
    const isShowBatchAssignRoles = ref(false)
    const openBatchAssignRolesDialog = () => {
      toGetUserAssignRoles().then(() => {
        isShowBatchAssignRoles.value = true
      })
    }
    const batchAssignRolesConfirm = () => {
      if (tableSelectionRows?.length === 0) {
        ElMessageBox.alert(t('please_select_user'), t('tip'), {
          confirmButtonText: t('determine'),
          type: 'error',
        })
        return
      }
      const ids = tableSelectionRows.map((item) => item.id)
      return batchRolesAssignConfirm({ ids, roleIds: newEditUserForm.value.roleIds }).then(() => {
        ElMessage.success(t('assigning_roles_in_batches_success'))
        isShowBatchAssignRoles.value = false
      })
    }

    return {
      isLoading,
      selectedRow,
      tableConfig,
      paginationConfig,
      statusText,
      filterConfig,
      searchHandle,
      resetHandle,
      batchDeleteConfirm,
      batchStartupConfirm,
      batchForbidConfirm,
      isShowNewEditUser,
      userNewEditType,
      newEditUserRef,
      newEditUserForm,
      newEditUserRule,
      toNewUser,
      isShowNewEditUserRole,
      userDeptList,
      confirmNewEditUser,
      toModifyUser,
      userDeleteConfirm,
      startupConfirm,
      forbidConfirm,
      isShowResetPass,
      resetPassRef,
      resetPassForm,
      resetPassRule,
      openResetPassDialog,
      confirmResetPass,
      userAssignRoles,
      isShowAssignRoles,
      isShowAssignRolesInner,
      openAssignRolesDialog,
      toAssignRoles,
      assignRolesConfirm,
      isShowBatchAssignRoles,
      openBatchAssignRolesDialog,
      batchAssignRolesConfirm,
      roleChangeHandle,
    }
  },
})
</script>
<style lang="scss" scoped>
.mr10 {
  margin-right: 10px;
}
</style>
