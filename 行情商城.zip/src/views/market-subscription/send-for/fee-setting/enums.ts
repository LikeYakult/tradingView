export enum OperateMode {
  Add = 'Add',
  Edit = 'Edit',
  Detail = 'Detail',
}
