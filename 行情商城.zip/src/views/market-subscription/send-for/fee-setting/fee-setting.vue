<template>
  <!-- 套餐管理 - 费用设置 -->
  <div class="page-container">
    <base-filter :loading="isLoading"
      :config="filterConfig"
      @on-search="searchHandle"
      @on-reset="resetHandle"
    ></base-filter>
    <div class="tool operate-buttons">
      <el-button class="toolbar-add-button" type="primary" @click="openAddDialog">
        {{ $t('add_fee') }}
      </el-button>
    </div>
    <base-table :config="tableConfig" :pagination="pagination" :is-table-loading="isLoading">
      <template #handler>
        <el-table-column align="center" :label="$t('operate')" width="210px" fixed="right">
          <template #default="scope">
            <el-button type="text" class="text-primary" @click="openViewDialog(scope.row)">
              <span>{{ $t('view') }}</span>
            </el-button>
            <el-button type="text" class="text-primary" @click="openEditDialog(scope.row)">
              <span>{{ $t('modify') }}</span>
            </el-button>
            <el-button type="text" class="text-primary" @click="deleteFeeItem(scope.row.id)">
              <span>{{ $t('delete') }}</span>
            </el-button>
          </template>
        </el-table-column>
      </template>
    </base-table>

    <EditFeeDialog ref="editFeeDialogRef" @success="getData" />
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage, ElMessageBox } from 'element-plus'
import baseTable from '@/components/base-table/base-table'
import baseFilter from '@/components/base-filter/base-filter'
import EditFeeDialog from './edit-fee-dialog.vue'
import { OperateMode } from './enums'
import { fetchFeeList, deleteFee, IFeeListItem, IFeeListQueryParams } from '@/api-v2/quotation/fee'

const { t } = useI18n()

const isLoading = ref<boolean>(false)
const editFeeDialogRef = ref<InstanceType<typeof EditFeeDialog>>()

const ordering = ref<{ asc: boolean; column: string }>({
  asc: false,
  column: 'createTime',
})

const filterParams = ref<{
  id?: string
  name?: string
  createTimeRange?: [string, string]
}>({})

const tableConfig = reactive<{
  tableProps: {
    data: IFeeListItem[]
    height: string
  }
  tableEvent: {
    onSortChange: (column: { order: string; prop: string }) => void
  }
  customColumns: Record<string, string>[]
}>({
  tableProps: {
    data: [],
    height: '520',
  },
  tableEvent: {
    onSortChange: (column: { order: string; prop: string }) => {
      const { order, prop } = column
      pagination.paginationProps.currentPage = 1
      if (order) {
        ordering.value = {
          asc: order === 'ascending',
          column: prop,
        }
      } else {
        ordering.value = {
          asc: false,
          column: 'createTime',
        }
      }
      getData()
    },
  },
  customColumns: [
    { label: t('fee_id'), prop: 'id', minWidth: '160' },
    { label: t('fee_name'), prop: 'name', minWidth: '180' },
    { label: t('fixed_amount'), prop: 'fixAmount', minWidth: '140' },
    { label: t('fee_currency'), prop: 'currency', minWidth: '120' },
    { label: t('creation_time'), prop: 'createTime', minWidth: '180', sortable: 'custom' },
    { slot: 'handler' },
  ],
})

const pagination = reactive<{
  paginationProps: {
    currentPage: number
    pageSize: number
    total: number
  }
  paginationEvent: {
    onSizeChange: (v: number) => void
    onCurrentChange: (v: number) => void
  }
}>({
  paginationProps: {
    currentPage: 1,
    pageSize: 20,
    total: 0,
  },
  paginationEvent: {
    onSizeChange: (v: number) => {
      pagination.paginationProps.pageSize = v
      getData()
    },
    onCurrentChange: (v: number) => {
      pagination.paginationProps.currentPage = v
      getData()
    },
  },
})

const filterConfig = reactive({
  formProps: {
    model: {},
  },
  formItems: [
    {
      prop: 'id',
      label: t('fee_id'),
      innerEl: {
        elType: 'input',
        props: {
          placeholder: t('please_enter'),
        },
      },
    },
    {
      prop: 'name',
      label: t('fee_name'),
      innerEl: {
        elType: 'input',
        props: {
          placeholder: t('please_enter'),
        },
      },
    },
    {
      prop: 'createTimeRange',
      label: t('creation_time'),
      innerEl: {
        elType: 'datePicke',
        props: { type: 'daterange', valueFormat: 'YYYY-MM-DD' },
      },
    },
  ],
})

async function getData() {
  isLoading.value = true
  try {
    const params: IFeeListQueryParams = {
      pageNum: pagination.paginationProps.currentPage,
      pageSize: pagination.paginationProps.pageSize,
      id: filterParams.value.id || undefined,
      name: filterParams.value.name || undefined,
    }

    if (filterParams.value.createTimeRange && filterParams.value.createTimeRange.length === 2) {
      params.createDateStart = filterParams.value.createTimeRange[0]
      params.createDateEnd = filterParams.value.createTimeRange[1]
    }

    if (ordering.value.column) {
      params.orders = [
        {
          asc: ordering.value.asc,
          column: ordering.value.column,
        },
      ]
    }

    const res = await fetchFeeList(params)
    if (res && res.result) {
      tableConfig.tableProps.data = res.result.records || []
      pagination.paginationProps.total = res.result.total || 0
    } else {
      tableConfig.tableProps.data = []
      pagination.paginationProps.total = 0
    }
  } catch (err) {
    console.error(err)
    tableConfig.tableProps.data = []
    pagination.paginationProps.total = 0
  } finally {
    isLoading.value = false
  }
}

function searchHandle(data: { id?: string; name?: string; createTimeRange?: [string, string] }) {
  pagination.paginationProps.currentPage = 1
  filterParams.value = data || {}
  getData()
}

function resetHandle() {
  pagination.paginationProps.currentPage = 1
  filterParams.value = {}
  getData()
}

function openAddDialog() {
  editFeeDialogRef.value?.open(OperateMode.Add)
}

function openViewDialog(row: IFeeListItem) {
  editFeeDialogRef.value?.open(OperateMode.Detail, row.id)
}

function openEditDialog(row: IFeeListItem) {
  editFeeDialogRef.value?.open(OperateMode.Edit, row.id)
}

function deleteFeeItem(id: string) {
  ElMessageBox.confirm(t('sure_to_delete_fee'), t('prompt'), {
    customClass: 'list-action-message-box',
    confirmButtonText: t('determine'),
    cancelButtonText: t('cancel'),
    type: 'warning',
  })
    .then(async () => {
      const res = await deleteFee(id)
      if (res && res.code === 0) {
        ElMessage.success(t('delete_success'))
        getData()
      }
    })
    .catch(() => {
      // Cancelled
    })
}

onMounted(() => {
  getData()
})
</script>

<style lang="scss" scoped>
.operate-buttons {
  margin-bottom: var(--ui-toolbar-spacing);
}

.text-primary {
  color: var(--el-color-primary, #409eff);
}
</style>
