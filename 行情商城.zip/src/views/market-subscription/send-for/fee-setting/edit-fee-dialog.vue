<template>
  <el-dialog
    v-model="dialogVisible"
    :title="title"
    width="1200px"
    center
    destroy-on-close
    :close-on-click-modal="false"
    @close="handleClose"
  >
    <div v-loading="isLoading" class="edit-fee-dialog-content">
      <div class="header-lang">
        <CheckLang v-model="currentLang" />
      </div>

      <el-form
        ref="formRef"
        :model="formModel"
        :rules="formRules"
        label-width="180px"
        :disabled="isReadOnly"
        size="default"
      >
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('fee_id')" prop="id">
              <el-input
                v-model="formModel.id"
                :disabled="isIdDisabled || isReadOnly"
                :placeholder="$t('please_enter')"
                @input="formModel.id = filterSpecialChars(formModel.id)"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('is_standard')" prop="isStandard">
              <el-radio-group v-model="formModel.isStandard">
                <el-radio :label="true">{{ $t('yes') }}</el-radio>
                <el-radio :label="false">{{ $t('no') }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('fee_name')" prop="name">
              <el-input
                v-model="formModel.name"
                maxlength="255"
                :placeholder="$t('please_enter')"
                @input="formModel.name = filterSpecialChars(formModel.name)"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('other_language')" prop="otherLanguage">
              <el-input v-model="formModel.otherLanguage" :placeholder="$t('please_enter')" />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('rounding_method')" prop="roundingMethod">
              <el-select
                v-model="formModel.roundingMethod"
                class="w-full"
                :placeholder="$t('please_select')"
              >
                <el-option
                  v-for="item in roundingMethodOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('rounding_digits')" prop="roundingDecimal">
              <el-input v-model="formModel.roundingDecimal" :placeholder="$t('please_enter')" />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('fee_currency_type')" prop="feeCurrency">
              <el-select
                v-model="formModel.feeCurrency"
                class="w-full"
                :placeholder="$t('please_select')"
              >
                <el-option
                  v-for="item in feeCurrencyTypeOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('fee_category')" prop="feeCategory">
              <el-select
                v-model="formModel.feeCategory"
                class="w-full"
                :placeholder="$t('please_select')"
              >
                <el-option
                  v-for="item in feeCategoryOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('sub_trade_type')" prop="subTransactionType">
              <el-select v-model="formModel.subTransactionType" :placeholder="$t('please_enter')">
                <el-option
                  v-for="item in subTransactions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('fee_currency')" prop="currency">
              <el-select
                v-model="formModel.currency"
                class="w-full"
                :placeholder="$t('please_select')"
              >
                <el-option
                  v-for="item in currencyOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('country')" prop="country">
              <el-input
                v-model="formModel.country"
                :placeholder="$t('please_enter')"
                @input="formModel.country = filterSpecialChars(formModel.country)"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('report_format')" prop="formatSelection">
              <el-input
                v-model="formModel.formatSelection"
                :placeholder="$t('please_enter')"
                @input="formModel.formatSelection = filterSpecialChars(formModel.formatSelection)"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item
              :label="$t('apply_multiple_channels_min_max')"
              prop="applyMultipleChannelsMinimumMaximum"
            >
              <el-radio-group v-model="formModel.applyMultipleChannelsMinimumMaximum">
                <el-radio :label="true">{{ $t('yes') }}</el-radio>
                <el-radio :label="false">{{ $t('no') }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item
              label-width="240px"
              class="label-nowrap"
              :label="$t('show_zero_amount_in_statement')"
              prop="showZeroAmountInStatementPreconf"
            >
              <el-radio-group v-model="formModel.showZeroAmountInStatementPreconf">
                <el-radio :label="true">{{ $t('yes') }}</el-radio>
                <el-radio :label="false">{{ $t('no') }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item
              :label="$t('generate_broker_settlement_gl')"
              label-width="240px"
              class="label-nowrap"
              prop="generateBrokerSettlementGl"
            >
              <el-radio-group v-model="formModel.generateBrokerSettlementGl">
                <el-radio :label="true">{{ $t('yes') }}</el-radio>
                <el-radio :label="false">{{ $t('no') }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="24">
          <el-col :span="12">
            <el-form-item :label="$t('channel_id')" prop="channelId">
              <!-- <div class="inline-flex-item"> -->
              <el-input
                v-model="formModel.channelId"
                :placeholder="$t('please_enter')"
                @input="formModel.channelId = filterSpecialChars(formModel.channelId)"
              />
              <!-- </div> -->
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('default')" prop="defaultFlag">
              <el-radio-group v-model="formModel.defaultFlag">
                <el-radio :label="true">{{ $t('yes') }}</el-radio>
                <el-radio :label="false">{{ $t('no') }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('channel_class_id')" prop="channelClassId">
              <el-input
                v-model="formModel.channelClassId"
                :placeholder="$t('please_enter')"
                @input="formModel.channelClassId = filterSpecialChars(formModel.channelClassId)"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('charge_action')" prop="chargeOperation">
              <el-select
                v-model="formModel.chargeOperation"
                class="w-full"
                :placeholder="$t('please_select')"
              >
                <el-option
                  v-for="item in chargeActionOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('default_online_channel_fee_setting')">
              <el-radio-group v-model="formModel.defaultOnlineChannelFeeSetting">
                <el-radio :label="true">{{ $t('yes') }}</el-radio>
                <el-radio :label="false">{{ $t('no') }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('charge_type')" prop="chargeType">
              <el-select
                v-model="formModel.chargeType"
                class="w-full"
                :placeholder="$t('please_select')"
              >
                <el-option
                  v-for="item in chargeTypeOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('minimum_charge_amount')" prop="minimumFeeAmount">
              <el-input-number
                v-model="formModel.minimumFeeAmount"
                :min="0"
                :placeholder="$t('please_enter')"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('maximum_charge_amount')" prop="maximumFeeAmount">
              <el-input-number
                v-model="formModel.maximumFeeAmount"
                :min="0"
                :placeholder="$t('please_enter')"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('fixed_amount')" prop="fixAmount">
              <el-input-number
                v-model="formModel.fixAmount"
                :min="0"
                :placeholder="$t('please_enter')"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('currency_unit')" prop="dollarUnit">
              <el-input v-model="formModel.dollarUnit" :placeholder="$t('please_enter')" />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('fixed_rate')" prop="fixRate">
              <el-input-number
                v-model="formModel.fixRate"
                :min="0"
                :placeholder="$t('please_enter')"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('sbl_reference_rate')" prop="interestRate">
              <el-input
                v-model="formModel.interestRate"
                :placeholder="$t('please_enter')"
                @input="formModel.interestRate = filterSpecialChars(formModel.interestRate)"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <div class="section-divider-title">
          <span>{{ $t('tiered_rate_amount') }}</span>
        </div>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item
              :label="$t('tiered_rate_order_qty')"
              label-width="240px"
              class="label-nowrap"
              prop="amountNoOfOrders"
            >
              <el-input-number
                v-model="formModel.amountNoOfOrders"
                :min="0"
                :placeholder="$t('please_enter')"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('tiered_rate_rate_amount')" prop="rateAmount">
              <el-input-number
                v-model="formModel.rateAmount"
                :min="0"
                :placeholder="$t('please_enter')"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item
              :label="$t('apply_min_max_before_qty')"
              prop="applyMinimumMaximumBeforeApplyQty"
            >
              <el-radio-group v-model="formModel.applyMinimumMaximumBeforeApplyQty">
                <el-radio :label="true">{{ $t('yes') }}</el-radio>
                <el-radio :label="false">{{ $t('no') }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <template #footer>
      <CustomDialogFooter>
        <el-button v-if="!isReadOnly" type="primary" :loading="isSubmitting" @click="handleSubmit">
          {{ $t('determine') }}
        </el-button>
        <el-button @click="handleCancel">{{ $t(isReadOnly ? 'close' : 'cancel') }}</el-button>
      </CustomDialogFooter>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { computed, ref, reactive, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage, FormInstance, FormRules } from 'element-plus'
import CustomDialogFooter from '@/components/custom-dialog-footer.vue'
import CheckLang from '@/components/check-lang/check-lang'
import { SelectOptions } from '@/types'
import { OperateMode } from './enums'
import { useCard } from '@/api/quotation/settingQuo'
import { IFeeSaveParams, saveFee, fetchFeeDetail } from '@/api-v2/quotation/fee'

const { t } = useI18n()

const emit = defineEmits<{
  (e: 'success'): void
}>()

interface IDictItem {
  [key: string]: unknown
}

type IDictItemTupleOrObject = [string | number, string] | IDictItem

const roundingMethodOptions = ref<SelectOptions>([])
const feeCurrencyTypeOptions = ref<SelectOptions>([])
const feeCategoryOptions = ref<SelectOptions>([])
const subTransactions = ref<SelectOptions>([])
const currencyOptions = ref<SelectOptions>([])
const chargeTypeOptions = ref<SelectOptions>([])
const chargeActionOptions = ref<SelectOptions>([])

function parseDictOptions(items?: IDictItemTupleOrObject[]): SelectOptions {
  if (!items || !Array.isArray(items)) return []
  return items.map((item) => {
    if (Array.isArray(item)) {
      return {
        value: String(item[0]),
        label: item[1] ? String(item[1]) : String(item[0]),
      }
    }
    return {
      value: '',
      label: '',
    }
  })
}

async function fetchDictOptions() {
  try {
    const res = await useCard({
      types: [
        'rounding_method',
        'fee_currency',
        'fee_category',
        'sub_transaction_type',
        'currency',
        'charge_operation',
        'charge_type',
      ],
    })
    if (res && res.result) {
      if (res.result.rounding_method) {
        roundingMethodOptions.value = parseDictOptions(res.result.rounding_method)
      }
      if (res.result.fee_currency) {
        feeCurrencyTypeOptions.value = parseDictOptions(res.result.fee_currency)
      }
      if (res.result.fee_category) {
        feeCategoryOptions.value = parseDictOptions(res.result.fee_category)
      }
      if (res.result.sub_transaction_type) {
        subTransactions.value = parseDictOptions(res.result.sub_transaction_type)
      }
      if (res.result.currency) {
        currencyOptions.value = parseDictOptions(res.result.currency)
      }
      if (res.result.charge_operation) {
        chargeActionOptions.value = parseDictOptions(res.result.charge_operation)
      }
      if (res.result.charge_type) {
        chargeTypeOptions.value = parseDictOptions(res.result.charge_type)
      }
    }
  } catch (err) {
    console.error('Failed to fetch dict options via useCard:', err)
  }
}

onMounted(() => {
  fetchDictOptions()
})

const dialogVisible = ref(false)
const isLoading = ref(false)
const isSubmitting = ref(false)
const mode = ref<OperateMode>(OperateMode.Add)
const currentLang = ref('zh-CN')

const formRef = ref<FormInstance>()

function getDefaultFormValues(): IFeeSaveParams {
  return {
    id: '',
    isStandard: false,
    name: '',
    otherLanguage: '',
    roundingMethod: '',
    roundingDecimal: undefined,
    feeCurrency: '',
    feeCategory: '',
    subTransactionType: '',
    currency: '',
    country: '',
    formatSelection: '',
    applyMultipleChannelsMinimumMaximum: false,
    showZeroAmountInStatementPreconf: false,
    generateBrokerSettlementGl: false,
    channelId: '',
    defaultFlag: false,
    channelClassId: '',
    brokerId: '',
    chargeOperation: '',
    defaultOnlineChannelFeeSetting: false,
    chargeType: '',
    minimumFeeAmount: undefined,
    maximumFeeAmount: undefined,
    fixAmount: undefined,
    dollarUnit: undefined,
    fixRate: undefined,
    interestRate: '',
    amountNoOfOrders: undefined,
    rateAmount: undefined,
    applyMinimumMaximumBeforeApplyQty: false,
  }
}

const formModel = ref<IFeeSaveParams>(getDefaultFormValues())

const title = computed(() => {
  if (mode.value === OperateMode.Add) return t('add_fee')
  if (mode.value === OperateMode.Edit) return t('edit_fee')
  if (mode.value === OperateMode.Detail) return t('view_fee')
  return t('fee_setting')
})

const specialCharReg = /[`~!@#$%^&*()+=|{}':;',[\]<>/?~！@#￥%……&*（）——+|{}【】‘；：""’。，、？\\]/

function filterSpecialChars(val?: string): string {
  if (!val) return ''
  return val.replace(
    /[`~!@#$%^&*()+=|{}':;',[\]<>/?~！@#￥%……&*（）——+|{}【】‘；：""’。，、？\\]/g,
    ''
  )
}

function validateNoSpecialChars(_rule: unknown, value: string, callback: (error?: Error) => void) {
  if (value && specialCharReg.test(value)) {
    return callback(new Error(t('no_special_characters')))
  }
  callback()
}

function validateMinFeeAmount(
  _rule: unknown,
  _value: number | undefined,
  callback: (error?: Error) => void
) {
  const min = formModel.value.minimumFeeAmount
  const max = formModel.value.maximumFeeAmount
  if (min !== undefined && min !== null && max !== undefined && max !== null && min > max) {
    return callback(new Error(t('min_fee_exceed_max_fee_warning')))
  }
  callback()
}

function validateMaxFeeAmount(
  _rule: unknown,
  _value: number | undefined,
  callback: (error?: Error) => void
) {
  const min = formModel.value.minimumFeeAmount
  const max = formModel.value.maximumFeeAmount
  if (min !== undefined && min !== null && max !== undefined && max !== null && min > max) {
    return callback(new Error(t('min_fee_exceed_max_fee_warning')))
  }
  callback()
}

const isReadOnly = computed(() => mode.value === OperateMode.Detail)
const isIdDisabled = computed(() => mode.value !== OperateMode.Add)

const formRules = reactive<FormRules>({
  id: [
    { required: true, message: () => t('please_enter'), trigger: 'blur' },
    { validator: validateNoSpecialChars, trigger: ['blur', 'change'] },
  ],
  name: [
    { required: true, message: () => t('please_enter'), trigger: 'blur' },
    { validator: validateNoSpecialChars, trigger: ['blur', 'change'] },
  ],
  country: [{ validator: validateNoSpecialChars, trigger: ['blur', 'change'] }],
  formatSelection: [{ validator: validateNoSpecialChars, trigger: ['blur', 'change'] }],
  channelId: [{ validator: validateNoSpecialChars, trigger: ['blur', 'change'] }],
  channelClassId: [{ validator: validateNoSpecialChars, trigger: ['blur', 'change'] }],
  interestRate: [{ validator: validateNoSpecialChars, trigger: ['blur', 'change'] }],
  roundingMethod: [{ required: true, message: () => t('please_select'), trigger: 'change' }],
  roundingDecimal: [{ required: true, message: () => t('please_enter'), trigger: 'blur' }],
  feeCurrency: [{ required: true, message: () => t('please_select'), trigger: 'change' }],
  feeCategory: [{ required: true, message: () => t('please_select'), trigger: 'change' }],
  currency: [{ required: true, message: () => t('please_select'), trigger: 'change' }],
  chargeOperation: [{ required: true, message: () => t('please_select'), trigger: 'change' }],
  chargeType: [{ required: true, message: () => t('please_select'), trigger: 'change' }],
  fixAmount: [{ required: true, message: () => t('please_enter'), trigger: 'blur' }],
  minimumFeeAmount: [{ validator: validateMinFeeAmount, trigger: ['blur', 'change'] }],
  maximumFeeAmount: [{ validator: validateMaxFeeAmount, trigger: ['blur', 'change'] }],
})

async function open(_mode: OperateMode = OperateMode.Add, feeId?: string) {
  mode.value = _mode
  formModel.value = getDefaultFormValues()
  dialogVisible.value = true

  if (
    !roundingMethodOptions.value.length ||
    !feeCurrencyTypeOptions.value.length ||
    !feeCategoryOptions.value.length
  ) {
    fetchDictOptions()
  }

  if ((_mode === OperateMode.Edit || _mode === OperateMode.Detail) && feeId) {
    isLoading.value = true
    try {
      const res = await fetchFeeDetail(feeId)
      if (res && res.result) {
        formModel.value = {
          ...getDefaultFormValues(),
          ...res.result,
        }
      }
    } catch (err) {
      console.error(err)
    } finally {
      isLoading.value = false
    }
  }
}

function handleCancel() {
  dialogVisible.value = false
}

function handleClose() {
  formRef.value?.resetFields()
  formModel.value = getDefaultFormValues()
}

async function handleSubmit() {
  if (!formRef.value) return
  await formRef.value.validate(async (valid) => {
    if (!valid) return
    isSubmitting.value = true
    try {
      const res = await saveFee(formModel.value)
      if (res && res.code === 0) {
        ElMessage.success(t('save_success'))
        dialogVisible.value = false
        emit('success')
      }
    } catch (err) {
      console.error(err)
    } finally {
      isSubmitting.value = false
    }
  })
}

defineExpose({
  open,
})
</script>

<style lang="scss" scoped>
.label-nowrap :deep(.el-form-item__label) {
  white-space: nowrap;
}

.edit-fee-dialog-content {
  padding: 0 10px;

  :deep(.el-select),
  :deep(.el-input-number),
  :deep(.el-textarea),
  :deep(.el-input) {
    width: 100% !important;
  }
}

.header-lang {
  display: flex;
  justify-content: flex-start;
  margin-bottom: 16px;
}

.w-full {
  width: 100%;
}

.inline-flex-item {
  display: flex;
  align-items: center;
  width: 100%;
}

.ml10 {
  margin-left: 10px;
}

.mr5 {
  margin-right: 5px;
}

.section-divider-title {
  margin: 16px auto;
  padding-bottom: 8px;
  border-bottom: 1px solid var(--el-border-color-lighter, #e4e7ed);
  font-weight: bold;
  font-size: 14px;
  color: var(--el-text-color-primary, #303133);
  text-align: center;
}
</style>
