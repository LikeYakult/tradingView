<template>
  <el-dialog
    v-model="visible"
    :title="$t('exchange_quotation')"
    width="880px"
    center
    destroy-on-close
    :close-on-click-modal="false"
    :close-on-press-escape="!submitting"
    :show-close="!submitting"
    @close="onClose"
  >
    <div v-loading="loading" class="exchange-content">
      <el-alert :title="$t('exchange_warning')" type="warning" :closable="false" />

      <h3 class="section-title">{{ $t('exchange_current_package') }}</h3>
      <el-descriptions direction="vertical" :column="3" border>
        <el-descriptions-item :label="$t('quote_market')">
          {{ order?.productName || '--' }}
        </el-descriptions-item>
        <el-descriptions-item :label="$t('exchange_current_package')">
          {{ order?.packageName || '--' }}
        </el-descriptions-item>
        <el-descriptions-item :label="$t('exchange_auto_renew')">
          {{ order?.autoRenew === true ? $t('yes') : order?.autoRenew === false ? $t('no') : '--' }}
        </el-descriptions-item>
      </el-descriptions>

      <h3 class="section-title">{{ $t('exchange_select_package') }}</h3>
      <el-select
        v-model="newPackageId"
        class="package-select"
        :placeholder="$t('exchange_select_placeholder')"
        :no-data-text="$t('exchange_no_packages')"
        :disabled="loading || submitting || !loaded"
      >
        <el-option
          v-for="item in packages"
          :key="item.packageId"
          :label="item.packageName"
          :value="item.packageId"
        />
      </el-select>
      <p class="package-hint">{{ $t('exchange_package_hint') }}</p>

      <div class="exchange-description">
        <p v-if="selectedPackage">
          {{
            $t('exchange_amount_tip', {
              currency: selectedPackage.currency,
              amount: selectedPackage.price,
            })
          }}
        </p>
        <p>{{ $t('exchange_transition_tip') }}</p>
      </div>
    </div>

    <template #footer>
      <CustomDialogFooter>
        <el-button
          class="exchange-action"
          type="primary"
          :loading="submitting"
          :disabled="loading || !loaded || !selectedPackage"
          @click="submit"
        >
          {{ $t('exchange_submit_review') }}
        </el-button>
        <el-button class="exchange-action" :disabled="submitting" @click="visible = false">
          {{ $t('cancel') }}
        </el-button>
      </CustomDialogFooter>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { useI18n } from 'vue-i18n'
import CustomDialogFooter from '@/components/custom-dialog-footer.vue'
import {
  fetchPackageOptions,
  fetchQuotationOrderDetail,
  IPackageOptionItem,
} from '@/api-v2/quotation/query'
import { applyQuotationExchange } from '@/api-v2/quotation/mutations'
import { getExchangePackages, IExchangeOrder } from './exchange'

const emit = defineEmits<{ (e: 'callback'): void }>()
const { t } = useI18n()
const visible = ref(false)
const loading = ref(false)
const loaded = ref(false)
const submitting = ref(false)
const order = ref<IExchangeOrder>()
const packages = ref<IPackageOptionItem[]>([])
const newPackageId = ref('')
const selectedPackage = computed(() =>
  packages.value.find((item) => item.packageId === newPackageId.value)
)
let requestId = 0

async function open(row: IExchangeOrder) {
  if (submitting.value) return
  const currentRequestId = ++requestId
  order.value = { ...row }
  packages.value = []
  newPackageId.value = ''
  loaded.value = false
  loading.value = true
  visible.value = true

  try {
    const [detailRes, packageRes] = await Promise.all([
      fetchQuotationOrderDetail(row.orderId),
      fetchPackageOptions(2, row.tradeAccount),
    ])
    if (currentRequestId !== requestId) return

    order.value = { ...row, ...detailRes.result }
    packages.value = getExchangePackages(order.value as IExchangeOrder, packageRes.result)
    loaded.value = true
  } catch (error) {
    console.error('获取换购信息失败', error)
  } finally {
    if (currentRequestId === requestId) loading.value = false
  }
}

function onClose() {
  // 丢弃关闭前的请求，避免重新打开时被旧订单数据覆盖。
  requestId++
}

async function submit() {
  if (
    submitting.value ||
    loading.value ||
    !loaded.value ||
    !order.value ||
    !selectedPackage.value
  ) {
    return
  }

  submitting.value = true
  try {
    await applyQuotationExchange({
      customerId: order.value.customerId,
      tradeAccount: order.value.tradeAccount,
      oldOrderId: order.value.orderId,
      newPackageId: selectedPackage.value.packageId,
      remark: '',
      subType: 2,
    })
    visible.value = false
    ElMessage.success(t('exchange_submit_success'))
    emit('callback')
  } catch (error) {
    console.error('提交换购失败', error)
  } finally {
    submitting.value = false
  }
}

defineExpose({ open })
</script>

<style scoped lang="scss">
.exchange-action {
  width: 120px;
}

.exchange-content {
  padding: 0 20px;
}

.section-title {
  margin: 24px 0;
  padding-left: 12px;
  border-left: 3px solid var(--el-color-primary);
  font-size: 14px;
  line-height: 28px;
}

.package-select {
  width: 100%;
}

.package-hint {
  margin: 12px 0 24px;
  color: var(--el-text-color-secondary);
}

.exchange-description {
  padding: 12px;
  border: 1px solid var(--el-border-color);
  background: var(--el-fill-color-light);
  line-height: 26px;

  p {
    margin: 0;
  }
}
</style>
