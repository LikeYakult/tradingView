import type { IPackageOptionItem } from '@/api-v2/quotation/query'
import { OrderEnableStatus } from '@/types/quotationType'

interface IExchangeableOrder {
  isGive?: boolean
  /** 接口返回的订单生效状态原始编码。 */
  orderEnableStatusOriginal?: OrderEnableStatus
}

export interface IExchangeOrder extends IExchangeableOrder {
  orderId: string
  customerId: number
  tradeAccount: string
  packageId: string
  packageName: string
  productId?: number | string
  productName?: string
  autoRenew?: boolean
}

export function canExchangeOrder(order: IExchangeableOrder) {
  return order.isGive === false && order.orderEnableStatusOriginal === OrderEnableStatus.Effective
}

export function getExchangePackages(order: IExchangeOrder, packages: IPackageOptionItem[]) {
  return packages.filter((item) => {
    if (String(item.packageId) === String(order.packageId)) return false
    if (order.productId != null && item.productId != null) {
      return String(item.productId) === String(order.productId)
    }
    return !!order.productName && item.productName === order.productName
  })
}
