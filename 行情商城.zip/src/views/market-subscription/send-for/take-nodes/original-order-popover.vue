<template>
  <el-popover
    v-model:visible="visible"
    placement="bottom-start"
    :width="340"
    trigger="click"
    :disabled="!canViewDetail"
    @show="loadDetail"
    @hide="onHide"
  >
    <template #reference>
      <button
        type="button"
        class="original-order-link"
        :class="{ 'is-open': visible }"
        :disabled="!canViewDetail"
      >
        {{ orderId }}
      </button>
    </template>
    <div v-loading="loading" class="original-order-content">
      <p>{{ $t('original_order_number') }}：{{ orderId }}</p>
      <template v-if="!loadFailed">
        <p>RTQ＋{{ $t('package') }}：{{ displayValue(detail?.packageName) }}</p>
        <p>{{ $t('expected_deduction_time') }}：{{ deductionTypeLabel }}</p>
        <p>{{ $t('amount_paid') }}：{{ displayValue(detail?.amount) }} {{ detail?.currency }}</p>
      </template>
      <p v-else>{{ $t('request_failed') }}</p>
    </div>
    <div class="original-order-actions">
      <el-button type="primary" @click="visible = false">{{ $t('got_it') }}</el-button>
    </div>
  </el-popover>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { useAppStore } from '@/store'

const appStore = useAppStore()
import { fetchQuotationOrderDetail } from '@/api-v2/quotation/query'

interface IOriginalOrderDetail {
  packageName?: string
  deductTimeType?: 'NOW' | 'MONTH_END' | 'NO'
  amount?: string | number
  currency?: string
}

const props = defineProps<{ orderId: string }>()
const { t } = useI18n()
const visible = ref(false)
const loading = ref(false)
const loadFailed = ref(false)
const detail = ref<IOriginalOrderDetail>()
const canViewDetail = computed(() => Boolean(appStore.permissions['quo:order:detail']))
const deductionTypeLabel = computed(() => {
  switch (detail.value?.deductTimeType) {
    case 'NOW':
      return t('current_deduction')
    case 'MONTH_END':
      return t('end_month_deduction')
    case 'NO':
      return t('presented')
    default:
      return '--'
  }
})
let requestId = 0

function displayValue(value: string | number | null | undefined) {
  return value === undefined || value === null || value === '' ? '--' : value
}

async function loadDetail() {
  if (!canViewDetail.value) return

  const currentRequestId = ++requestId
  detail.value = undefined
  loadFailed.value = false
  loading.value = true
  try {
    const res = await fetchQuotationOrderDetail(props.orderId)
    if (currentRequestId === requestId) detail.value = res.result
  } catch (error) {
    if (currentRequestId === requestId) {
      loadFailed.value = true
      console.error('获取原订单详情失败', error)
    }
  } finally {
    if (currentRequestId === requestId) loading.value = false
  }
}

function onHide() {
  requestId++
  detail.value = undefined
  loading.value = false
}

onBeforeUnmount(onHide)
</script>

<style lang="scss" scoped>
.original-order-link {
  padding: 0;
  border: 0;
  background: transparent;
  color: inherit;
  font: inherit;
  text-decoration: underline;
  text-underline-offset: 3px;
  cursor: pointer;

  &:hover,
  &:active,
  &:focus-visible,
  &.is-open {
    color: #1677ff;
  }

  &:focus-visible {
    outline: 2px solid currentcolor;
    outline-offset: 3px;
  }

  &:disabled {
    color: var(--el-disabled-text-color);
    text-decoration: none;
    cursor: not-allowed;
  }
}

.original-order-content {
  min-height: 144px;
  overflow-wrap: anywhere;

  p {
    margin: 0 0 14px;
    line-height: 22px;
  }
}

.original-order-actions {
  text-align: center;
}
</style>
