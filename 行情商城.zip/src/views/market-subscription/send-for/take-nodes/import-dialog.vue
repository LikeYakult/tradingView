<template>
  <el-dialog v-model="visible" :close-on-click-modal="false" width="550px" @close="close()">
    <template #title>
      <span v-if="!importResult">{{ title || $t('bulk_import') }}</span>
      <span v-else>{{ $t('import_result') }}</span>
    </template>
    <div v-if="!importResult" class="tool">
      <div class="tool-content">
        <el-upload action="" :auto-upload="true" :file-list="fileList" :http-request="uFile">
          <el-button size="small">{{ title || $t('bulk_import') }}</el-button>
        </el-upload>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <el-button type="text" size="small" @click="downloadTemp()">{{
          $t('download_template')
        }}</el-button>
      </div>
    </div>
    <div v-else class="import-result">
      <p>
        <span>{{ t('total_count') }}:</span><span>{{ importResult?.total }}</span>
      </p>
      <p>
        <span>{{ t('success_count') }}:</span><span>{{ importResult?.successCount }}</span>
      </p>
      <p>
        <span> {{ t('failure_count') }}: </span>
        <span :class="importResult?.failCount > 0 ? 'error-count' : ''">
          {{ importResult?.failCount }}
        </span>
      </p>
    </div>
    <template #footer>
      <div v-if="!importResult" class="import-actions">
        <el-button type="primary" size="small" :loading="isBtnLoading" @click="uploadOrder">{{
          $t('confirm_upload')
        }}</el-button>
      </div>
      <div v-else class="import-actions">
        <el-button type="primary" @click="toImportLog()">{{ t('view_import_log') }}</el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, defineExpose } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage, ElMessageBox } from 'element-plus'
import { uploadFile } from '@/api-v2/quotation/quotation'
import { templateExport, orderImportProgress } from '@/api-v2/quotation/order'
import { useRouter } from 'vue-router'

const { t } = useI18n()
const props = defineProps({
  title: {
    type: String,
    default: '',
  },
})
const emits = defineEmits(['callback'])

const router = useRouter()
const isBtnLoading = ref(false)
const importResult = ref(null)
const pollInterval = ref<number>()
const fileList = ref([])
const visible = ref(false)
let fileData = new FormData()

function uFile(params: Record<string, any>) {
  fileData.append('file', params.file)
}

function open() {
  visible.value = true
}

const toImportLog = () => {
  pollInterval.value && clearInterval(pollInterval.value)
  router.push({ path: '/market-subscription/send-for/file-import-log' })
}

function close() {
  fileData = new FormData()
  fileList.value = []
  importResult.value = null
  isBtnLoading.value = false
  visible.value = false

  if (pollInterval.value) {
    clearInterval(pollInterval.value)
    pollInterval.value = undefined
  }

  emits('callback')
}

// 轮询查询导入进度
function pollImportProgress(key: string) {
  pollInterval.value = setInterval(() => {
    orderImportProgress({ key }).then((res) => {
      if (res.code === 0) {
        importResult.value = res.result
        const { total, successCount } = res.result
        if (total === successCount) {
          // 导入完成，清除定时器
          clearInterval(pollInterval.value)
        }
      } else {
        // clearInterval(pollInterval.value)
      }
    })
  }, 2000) // 每2秒轮询一次
}

// 文件上传
function uploadOrder() {
  const file = fileData.get('file')
  if (!file) {
    ElMessage.warning(t('upload_file_prompt'))
    return
  }

  const { name } = file
  if (name.includes('xls') || name.includes('xlsx')) {
    isBtnLoading.value = true

    uploadFile(fileData)
      .then((res) => {
        if (res.data.code === 0) {
          ElMessage.success(t('upload_success'))
          importResult.value = res.data.result
          // 轮询查询导入进度
          pollImportProgress(res.data.result.key)

          // close()
          emits('callback')
        } else {
          ElMessageBox.alert(res.data.message, t('tip'), {
            confirmButtonText: t('determine'),
            type: 'error',
          })
        }
      })
      .finally(() => {
        isBtnLoading.value = false
      })
    return
  }

  ElMessage.warning(t('model_file_tip'))
}

function downloadTemp() {
  templateExport()
}

defineExpose({
  open,
  close,
})
</script>

<style lang="scss" scoped>
.el-dialog__header {
  span {
    font-family: PingFangSC-Medium;
    font-weight: 500;
    font-size: 20px;
    color: #212121;
  }
}
.tool-content {
  width: 144px;
  margin: 0 auto;
  display: flex;
}

.import-actions {
  text-align: center;
}

.import-result {
  display: flex;
  flex-direction: column;
  align-items: center;
  font-size: 16px;

  p {
    padding-top: 18px;
    margin: 0;
  }

  .error-count {
    color: red;
  }
}
</style>
