export enum OperateMode {
  Add = 'Add',
  Edit = 'Edit',
  Audit = 'Audit',
  Detail = 'Detail',
}

export enum UserTypes {
  All = 'All',
  Pro = 'Pro',
  NonPro = 'NonPro',
}
