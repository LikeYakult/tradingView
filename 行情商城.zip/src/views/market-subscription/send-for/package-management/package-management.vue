<template>
  <!-- 套餐管理-串流行情套餐 -->
  <div class="page-container">
    <base-filter
      :loading="isLoading"
      :config="filterConfig"
      @on-search="searchHandle"
      @on-reset="resetHandle"
    ></base-filter>
    <div class="tool operate-buttons">
      <el-button
        class="toolbar-add-button"
        v-permission="'quo:package:add'"
        type="primary"
        @click="openAddDialog()"
        >{{ $t('add_stream_market_package') }}</el-button
      >
    </div>
    <base-table :config="tableConfig" :pagination="pagination" :is-table-loading="isLoading">
      <template #packageName>
        <el-table-column align="center" :label="$t('package_name')" width="200px" prop="name">
          <template #default="scope">
            <span class="text-primary mr10" @click="openEditDialog(scope.row, true)">
              {{ scope.row.packageName }}
            </span>
          </template>
        </el-table-column>
      </template>

      <template #enableDate>
        <el-table-column
          align="center"
          :label="$t('expiration_date')"
          width="200px"
          sortable="custom"
          prop="enableStart"
        >
          <template #default="scope">
            <div>{{ scope.row.enableStart }} -- {{ scope.row.enableEnd }}</div>
          </template>
        </el-table-column>
      </template>

      <template #handler>
        <el-table-column align="center" :label="$t('operate')" width="210px" fixed="right">
          <template #default="scope">
            <div>
              <div>
                <el-button
                  v-permission="'quo:package:edit'"
                  type="text"
                  class="text-primary"
                  :disabled="scope.row.status === AuditStatus.Success"
                  @click="openEditDialog(scope.row)"
                >
                  <span>{{ $t('modify') }}</span>
                </el-button>
                <el-button
                  v-permission="'quo:package:delete'"
                  type="text"
                  class="text-primary"
                  :disabled="scope.row.status === AuditStatus.Success"
                  @click="deletePackage(scope.row.packageId)"
                >
                  <span>{{ $t('delete') }}</span>
                </el-button>
                <action-confirm
                  :title="
                    scope.row.enable === EnableStatus.Disable
                      ? $t('sure_to_enable_package')
                      : $t('sure_to_disable_named_package', { packageName: scope.row.packageName })
                  "
                  :confirm-button-text="$t('determine')"
                  :cancel-button-text="$t('cancel')"
                  @confirm="enablePackage(scope.row.packageId)"
                >
                  <template #reference>
                    <el-button
                      v-permission="'quo:package:enable'"
                      type="text"
                      class="text-primary"
                      >{{
                        scope.row.enable === EnableStatus.Disable ? $t('enabled') : $t('disable')
                      }}</el-button
                    >
                  </template>
                </action-confirm>
                <el-button
                  v-permission="'quo:package:review'"
                  type="text"
                  class="text-primary"
                  :disabled="scope.row.status !== AuditStatus.ReviewIng"
                  @click="openAuditDialog(scope.row)"
                  >{{ $t('audit') }}</el-button
                >
              </div>
            </div>
          </template>
        </el-table-column>
      </template>
    </base-table>

    <editOrderDialog
      ref="editOrderRef"
      :terminal-options="terminalOptions"
      :product-list-options="productListOptions"
      :currency-options="currencyOptions"
      :package-region-options="packageRegionOptions"
      :pi-type-options="piTypeOptions"
      :account-type-options="accountTypeOptions"
      :fee-category-options="feeCategoryOptions"
      :charge-options="chargeOptions"
      :calculation-period-options="calculationPeriodOptions"
      :calculation-method-options="calculationMethodOptions"
      :full-customer-options="fullCustomerOptions"
      :waive-type-options="waiveTypeOptions"
      @callback="getData"
    />
  </div>
</template>

<script setup lang="ts">
import { reactive, onBeforeMount, ref, onMounted, Ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage, ElMessageBox } from 'element-plus'
import baseTable from '@/components/base-table/base-table'
import baseFilter from '@/components/base-filter/base-filter'
import editOrderDialog from './edit-order-dialog.vue'
import {
  packageList,
  packageDelete,
  packageEnable,
  fetchFeeConditionList,
} from '@/api-v2/quotation'
import { formToParams } from '@/utils'
import { AuditStatus, EnableStatus } from '@/types/quotationType'
import { fetchDicts, fetchPackageDetail, fetchProductList } from '@/api-v2/quotation/query'
import { SelectOptions } from '@/types'
import { extractDict } from '@/utils/options-dictionary'
import { OperateMode } from './enums'
import { IInitFormValues } from './edit-order-dialog-content.vue'

// #region options
const reviewStatusOptions = ref<SelectOptions>([])
const packageEnableStatusOptions = ref<SelectOptions>([])
const productListOptions = ref<SelectOptions<number>>([])
const terminalOptions = ref<SelectOptions>([])
const currencyOptions = ref<SelectOptions>([])
const packageRegionOptions = ref<SelectOptions>([])
const piTypeOptions = ref<SelectOptions>([])
const accountTypeOptions = ref<SelectOptions>([])
const feeCategoryOptions = ref<SelectOptions>([])
const chargeOptions = ref<SelectOptions>([])
const calculationPeriodOptions = ref<SelectOptions>([])
const calculationMethodOptions = ref<SelectOptions>([])
const fullCustomerOptions = ref<SelectOptions>([])
const waiveTypeOptions = ref<SelectOptions>([])

function initDicts() {
  const dictPairs: [string, Ref<SelectOptions>][] = [
    ['review_status', reviewStatusOptions],
    ['package_enable_staus', packageEnableStatusOptions],
    ['terminal', terminalOptions],
    ['currency', currencyOptions],
    ['package_region', packageRegionOptions],
    ['pi_type', piTypeOptions],
    ['account_type', accountTypeOptions],
    ['charge_method', chargeOptions],
    ['calculation_period', calculationPeriodOptions],
    ['calculation_method', calculationMethodOptions],
    ['full_customer', fullCustomerOptions],
    ['waive_type', waiveTypeOptions],
  ]

  const keys = dictPairs.map((item) => item[0])

  fetchDicts(keys).then((res) => {
    dictPairs.forEach((item) => {
      extractDict(res?.result?.[item[0]], item[1])
    })
    console.log('dict: ', currencyOptions)
  })

  fetchProductList().then((res) => {
    productListOptions.value = res.result.map((v) => ({
      label: v.name,
      value: v.productId,
    }))
  })

  fetchFeeConditionList().then((res) => {
    feeCategoryOptions.value = (res.result || []).map((v) => ({
      label: v.name,
      value: v.id,
    }))
  })
}
// #endregion

onBeforeMount(() => {
  initDicts()
})

const editOrderRef = ref()

const { t } = useI18n()
const isLoading = ref<boolean>(false)
const ordering = ref({
  asc: false,
  column: 'createTime',
})

function fetchDialogDetail(packageId: string): Promise<IInitFormValues['form']> {
  return fetchPackageDetail(packageId).then((res) => {
    const {
      isPi,
      accountType,
      currency,
      enable,
      enableEnd,
      enableStart,
      i18nMap,
      packageId,
      price,
      productId,
      region,
      terminal,
      rtq,
      calculationMethod,
      calculationPeriod,
      defaultAuthorize,
      enableWaive,
      waiveList,
      feeId,
      chargeMethod,
      snapshotMonthlyBasicFreeQuote,
      targetCustomer,
      vipPackage,
      isDefault,
      waiveOnRenew,
    } = res.result

    return {
      enable: enable === 'enable' ? true : false,
      isPi,

      accountType,
      calculationMethod,
      calculationPeriod,
      currency,
      defaultAuthorize,
      enableEnd,
      enableWaive,
      enableStart,
      waiveList,
      feeId,
      chargeMethod,
      i18nMap,
      snapshotMonthlyBasicFreeQuote,
      packageId: packageId || undefined,
      price,
      productId: productId as number,
      region,
      targetCustomer,
      terminal,
      rtq,
      vipPackage,
      isDefault,
      waiveOnRenew,
    }
  })
}

function openAddDialog() {
  editOrderRef.value.open()
}

function openEditDialog(v: Record<string, any>, readonly = false) {
  editOrderRef.value.open(readonly ? OperateMode.Detail : OperateMode.Edit, {
    load: () => fetchDialogDetail(v.packageId).then((form) => ({ form })),
  })
}

function openAuditDialog(v: Record<string, any>) {
  editOrderRef.value.open(OperateMode.Audit, {
    load: () => fetchDialogDetail(v.packageId).then((form) => ({ form })),
  })
}

// function getStatusText(enableEndTime: string, enable: boolean) {
//   const localeDate = new Date(enableEndTime).toLocaleDateString()
//   const enableEndDate = new Date(new Date(localeDate).getTime() + 24 * 60 * 60 * 1000 - 1)
//   const currentDate = new Date()

//   if (enableEndDate < currentDate) return t('invalidation')

//   if (enable) return t('enabled')

//   return t('disable')
// }

const quoPackages = ref([])

/** 串流行情 */
const tableConfig = reactive({
  tableProps: {
    data: [],
    height: '520',
  },
  tableEvent: {
    onSortChange: (column: Record<string, any>) => {
      const { order, prop } = column
      ordering.value.column = ''
      pagination.paginationProps.currentPage = 1

      if (order) {
        ordering.value = {
          asc: order === 'ascending',
          column: prop,
        }
        console.log(ordering.value, '<___ordering.value')
      }
      return getData()
    },
  },
  customColumns: [
    { label: t('package_id'), prop: 'rtq', minWidth: '160' },
    { slot: 'packageName' },
    { label: t('quote_market'), prop: 'productName', minWidth: '160' },
    // { label: t('price'), prop: 'price', minWidth: '160', sortable: 'custom' },
    { label: t('creation_time'), prop: 'createTime', minWidth: '180', sortable: 'custom' },
    { slot: 'enableDate' },
    { label: t('state'), prop: 'enableName', minWidth: '150' },
    { label: t('audit_status'), prop: 'statusName', minWidth: '150' },
    { slot: 'handler' },
  ],
})

const pagination: Record<string, any> = reactive({
  paginationProps: {
    currentPage: 1,
    pageSize: 20,
    total: 0,
  },
  paginationEvent: {
    onSizeChange: (v: number | string) => {
      pagination.paginationProps.pageSize = v
      getData()
    },
    onCurrentChange: (v: number | string) => {
      pagination.paginationProps.currentPage = v
      getData()
    },
  },
})

/** 表单数据 */
const filterConfig = reactive({
  formProps: {
    model: {},
  },
  formItems: [
    {
      prop: 'createDate',
      label: t('creation_time'),
      innerEl: {
        elType: 'datePicke',
        props: { type: 'daterange', valueFormat: 'YYYY-MM-DD' },
      },
    },
    {
      prop: 'packageId',
      label: t('stream_market_package'),
      innerEl: {
        elType: 'select',
        options: quoPackages,
        props: {
          placeholder: t('please_select'),
        },
      },
    },
    {
      prop: 'status',
      label: t('audit_status'),
      innerEl: {
        elType: 'select',
        options: reviewStatusOptions,
        props: {
          placeholder: t('please_select'),
        },
      },
    },
    {
      prop: 'enable',
      label: t('state'),
      innerEl: {
        elType: 'select',
        options: packageEnableStatusOptions,
        props: {
          placeholder: t('please_select'),
        },
      },
    },
  ],
})
let type = 1

/**
 * 获取行情套餐
 */
function selectPackage() {
  packageList({ type, pageNum: 1, pageSize: 100000 }).then((res: any) => {
    quoPackages.value = res.result.records.map((v: any) => ({
      label: v.name || v.packageName,
      value: v.id || v.packageId,
    }))
  })
}

function getData() {
  isLoading.value = true
  // 分页
  const page: { [key: string]: string | number } = {
    type,
  }
  page.pageNum = pagination.paginationProps.currentPage
  page.pageSize = pagination.paginationProps.pageSize

  Object.assign(page, {
    orders: [ordering.value],
  })

  const params: any = { ...filterConfig.formProps.model }
  // 格式化时间
  if (params.createDate) {
    params.createDateStart = params.createDate[0]
    params.createDateEnd = params.createDate[1]
    delete params.createDate
  }

  // 查询条件
  packageList(formToParams({ ...page, ...params }))
    .then((res: any) => {
      const { records = [], current, size, total } = res?.result || {}

      const packageList = records.map((item: Record<string, any>) => {
        const { enable, enableEnd, defaultAuthorize, products = [] } = item

        const localeDate = new Date(enableEnd).toLocaleDateString()
        const enableEndDate = new Date(new Date(localeDate).getTime() + 24 * 60 * 60 * 1000 - 1)
        const currentDate = new Date()

        if (!defaultAuthorize && enableEndDate < currentDate) {
          item.stateLocal = -1
          item.stateLocalText = t('invalidation')
        } else if (enable) {
          item.stateLocal = 1
          item.stateLocalText = t('enabled')
        } else {
          item.stateLocal = 0
          item.stateLocalText = t('disable')
        }

        item.isNull = true
        if (products.length > 0) {
          let isNull = true
          products.forEach((product: any) => {
            if (product.type !== 3) {
              isNull = false
            }
          })
          item.isNull = isNull
        }

        return item
      })

      Object.assign(pagination.paginationProps, {
        currentPage: current,
        pageSize: size,
        total,
      })

      tableConfig.tableProps.data = packageList
      isLoading.value = false
    })
    .catch((err: any) => {
      console.log(err)
      isLoading.value = false
    })
}

function searchHandle() {
  getData()
}

function resetHandle() {
  getData()
}

// 删除套餐
function deletePackage(packageId: number) {
  ElMessageBox.confirm(t('sure_to_delete_package'), t('delete'), {
    customClass: 'list-action-message-box',
    confirmButtonText: t('determine'),
    cancelButtonText: t('cancel'),
    type: 'warning',
  }).then(() => {
    packageDelete({ packageId }).then(() => {
      ElMessage({
        type: 'success',
        message: t('delete_success'),
      })
      getData()
    })
  })
}

// 启用禁用
function enablePackage(packageId: number): any {
  packageEnable({ packageId }).then(() => {
    getData()
  })
}

function changeType() {
  getData()
  selectPackage()
}

onBeforeMount(() => {
  getData()
})

onMounted(() => {
  selectPackage()
})
</script>

<style lang="scss" scoped>
.tool {
  margin-bottom: var(--ui-toolbar-spacing);
}
</style>
