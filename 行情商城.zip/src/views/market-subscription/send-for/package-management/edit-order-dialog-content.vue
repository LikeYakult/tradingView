<template>
  <div>
    <el-form ref="formRef" class="form" :model="form" label-width="auto" :disabled="!canEditForm">
      <el-input v-model="form.packageId" type="hidden" />
      <check-lang v-model="lang" />

      <div class="edit-streaming-quote-box">
        <!-- 第 1 行: 套餐名称 | 套餐说明 -->
        <el-form-item
          :prop="'i18nList[' + langIndex + '].name'"
          :rules="{
            required: true,
            message: $t('please_enter_package_name'),
            trigger: 'change',
          }"
        >
          <template #label>
            <div class="lang-icon-label">
              <span>{{ $t('package_name') }}：</span>
              <img :src="checkLangImage" alt="" />
            </div>
          </template>
          <el-input
            v-model="form.i18nList[langIndex].name"
            maxlength="30"
            :placeholder="$t('please_enter')"
          />
        </el-form-item>

        <el-form-item
          :prop="'i18nList[' + langIndex + '].remark'"
          :rules="[
            {
              required: true,
              message: $t('please_enter_package_description'),
              trigger: 'change',
            },
            {
              max: 24,
              message: $t('character_length_hint_24'),
              trigger: 'change',
            },
          ]"
        >
          <template #label>
            <div class="lang-icon-label">
              <span>{{ $t('package_introductions') }}：</span>
              <img :src="checkLangImage" alt="" />
            </div>
          </template>
          <el-input
            v-model="form.i18nList[langIndex].remark"
            :placeholder="$t('character_length_hint_24')"
            :rows="3"
            type="text"
            class="remark-input"
          />
        </el-form-item>

        <!-- 第 2 行: 市场 | 套餐有效期 -->
        <el-form-item
          key="productId"
          :label="`${$t('quote_market')}：`"
          prop="productId"
          :rules="{
            required: true,
            message: $t('please_select_market_type'),
            trigger: 'change',
          }"
        >
          <el-select-v2
            v-model="form.productId"
            class="m-2"
            filterable
            :options="productListOptions"
            :placeholder="$t('please_select')"
          />
        </el-form-item>

        <el-form-item
          :label="`${$t('package_effective_period')}：`"
          prop="enableStart"
          :rules="{
            required: true,
            message: $t('please_select_package_effective_period'),
            trigger: 'change',
          }"
        >
          <div class="package-date-picker-container">
            <div>
              <el-date-picker
                v-model="form.enableStart"
                class="package-date-picker"
                :disabled-date="checkDisabledDate"
                type="date"
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                :clearable="false"
              />
            </div>
            <span class="package-date-picker-separator">~</span>
            <div>
              <el-date-picker
                v-model="enableEnd"
                class="package-date-picker"
                :disabled="true"
                type="date"
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                :clearable="false"
              />
            </div>
          </div>
        </el-form-item>

        <!-- 第 3 行: 行情适用终端 | 状态 -->
        <el-form-item :label="`${$t('market_uses_terminal')}：`" prop="terminal">
          <el-select
            v-model="form.terminal"
            multiple
            class="m-2"
            :placeholder="$t('please_select')"
          >
            <el-option
              v-for="item in terminalOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>

        <el-form-item :label="`${$t('state')}：`" :rules="{ required: true }" prop="enable">
          <el-radio-group v-model="form.enable">
            <el-radio :value="true">{{ $t('enabled') }}</el-radio>
            <el-radio :value="false">{{ $t('disable') }}</el-radio>
          </el-radio-group>
        </el-form-item>

        <!-- 第 4 行: 行情适用地区 | RTQ -->
        <el-form-item :label="`${$t('market_uses_area')}：`" prop="region">
          <el-radio-group v-model="form.region" class="region-group">
            <el-radio v-for="item in regionOptions" :key="item.value" :value="item.value">
              {{ item.label }}
            </el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item
          label="RTQ："
          prop="rtq"
          :rules="{
            required: true,
            message: $t('please_enter_RTQ'),
            trigger: 'change',
          }"
        >
          <el-input v-model="form.rtq" :placeholder="$t('please_enter_RTQ')" />
        </el-form-item>

        <!-- 第 5 行: 行情适用人群 | 行情使用账号类型 -->
        <el-form-item :label="`${$t('market_uses_group')}：`" prop="isPi">
          <el-radio-group v-model="form.isPi">
            <el-radio v-for="item in isPiOptions" :key="item.value" :value="item.value">
              {{ item.label }}
            </el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item :label="`${$t('market_uses_account_type')}：`" prop="accountType">
          <el-radio-group v-model="form.accountType">
            <el-radio v-for="item in _accountTypeOptions" :key="item.value" :value="item.value">
              {{ item.label }}
            </el-radio>
          </el-radio-group>
        </el-form-item>

        <!-- 第 6 行: 费用 | 默认 -->
        <el-form-item :label="`${$t('fee')}：`" prop="feeId">
          <el-select-v2
            v-model="form.feeId"
            class="m-2"
            filterable
            :options="feeCategoryOptions"
            :placeholder="$t('please_select')"
          />
        </el-form-item>

        <el-form-item :label="`${$t('default')}：`" prop="isDefault">
          <el-radio-group v-model="form.isDefault">
            <el-radio :value="true">{{ $t('yes') }}</el-radio>
            <el-radio :value="false">{{ $t('no') }}</el-radio>
          </el-radio-group>
        </el-form-item>

        <!-- 第 7 行: 费用方式 | VIP Package -->
        <el-form-item
          :label="`${$t('fee_method')}：`"
          :rules="{ required: true, message: $t('please_select_charge_method'), trigger: 'change' }"
          prop="chargeMethod"
        >
          <el-select v-model="form.chargeMethod" class="m-2" :placeholder="$t('please_select')">
            <el-option
              v-for="item in chargeOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>

        <el-form-item :label="`${$t('vip_package')}：`" prop="vipPackage">
          <el-input v-model="form.vipPackage" :placeholder="$t('please_enter')" />
        </el-form-item>

        <!-- 第 8 行: 启用豁免费用设定 | 续订仍执行豁免 -->
        <el-form-item :label="`${$t('enable_exemption_fee_setting')}：`" prop="enableWaive">
          <el-radio-group v-model="form.enableWaive">
            <el-radio :value="true">{{ $t('yes') }}</el-radio>
            <el-radio :value="false">{{ $t('no') }}</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item :label="`${$t('renew_still_execute_exemption')}：`" prop="waiveOnRenew">
          <el-radio-group v-model="form.waiveOnRenew">
            <el-radio :value="true">{{ $t('yes') }}</el-radio>
            <el-radio :value="false">{{ $t('no') }}</el-radio>
          </el-radio-group>
        </el-form-item>

        <!-- 第 9 行: 计算期 | 计算方式 -->
        <el-form-item :label="`${$t('calculation_period')}：`" prop="calculationPeriod">
          <el-select
            v-model="form.calculationPeriod"
            class="m-2"
            :disabled="exemptionFieldsDisabled"
            :placeholder="$t('please_select')"
          >
            <el-option
              v-for="item in calculationPeriodOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>

        <el-form-item :label="`${$t('calculation_method')}：`" prop="calculationMethod">
          <el-select
            v-model="form.calculationMethod"
            class="m-2"
            :disabled="exemptionFieldsDisabled"
            :placeholder="$t('please_select')"
          >
            <el-option
              v-for="item in calculationMethodOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
      </div>

      <div class="exemption-table-box">
        <div class="exemption-grid">
          <div class="exemption-grid-header">{{ $t('exemption_type') }}</div>
          <div class="exemption-grid-header">{{ $t('exemption_amount') }}</div>
          <div class="exemption-grid-header direct-gift-header">
            <span>{{ $t('direct_gift') }}</span>
            <el-popover
              placement="top"
              :width="280"
              trigger="click"
              :content="$t('direct_gift_tip')"
            >
              <template #reference>
                <el-icon class="question-icon"><QuestionFilled /></el-icon>
              </template>
            </el-popover>
          </div>
          <div class="exemption-grid-header">{{ $t('exemption_price') }}</div>
          <div class="exemption-grid-header">{{ $t('claim_valid_days') }}</div>
          <div class="exemption-grid-header">{{ $t('click_quote_count') }}</div>
          <div class="exemption-grid-header">{{ $t('operate') }}</div>
          <template v-for="(rule, index) in form.waiveList" :key="index">
            <div class="exemption-grid-cell">
              <el-select
                v-model="rule.waiveType"
                :disabled="exemptionFieldsDisabled"
                :placeholder="$t('please_select')"
                ><el-option
                  v-for="item in waiveTypeOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
              /></el-select>
            </div>
            <div class="exemption-grid-cell">
              <el-input-number
                v-model="rule.numberAmount"
                :disabled="exemptionFieldsDisabled"
                :min="0"
                :controls="false"
              />
            </div>
            <div class="exemption-grid-cell">
              <el-radio-group v-model="rule.directGift" :disabled="exemptionFieldsDisabled"
                ><el-radio :value="true">{{ $t('yes') }}</el-radio
                ><el-radio :value="false">{{ $t('no') }}</el-radio></el-radio-group
              >
            </div>
            <div class="exemption-grid-cell">
              <el-input-number
                v-model="rule.waiveAmount"
                :disabled="exemptionFieldsDisabled || rule.directGift"
                :min="0"
                :precision="2"
                :controls="false"
              />
            </div>
            <div class="exemption-grid-cell">
              <el-input-number
                v-model="rule.redemptionValidityPeriod"
                :disabled="exemptionFieldsDisabled || rule.directGift"
                :min="1"
                :precision="0"
                :controls="false"
              />
            </div>
            <div class="exemption-grid-cell">
              <el-input-number
                v-model="rule.freeQuote"
                :disabled="exemptionFieldsDisabled"
                :min="0"
                :controls="false"
              />
            </div>
            <div class="exemption-grid-cell">
              <el-button
                type="text"
                :disabled="exemptionFieldsDisabled"
                @click="removeExemptionRule(index)"
                >{{ $t('delete') }}</el-button
              >
            </div>
          </template>
        </div>
        <div class="exemption-add-box">
          <el-button :disabled="exemptionFieldsDisabled" @click="addExemptionRule">
            {{ $t('add') }} +
          </el-button>
        </div>
        <el-form-item
          :label="`${$t('monthly_basic_click_quote')}：`"
          prop="snapshotMonthlyBasicFreeQuote"
        >
          <el-col :span="8">
            <el-input-number
              v-model="form.snapshotMonthlyBasicFreeQuote"
              :disabled="exemptionFieldsDisabled"
              :min="0"
              :controls="false"
              :placeholder="$t('please_enter')"
            />
          </el-col>
        </el-form-item>
      </div>
    </el-form>
    <el-card v-if="mode === OperateMode.Audit" shadow="never" style="margin-top: 15px">
      <el-form ref="auditFormRef" :model="auditForm" :rules="auditFormRules" label-width="auto">
        <el-form-item
          prop="isPass"
          :label="$t('audit_status') + ':'"
          :rules="[{ required: true, message: $t('audit_status') }]"
        >
          <el-radio-group v-model="auditForm.isPass">
            <el-radio :label="true">{{ $t('audit_approve') }}</el-radio>
            <el-radio :label="false">{{ $t('audit_reject') }} </el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item prop="remark" :label="$t('audit_reason') + ':'">
          <el-input
            v-model="auditForm.remark"
            type="textarea"
            :autosize="{ minRows: 2, maxRows: 4 }"
            maxlength="64"
          />
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script lang="ts" setup>
import { ComputedRef, computed, reactive, ref, watch } from 'vue'
import { ElMessageBox, ElMessage } from 'element-plus'
import { QuestionFilled } from '@element-plus/icons-vue'
import CheckLang, { getLangIcon } from '@/components/check-lang/check-lang'
import { SelectOptions } from '@/types'
import { useI18n } from 'vue-i18n'
import dayjs from 'dayjs'
import { cloneDeep } from 'lodash'
import {
  IPackageExemptionRuleItem,
  IPackageI18nListItem,
  ISavePackageParams,
  savePackage,
} from '@/api-v2/quotation/query'
import { pickMissValuesFromEachOther } from '@/utils/i18n-form/merge'
import { OperateMode } from './enums'

import { reviewQuotationPackage } from '@/api-v2/quotation/mutations'
import { useLanguageList } from '@/components/hooks/use-language-list'

const { t } = useI18n()

type FormValues = Omit<ISavePackageParams, 'enable' | 'isPi'> & {
  enable: boolean
  isPi: string // 表单中使用字符串：'all' | 'true' | 'false'
}

export interface IInitFormValues {
  form: Omit<FormValues, 'i18nList' | 'isPi'> & {
    i18nMap?: Record<string, IPackageI18nListItem>
    isPi?: boolean | null // 从 API 获取的是 boolean | null
  }
}

const emit = defineEmits<{
  (e: 'close', success: boolean): void
}>()

interface IProps {
  initFormValues?: IInitFormValues
  terminalOptions: SelectOptions
  productListOptions: SelectOptions<number>
  currencyOptions: SelectOptions
  packageRegionOptions: SelectOptions
  piTypeOptions: SelectOptions
  accountTypeOptions: SelectOptions
  mode?: OperateMode
  feeCategoryOptions: SelectOptions
  chargeOptions: SelectOptions
  calculationPeriodOptions: SelectOptions
  calculationMethodOptions: SelectOptions
  waiveTypeOptions: SelectOptions
}

const props = withDefaults(defineProps<IProps>(), {
  terminalOptions: () => [],
  productListOptions: () => [],
  currencyOptions: () => [],
  packageRegionOptions: () => [],
  piTypeOptions: () => [],
  accountTypeOptions: () => [],
  feeCategoryOptions: () => [],
  chargeOptions: () => [],
  calculationPeriodOptions: () => [],
  calculationMethodOptions: () => [],
  waiveTypeOptions: () => [],
  mode: OperateMode.Add,
  initFormValues: undefined,
})

const canEditForm = computed(() => {
  return props.mode === OperateMode.Add || props.mode === OperateMode.Edit
})

const languageList = useLanguageList()

const lang = ref('zh-CN')
const langIndex = computed(() => {
  return languageList.value.findIndex((item: any) => item[0] === lang.value)
})

const _accountTypeOptions = computed<SelectOptions>(() => [
  {
    value: '',
    label: t('all'),
  },
  ...props.accountTypeOptions,
])

const isPiOptions: ComputedRef<SelectOptions> = computed<SelectOptions>(() => [
  {
    value: 'all',
    label: t('all'),
  },
  ...props.piTypeOptions,
])

const regionOptions = computed<SelectOptions>(() => [
  {
    value: '',
    label: t('all'),
  },
  ...props.packageRegionOptions,
])

const checkLangImage = computed(() => getLangIcon(lang.value))
const enableEnd = '2099-01-01'

function createExemptionRule(): IPackageExemptionRuleItem {
  return {
    exemptionType: '',
    numberAmount: undefined,
    directGift: true,
    waiveAmount: undefined,
    redemptionValidityPeriod: 5,
    freeQuote: undefined,
  }
}

function getEnabledExemptionDefaults() {
  return {
    calculationMethod: '',
    calculationPeriod: '',
    waiveList: [createExemptionRule()],
    snapshotMonthlyBasicFreeQuote: undefined,
  }
}

function getDisabledExemptionDefaults() {
  return {
    calculationMethod: '',
    calculationPeriod: '',
    waiveList: [createExemptionRule()],
    snapshotMonthlyBasicFreeQuote: undefined,
  }
}

function toBoolean(val: unknown, defaultVal = false): boolean {
  if (val === true || val === 'true' || val === 1 || val === '1') return true
  if (val === false || val === 'false' || val === 0 || val === '0') return false
  return defaultVal
}

function getInitFormValues(): FormValues {
  const i18nList: IPackageI18nListItem[] = languageList.value.map((item: string[]) => ({
    lang: item[0],
    name: '',
    remark: '',
  }))

  if (props.initFormValues) {
    const { i18nMap = {}, isPi: isPiFromApi, ...rest } = props.initFormValues.form

    i18nList.forEach((item) => {
      item.name = i18nMap[item.lang]?.name || ''
      item.remark = i18nMap[item.lang]?.remark || ''
    })

    // 将 isPi (boolean | null) 转换为字符串
    // 如果返回 null，选择"全部"
    let isPiValue = 'all'
    if (isPiFromApi === true) {
      isPiValue = 'true'
    } else if (isPiFromApi === false) {
      isPiValue = 'false'
    } else if (isPiFromApi === null || isPiFromApi === undefined) {
      isPiValue = 'all'
    }

    const exemptionDefaults = rest.enableWaive
      ? getEnabledExemptionDefaults()
      : getDisabledExemptionDefaults()

    return {
      ...exemptionDefaults,
      ...rest,
      defaultAuthorize: rest.defaultAuthorize ?? false,
      enableWaive: rest.enableWaive ?? false,
      waiveList: rest.waiveList?.length
        ? rest.waiveList
        : props.mode === OperateMode.Add
        ? exemptionDefaults.waiveList
        : [],
      feeId: rest.feeId || '',
      chargeMethod: rest.chargeMethod || '',
      isPi: isPiValue,
      i18nList,
      vipPackage: rest.vipPackage || '',
      isDefault: toBoolean(rest.isDefault, false),
      waiveOnRenew: toBoolean(rest.waiveOnRenew, false),
    }
  }

  const enableStart = dayjs().format('YYYY-MM-DD')

  return {
    accountType: '',
    calculationMethod: '',
    calculationPeriod: '',
    currency: 'HKD',
    defaultAuthorize: false,
    enable: false,
    enableWaive: false,
    enableStart: enableStart,
    enableEnd,
    waiveList: [createExemptionRule()],
    feeId: '',
    chargeMethod: '',
    i18nList,
    isPi: 'all',
    snapshotMonthlyBasicFreeQuote: undefined,
    packageId: '',
    price: 0,
    productId: undefined,
    region: '',
    terminal: [],
    rtq: '',
    vipPackage: '',
    isDefault: false,
    waiveOnRenew: false,
  }
}

const form = reactive(getInitFormValues())
const formRef = ref()
const auditFormRef = ref()
const auditForm = reactive({
  isPass: true,
  packageId: '',
  remark: '',
})

function resetForm() {
  const values = getInitFormValues()
  Object.assign(form, values)
  lang.value = 'zh-CN'
  auditForm.isPass = true
  auditForm.packageId = ''
  auditForm.remark = ''
  isSubmitting.value = false
}

watch([() => props.mode, () => props.initFormValues], resetForm)
const auditFormRules = {
  isPass: {
    required: true,
    trigger: 'change',
    message: `${t('please_select')}${t('trading_account')}`,
  },
}

const isSubmitting = ref(false)
const exemptionFieldsDisabled = computed(() => !canEditForm.value || !form.enableWaive)

function addExemptionRule() {
  form.waiveList?.push(createExemptionRule())
}

function removeExemptionRule(index: number) {
  form.waiveList?.splice(index, 1)
}

function checkDisabledDate(date: Date) {
  const todayStart = dayjs().startOf('day')
  return dayjs(date).isBefore(todayStart)
}

function getSubmitParams(): ISavePackageParams {
  const params = cloneDeep(form)

  const {
    isPi: isPiStr,
    accountType,
    calculationMethod,
    calculationPeriod,
    currency,
    defaultAuthorize,
    enable,
    enableEnd,
    enableWaive,
    enableStart,
    waiveList,
    feeId,
    chargeMethod,
    i18nList,
    snapshotMonthlyBasicFreeQuote,
    packageId,
    price,
    productId,
    region,
    terminal,
    rtq,
    vipPackage,
    isDefault,
    waiveOnRenew,
  } = params

  // 将字符串转换为 boolean | undefined
  let isPi: boolean | undefined = undefined
  if (isPiStr === 'true') {
    isPi = true
  } else if (isPiStr === 'false') {
    isPi = false
  }

  return {
    enable: enable ? 'enable' : 'disable',
    isPi,
    accountType,
    calculationMethod,
    calculationPeriod,
    currency,
    defaultAuthorize,
    enableEnd,
    enableWaive,
    enableStart,
    waiveList: enableWaive ? waiveList : [],
    feeId,
    chargeMethod,
    i18nList,
    snapshotMonthlyBasicFreeQuote: enableWaive ? snapshotMonthlyBasicFreeQuote : undefined,
    packageId: packageId || undefined,
    price,
    productId: productId as number,
    region,
    terminal,
    rtq,
    vipPackage,
    isDefault,
    waiveOnRenew,
  }
}

function checkMissI18n() {
  const i18nValues = form.i18nList
  return i18nValues.some((item) => {
    if (!item.name || !item.remark) {
      return true
    }

    return false
  })
}

function onSubmit() {
  if (canEditForm.value) {
    formRef.value.validate(async (valid: boolean) => {
      if (valid) {
        const missI18n = checkMissI18n()

        let autoFilledI18nList = form.i18nList

        if (missI18n) {
          try {
            await ElMessageBox.confirm(t('internationalization_tips'), {
              confirmButtonText: t('determine'),
              cancelButtonText: t('cancel'),
              type: 'warning',
            })
          } catch (error) {
            console.error(error)
            return
          }
          autoFilledI18nList = pickMissValuesFromEachOther(
            form.i18nList
          ) as typeof autoFilledI18nList

          form.i18nList = autoFilledI18nList
        }

        const params = getSubmitParams()

        isSubmitting.value = true

        savePackage(params)
          .then(() => {
            const tips =
              props.mode === OperateMode.Add ? t('add_quote_package_success') : t('modify_success')

            ElMessage.success(tips)
            close(true)
          })
          .catch((err: unknown) => {
            console.error(err)
          })
          .finally(() => {
            isSubmitting.value = false
          })
      }
    })

    return
  }

  if (props.mode === OperateMode.Audit) {
    auditFormRef.value.validate((validate: boolean) => {
      if (!validate) {
        return
      }

      if (auditForm.isPass) {
        const selectedChargeOpt = props.chargeOptions.find(
          (opt) => String(opt.value) === String(form.chargeMethod)
        )
        const isCharge = form.chargeMethod === 'Advance'
        if (isCharge && !form.feeId) {
          ElMessage.warning(t('please_select_fee_for_charge'))
          return
        }
      }

      ElMessageBox.confirm(t('is_confirm_audit'), {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
      })
        .then(() => {
          // const params = getSubmitParams()
          const params: Parameters<typeof reviewQuotationPackage>[0] = {
            packageId: form.packageId as string,
            isPass: auditForm.isPass,
            remark: auditForm.remark,
          }

          isSubmitting.value = true

          reviewQuotationPackage(params)
            .then(() => {
              close(true)
              ElMessage.success(t('audit_success'))
            })
            .catch((error: unknown) => {
              console.error('确认审核失败', error)
            })
            .finally(() => {
              isSubmitting.value = false
            })
        })
        .catch(() => {
          // prevent promise error popup in development mode
          return
        })
    })
  }
}

function close(success: boolean) {
  emit('close', success)
}

defineExpose({ submit: onSubmit, isSubmitting })
</script>

<style lang="scss" scoped>
.form {
  :deep(.el-select),
  :deep(.el-input-number),
  :deep(.el-textarea),
  :deep(.el-input) {
    width: 100% !important;
  }
}

.package-date-picker-container {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.package-date-picker {
  width: 130px !important;
}

.package-date-picker-separator {
  margin: 0 6px;
}

.package-date-picker-end {
  width: 94px !important;
}

.lang-icon-label {
  display: flex;
  align-items: center;
}
</style>

<style lang="scss" scoped>
.edit-streaming-quote-box {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  column-gap: 20px;
  align-items: start;
  padding: 10px 20px;

  :deep(.el-form-item--default) {
    margin: 12px 0;
    font-weight: 600;
  }

  :deep(.el-checkbox-group) {
    display: flex;
  }

  img {
    width: 20px;
    height: 20px;
  }
}

.avatar-uploader {
  :deep(.el-upload-dragger),
  .avatar {
    width: 150px;
    height: 150px;
  }
  .el-icon.avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    text-align: center;
    position: relative;
    bottom: 15px;
    right: 15px;
  }
}

.region-group {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.remark-input {
  :deep(.el-input__count) {
    bottom: -16px;
  }
}

.exemption-table-box {
  padding: 0 20px 10px;
  overflow-x: auto;
}

.exemption-grid {
  display: grid;
  grid-template-columns:
    minmax(180px, 1.4fr) minmax(160px, 1.2fr) minmax(170px, 1.3fr) repeat(3, minmax(140px, 1fr))
    100px;
  min-width: 1060px;
  border: 1px solid #dcdfe6;
}

.exemption-grid-header,
.exemption-grid-cell {
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 0;
  min-height: 48px;
  padding: 8px;
  border-bottom: 1px solid #dcdfe6;
}

.exemption-grid-header {
  font-weight: 600;
  background-color: #d20a10;
  color: white;
}

.exemption-grid-header:nth-child(7n),
.exemption-grid-cell:nth-child(7n) {
  border-right: 0;
}

.exemption-grid-cell :deep(.el-select),
.exemption-grid-cell :deep(.el-input-number) {
  width: 100%;
}

.exemption-add-box {
  display: flex;
  justify-content: center;
  margin: 14px 0;
}

.direct-gift-header {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
}

.question-icon {
  cursor: pointer;
  color: #909399;
  font-size: 14px;
  margin-left: 2px;
  vertical-align: middle;

  &:hover {
    color: #fff;
  }
}
</style>
