﻿<template>
  <el-dialog
    v-model="dialogTableVisible"
    :close-on-click-modal="false"
    :title="title"
    width="1200px"
    center
    class="dialog"
    @opened="handleOpened"
    @closed="handleClosed"
  >
    <div v-if="isLoading || loadError || !contentMounted" class="dialog-state">
      <el-skeleton v-if="isLoading || !contentMounted" :rows="8" animated />
      <el-empty v-else :description="loadError">
        <el-button type="primary" @click="retryLoad">{{ t('retry') }}</el-button>
      </el-empty>
    </div>
    <EditOrderDialogContent
      v-if="contentMounted"
      v-show="!isLoading && !loadError"
      ref="contentRef"
      :="$props"
      :init-form-values="initFormValues"
      :mode="mode"
      @close="handleClose"
    />
    <template
      v-if="contentMounted && !isLoading && !loadError && mode !== OperateMode.Detail"
      #footer
    >
      <CustomDialogFooter>
        <el-button type="primary" :loading="contentRef?.isSubmitting" @click="contentRef?.submit()">
          {{ $t('determine') }}
        </el-button>
        <el-button @click="handleClose(false)">{{ $t('cancel') }}</el-button>
      </CustomDialogFooter>
    </template>
  </el-dialog>
</template>
<script lang="ts" setup>
import { computed, ref } from 'vue'
import EditOrderDialogContent, { IInitFormValues } from './edit-order-dialog-content.vue'
import CustomDialogFooter from '@/components/custom-dialog-footer.vue'
import { SelectOptions } from '@/types'
import { OperateMode } from './enums'
import { useI18n } from 'vue-i18n'
const { t } = useI18n()
type IProps = {
  terminalOptions: SelectOptions
  productListOptions: SelectOptions<number>
  currencyOptions: SelectOptions
  packageRegionOptions: SelectOptions
  piTypeOptions: SelectOptions
  accountTypeOptions: SelectOptions
  feeCategoryOptions: SelectOptions
  chargeOptions: SelectOptions
  calculationPeriodOptions: SelectOptions
  calculationMethodOptions: SelectOptions
  fullCustomerOptions: SelectOptions
  waiveTypeOptions: SelectOptions
}
withDefaults(defineProps<IProps>(), {
  terminalOptions: () => [],
  productListOptions: () => [],
})
const initFormValues = ref<IInitFormValues>()
type LoadOptions = {
  load?: () => Promise<IInitFormValues>
}

const emit = defineEmits<{
  (e: 'callback'): void
}>()

const dialogTableVisible = ref(false)
const mode = ref(OperateMode.Add)
const contentRef = ref<InstanceType<typeof EditOrderDialogContent>>()
const isLoading = ref(false)
const loadError = ref('')
const contentMounted = ref(false)
const isOpened = ref(false)
const requestToken = ref(0)
let currentLoader: (() => Promise<IInitFormValues>) | undefined

const title = computed(() => {
  if (mode.value === OperateMode.Add) {
    return t('add_stream_market_package')
  }

  if (mode.value === OperateMode.Edit) {
    return t('edit_stream_market_package')
  }

  if (mode.value === OperateMode.Audit) {
    return t('audit_stream_market_package')
  }

  if (mode.value === OperateMode.Detail) {
    return t('view_stream_market_package')
  }

  return t('details')
})

function open(
  _mode: OperateMode = OperateMode.Add,
  options?: LoadOptions,
  _initFormValues?: IInitFormValues
) {
  requestToken.value += 1
  mode.value = _mode
  initFormValues.value = _initFormValues
  currentLoader = options?.load
  loadError.value = ''
  isLoading.value = Boolean(currentLoader)
  dialogTableVisible.value = true

  if (currentLoader) {
    loadData(currentLoader, requestToken.value)
  }
}

async function loadData(loader: () => Promise<IInitFormValues>, token: number) {
  try {
    const values = await loader()
    if (token !== requestToken.value) return

    initFormValues.value = values
    loadError.value = ''
    isLoading.value = false
    mountContentIfReady()
  } catch {
    if (token !== requestToken.value) return

    isLoading.value = false
    loadError.value = t('request_failed')
  }
}

function mountContentIfReady() {
  if (isOpened.value && !isLoading.value && !loadError.value) {
    contentMounted.value = true
  }
}

function handleOpened() {
  isOpened.value = true
  mountContentIfReady()
}

function handleClosed() {
  isOpened.value = false
  requestToken.value += 1
}

function retryLoad() {
  if (!currentLoader) return

  requestToken.value += 1
  loadError.value = ''
  isLoading.value = true
  loadData(currentLoader, requestToken.value)
}

function handleClose(success: boolean) {
  dialogTableVisible.value = false

  if (success) {
    emit('callback')
  }
}

defineExpose({
  open,
})
</script>
<style scoped>
.dialog-state {
  min-height: 360px;
  padding: 24px;
}
</style>
