<template>
  <div class="login-container">
    <div class="logo">
      <img :src="logoUrl" />
    </div>
    <div class="welcome-login">
      <section class="welcome">
        <h4 class="title1">{{ $t('hello') }}</h4>
        <h2 class="title2">{{ $t('market_mall') }}<br />{{ $t('management_platform') }}</h2>
        <img src="@/assets/images/welcom_new.png" class="welcome-login-img" />
      </section>
      <section class="login">
        <div class="login-wrap">
          <h2 class="title">{{ $t('login') }}</h2>
          <el-form ref="loginFormRef" :model="loginForm" :rules="rules" class="login-form">
            <el-form-item prop="username">
              <el-input
                v-model="loginForm.username"
                :placeholder="$t('please_enter_account')"
                class="login-input"
                @keydown.enter="toLogin"
              >
                <template #prepend>
                  <SvgIcon :size="22" :path="require('@/images/login-account.svg')" />
                </template>
              </el-input>
            </el-form-item>
            <el-form-item prop="password">
              <el-input
                v-model="loginForm.password"
                type="password"
                :placeholder="$t('please_enter_password')"
                class="login-input"
                @keydown.enter="toLogin"
              >
                <template #prepend>
                  <SvgIcon :size="22" :path="require('@/images/login-pass.svg')" />
                </template>
              </el-input>
            </el-form-item>
            <el-form-item prop="code">
              <el-input
                v-model="loginForm.code"
                maxlength="6"
                :placeholder="$t('verification_code')"
                class="identifying-input login-input"
                @keydown.enter="toLogin"
              >
                <template #prepend>
                  <SvgIcon :size="22" :path="require('@/images/login-code.svg')" />
                </template>
              </el-input>
              <div class="img-code">
                <img :src="codeUrl" :alt="$t('verification_code')" />
                <el-icon :size="20" class="icon-fresh" @click="getIdentifyingCode">
                  <i-refresh />
                </el-icon>
              </div>
            </el-form-item>
            <el-button type="primary" class="login-btn" @click="toLogin">{{
              $t('login')
            }}</el-button>
          </el-form>
          <div class="language-btns-box">
            <language-btns @btn-click="selecteLang" />
          </div>
        </div>
      </section>
    </div>
  </div>
</template>
<script lang="ts">
import { defineComponent, reactive, ref, onBeforeMount, computed, watch, onMounted } from 'vue'
import { useAppStore } from '@/store'
import { useI18n } from 'vue-i18n'
import {
  getIdentifyingCode as getIdentifyingCodeApi,
  getMultiModuleList
} from '@/api-v2/authority/authority'
import LanguageBtns from '@/components/language-btns/language-btns.vue'
import { ElMessage } from 'element-plus'

import { getDefaultModulePath, getModuleByPath, setMicroPath } from '@/utils/common'
import { useRouter } from 'vue-router'
import { passwordEncrypt } from '@/utils/common'
import { createInternalPath } from '@/micro-app'
import locationUtil from '@/utils/location'

export default defineComponent({
  components: { LanguageBtns },
  setup() {
    /* 验证码-start */
    const codeUrl = ref()
    const router = useRouter()
    const { t, locale } = useI18n({ useScope: 'global' })
    const logoUrl = locationUtil.getPublicAssetUrl('/public-images/logo.svg')

    const getIdentifyingCode = () => {
      getIdentifyingCodeApi({ sid: sessionStorage.getItem('codeSid') || '' }).then((res) => {
        codeUrl.value = `data:image/jpeg;base64,${res.result.image}`
        sessionStorage.setItem('codeSid', res.result.sid)
      })
    }

    /* 验证码-end */

    /* 登录-start */
    const appStore = useAppStore()
    const loginForm = reactive({
      username: '',
      password: '',
      code: ''
    })

    const rules = computed(() => {
      return {
        username: [{ required: true, message: t('please_enter_account'), trigger: 'blur' }],
        password: [{ required: true, message: t('please_enter_password'), trigger: 'blur' }],
        code: [{ required: true, message: t('please_enter_verification_code'), trigger: 'blur' }]
      }
    })

    const title = ref(window.APP_CONFIG.login_title_cn || t('management_system'))
    // const loginFormRef = ref<InstanceType<typeof ElForm>>()
    const loginFormRef = ref()
    const toLogin = () => {
      loginFormRef.value?.validate((valid: boolean) => {
        if (!valid) {
          return false
        }

        const data = {
          ...loginForm,
          sid: sessionStorage.getItem('codeSid'),
          imgCode: loginForm.code,
          password: passwordEncrypt(loginForm.password)
        }

        appStore
          .login(data)
          .then(() => {
            getMultiModuleList().then((res) => {
              console.log('============>res.result', res.result)
              const multiModuleList = res.result
                .sort((a, b) => {
                  if (a.isExternal && !b.isExternal) {
                    return 1
                  }
                  if (!a.isExternal && b.isExternal) {
                    return -1
                  }
                  return 0
                })
                .map((md: any) => ({
                  ...md,
                  menu: createInternalPath(md.menu, md.code)
                }))

              // TODO
              const currentModulePath = appStore.currentModulePath

              console.log(multiModuleList, '==========>multiModuleList')

              if (!multiModuleList.length) {
                ElMessage.error(t('no_accessible_module'))
                appStore.logout()
                getIdentifyingCode()
                return
              }

              // const defaultApp = setMicroPath(multiModuleList[0].code)

              const path = getDefaultModulePath(multiModuleList[0])

              appStore.setMultiModuleList(multiModuleList)

              const cachedModule = getModuleByPath(currentModulePath, multiModuleList)
              const targetModule = cachedModule || multiModuleList[0]
              const targetPath = cachedModule
                ? currentModulePath
                : getDefaultModulePath(targetModule)

              appStore.setCurrentModule(targetModule)
              const fullPath = locationUtil.getFullPath(targetPath)
              appStore.setCurrentModulePath(fullPath)

              console.log(path, '==========>path')
              router.push(locationUtil.getRouterPath(targetPath))
            })
          })
          .catch(() => {
            // 登录失败重刷验证码
            getIdentifyingCode()
          })
      })
    }
    /* 登录-end */

    /* 语言-start */
    const selecteLang = (lan: { label: string; value: string }) => {
      locale.value = lan
      appStore.setLanguage(lan)
    }
    /* 语言-end */

    onBeforeMount(() => {
      getIdentifyingCode()
    })

    watch(locale, () => {
      const formBackup = Object.assign({}, loginForm)
      loginFormRef.value.resetFields()

      Object.assign(loginForm, formBackup)
      console.log(
        window.APP_CONFIG.login_title_cn,
        title.value,
        'window.APP_CONFIG.login_title_cn --> '
      )
      if (window.APP_CONFIG.login_title_cn) {
        if (locale.value === 'en') {
          title.value = window.APP_CONFIG.login_title_en
          return
        }
        title.value =
          locale.value === 'hk'
            ? window.APP_CONFIG.login_title_hk
            : window.APP_CONFIG.login_title_cn
        return
      }
      title.value = t('management_system')
    })

    // 获取标题

    // onMounted(() => {

    // })
    return {
      loginForm,
      rules,
      loginFormRef,
      toLogin,
      getIdentifyingCode,
      codeUrl,
      selecteLang,
      locale,
      title,
      logoUrl
    }
  }
})
</script>
<style lang="scss" scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;

  &::before,
  &::after {
    display: inline-block;
    content: '';
    height: 100%;
  }

  &::before {
    width: 30%;
    background-color: #fff6f7;
  }

  &::after {
    width: 70%;
    background-color: #ffffff;
  }

  .logo {
    position: absolute;
    top: 50px;
    left: 40px;
    z-index: 1000;

    img {
      width: 240px;
    }
  }
}

.welcome-login {
  position: absolute;
  z-index: 1;
  display: flex;
  width: 960px;
  height: 580px;
  background-color: #fdfdfd;
  border-radius: 30px;
  box-shadow: 0px 0px 80px 0px rgba(44, 49, 52, 0.2);
  .welcome,
  .login {
    height: 100%;
    box-sizing: border-box;
  }
}

.welcome {
  width: 400px;
  box-shadow: 0px 0px 80px 0px rgba(162, 190, 210, 0.3);
  background-color: #ffffff;
  border-radius: 30px 0 0 30px;
  padding: 101px 0 86px 50px;

  .title1,
  .title2 {
    margin: 0;
    color: #333;
    font-weight: 500;
  }
  .title1 {
    font-size: 24px;
    line-height: 33px;
  }
  .title2 {
    margin: 10px 0 55px;
    font-size: 38px;
    line-height: 53px;
    word-break: break-word;
  }

  .welcome-login-img {
    width: 300px;
    height: 242px;
  }
}

.login {
  width: 560px;
  padding: 40px 100px 83px;
  border-radius: 0 30px 30px 0;
  .login-wrap {
    display: flex;
    flex-direction: column;
    align-items: center;

    .title {
      margin: 0;
      color: #212121;
      font-size: 30px;
      font-weight: 500;
    }

    .language-btns-box {
      align-self: flex-end;
      text-align: center;
    }
  }
}

.login-form {
  margin: 60px 0 22px;
  width: 100%;

  :deep(.el-form-item) {
    margin-bottom: 40px;
    border-bottom: 1px solid #ebebeb;
  }

  :deep(.el-form-item .el-input) {
    width: 100%;
  }

  :deep(.el-form-item__content) {
    margin-bottom: 18px;
  }

  :deep(.el-input-group__prepend) {
    padding: 0;
    width: 40px !important;
    border: none;
    background: inherit;
    box-shadow: none;
  }

  :deep(.el-input__wrapper) {
    box-shadow: none !important;
  }

  :deep(.is-focus) {
    box-shadow: none;
  }

  :deep(.el-input__inner) {
    border: none;
    font-size: 18px;
  }

  :deep(.el-form-item__error) {
    font-size: 14px;
  }

  .img-code {
    display: flex;
    align-items: center;
    position: absolute;
    right: 0;
    .icon-fresh {
      margin-left: 11px;
      margin-right: 11px;
      cursor: pointer;
    }
  }
  .login-btn {
    width: 100%;
    height: 50px;
    border-radius: 7px;
    margin-bottom: 24px;
    font-size: 18px;
    background-color: #d20a10;
    border-color: #d20a10;
  }
}

@media screen and (max-width: 1366px) {
  .welcome-login {
    width: 800px;
    height: 520px;

    .welcome {
      width: 300px;

      .title2 {
        margin: 10px 0;
      }
    }

    .welcome-login-img {
      width: 200px;
    }
  }

  .login {
    width: 500px;
    padding: 40px 100px 83px;
  }

  .login-form {
    margin: 40px 0 20px !important;
    :deep(.el-form-item) {
      margin-bottom: 15px !important;
    }
  }

  .logo {
    img {
      width: 230px !important;
    }
  }
}

@media screen and (max-width: 1024px) {
  .welcome-login {
    width: 700px;
    height: 480px;

    .welcome {
      width: 300px;
    }

    .welcome-login-img {
      width: 150px;
    }
  }

  .login {
    width: 400px;
    padding: 40px 50px 83px;
  }

  .login-form {
    margin: 20px 0 20px !important;

    :deep(.el-form-item) {
      margin-bottom: 15px !important;
    }
  }

  .logo {
    top: 20px;
    left: 20px;

    img {
      width: 230px !important;
    }
  }
}

@media screen and (max-width: 800px) {
  .welcome-login {
    width: 600px;
    height: 440px;

    .welcome-login-img {
      height: 150px;
    }
  }

  .login {
    width: 360px;
    padding: 40px 20px 83px;
  }

  .login-form {
    margin: 20px 0;
    :deep(.el-form-item) {
      margin-bottom: 15px !important;
    }
  }

  .logo {
    top: 15px;
    left: 15px;

    img {
      width: 250px !important;
    }
  }
}
</style>
