<template>
  <div class="layout-container" :class="{ 'layout-container--embedded': isByQiankun }">
    <v-header v-if="!isByQiankun" />
    <div class="sidebar-main">
      <v-sidebar :multi-module-list="multiModuleList" v-if="!isByQiankun" />

      <div
        v-loading="moduleLoading"
        class="main"
        :style="{ padding: isByQiankun ? 0 : contentPadding + 'px' }"
      >
        <router-view />
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { computed, defineComponent } from 'vue'
import { useRoute } from 'vue-router'
import { useAppStore } from '@/store'
import { UI_CONFIG } from '@/constants/ui'
import VHeader from '@/components/header/header.vue'
import VSidebar from '@/components/sidebar/sidebar.vue'

export default defineComponent({
  name: 'Layout',
  components: {
    VHeader,
    VSidebar
  },
  props: {
    mainPadding: { type: Number, default: UI_CONFIG.mainPadding }
  },
  setup(props) {
    const appStore = useAppStore()
    const route = useRoute()
    const multiModuleList = computed(() => appStore.multiModuleList)
    const moduleLoading = computed(() => appStore.moduleLoading)
    const isByQiankun = computed(() => appStore.isByQiankun)
    // 页面可通过 meta.mainPadding 覆盖统一内容边距
    const contentPadding = computed(() => Number(route.meta.mainPadding ?? props.mainPadding))

    return {
      multiModuleList,
      moduleLoading,
      isByQiankun,
      contentPadding
    }
  }
})
</script>

<style lang="scss" scoped>
.layout-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;

  .sidebar-main {
    flex: 1;
    min-height: 0;
    display: flex;
    overflow: hidden;

    .main {
      flex: 1;
      min-width: 0;
      min-height: 0;
      overflow: auto;
      background: var(--el-bg-color);
    }
  }
}
</style>
