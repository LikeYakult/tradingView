<template>
  <div>
    <baseFilter :loading="isLoading" :config="filterConfig" @onSearch="searchHandle" @onReset="resetHandle"></baseFilter>
    <div class="operate-buttons">
      <el-button
        type="primary"
        plain
        @click="toBack"
        >{{ $t('back') }}</el-button
      >
      <el-button plain class="export-button"
        v-permission="'sys:rateLog:export'"
        :loading="exportLoading"
        @click="toExport"
        >{{ $t('export') }}</el-button
      >
    </div>
    <baseTable
      ref="tablePaginationRef"
      :config="tableConfig"
      :pagination="paginationConfig"
      :isTableLoading="isLoading"
    >
      <template v-slot:status>
        <el-table-column :label="$t('operate_status')" align="center">
          <template #default="scope">
            <div :class="{'success': scope.row.status === 1, 'fail': scope.row.status === 0}" >
              {{ statusText(scope.row.status) }}
            </div>
          </template>
        </el-table-column>
      </template>
    </baseTable>
  </div>
</template>
<script lang="ts">
import { defineComponent, reactive, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage } from 'element-plus'
import baseFilter from '@/components/base-filter/base-filter'
import baseTable from '@/components/base-table/base-table'
import { timeDiff } from '@/utils/common'
import { getUserLoginLog, operationLogExport, loginLogExport } from '@/api/subPro/subPro'
import { rateLogList, logExport } from "@/api/exchangeRate/exchangeRate"

export default defineComponent({
  name: 'account-operation-log',
  props: {
    showlog: {
      type: Boolean,
    }
  },
  components: {
    baseFilter,
    baseTable,
  },
  setup(props: any, context) {
    console.log('props', props.showlog);

    // const emit = defineEmits(['closeChangeLog'])
    const { t } = useI18n()
    const tablePaginationRef = ref()
    const pageSize = ref(20)
    const currentPage = ref(1)
    const searchData = ref()
    const isLoading = ref<boolean>(false)
    const ordering = ref({
      asc: true,
      column: '',
    })

    /* 表格-start */
    const tableConfig = reactive({
      tableProps: {
        data: <{ date: string; name: string; address: string }[]>[],
      },
      tableEvent: {
        onSortChange: (column: Record<string, any>) => {
          const { order, prop } = column
          ordering.value.column = ''
          currentPage.value = 1
          paginationConfig.value.paginationProps.currentPage = 1

          if (order) {
            ordering.value = {
              asc: order === 'ascending',
              column: prop,
            }
          }
          return toGetUserLoginLog()
        },
      },
      customColumns: [
        { label: t('operatorAccount'), prop: 'operatorAccount' },
        { label: t('fullName'), prop: 'operator' },
        { label: t('updateCurrency'), prop: 'updateCurrency' },
        { label: t('updateBefore'), prop: 'beforeUpdate' },
        { label: t('updateAfter'), prop: 'afterUpdate' },
        { slot: 'status' },
        { label: t('updateTime'), prop: 'updateTime' },
      ],
    })
    const statusText = (num: number) => {
      const text = [t('failure'), t('success')]
      return text[num]
    }
    /* 表格-end */

    /* 分页-start */
    const paginationConfig = ref({
      paginationProps: { total: 0, 'page-size': 20, currentPage: 1 },
      paginationEvent: {
        onSizeChange: handleSizeChange,
        onCurrentChange: handleCurrentChange,
      },
    })
    function handleSizeChange(currentSize: number) {
      paginationConfig.value.paginationProps['page-size'] = currentSize
      tablePaginationRef.value?.toFirstPage()
      currentPage.value = 1
      pageSize.value = currentSize
      toGetUserLoginLog()
    }
    function handleCurrentChange(theCurrentPage: number) {
      currentPage.value = theCurrentPage
      paginationConfig.value.paginationProps.currentPage = theCurrentPage
      toGetUserLoginLog()
    }
    /* 分页-end */

    function toGetUserLoginLog() {
      isLoading.value = true
      const params = {
        ...searchData.value,
        pageSize: pageSize.value,
        pageNum: currentPage.value,
      }

      if (ordering.value.column) {
        Object.assign(params, {
          orders: [ordering.value],
        })
      }

      rateLogList(params)
        .then((res: { [key: string]: any }) => {
          tableConfig.tableProps.data = res.result?.records
          paginationConfig.value.paginationProps.total = res.result?.total || 0
        })
        .finally(() => {
          isLoading.value = false
        })
    }
    toGetUserLoginLog()

    const toBack = () => {
      context.emit('close-changelog', true)
    }

    /* 过滤表单-start */
    const filterConfig = ref({
      formProps: {
        model: {
          loginTime: '',
          status: '',
          keyword: '',
        },
      },
      formItems: [
        {
          prop: 'loginTime',
          label: t('updateTime'),
          innerEl: {
            elType: 'datePicke',
            props: { type: 'datetimerange', 'value-format': 'YYYY-MM-DD HH:mm:ss' },
          },
        },
        {
          prop: 'status',
          label: t('operate_status'),
          innerEl: {
            elType: 'select',
            options: [
              { value: '', label: t('all') },
              { label: t('success'), value: 1 },
              { label: t('failure'), value: 0 },
            ],
          },
        },
        {
          prop: 'keyword',
          label: '',
          innerEl: {
            elType: 'input',
            props: { placeholder: t('please_enter_keyword') },
          },
        },
      ],
    })
    const searchHandle = (data: { [name: string]: any }) => {
      currentPage.value = 1
      tablePaginationRef.value?.toFirstPage()
      // 携带自定义插槽数据并请求查询
      const { loginTime, ...params } = data
      const [beginDate, endDate] = loginTime
      searchData.value = { beginDate, endDate, ...params }
      toGetUserLoginLog()
    }
    const resetHandle = (data: { [name: string]: any }) => {
      currentPage.value = 1
      tablePaginationRef.value?.toFirstPage()
      // 重置自定义插槽数据并请求查询
      const { loginTime, ...params } = data
      const [beginDate, endDate] = loginTime
      searchData.value = { beginDate, endDate, ...params }
      toGetUserLoginLog()
    }
    /* 过滤表单-end */

    // 导出
    const exportLoading = ref(false)
    const toExport = () => {
      const params = {
        ...searchData.value,
        pageSize: pageSize.value,
        pageNum: currentPage.value,
      }

      if (ordering.value.column) {
        Object.assign(params, {
          orders: [ordering.value],
        })
      }
      console.log('params', params);


      if (!params.beginDate && !params.endDate) {
        ElMessage.warning(t('export_message'))
        return
      }

      if (timeDiff(params.beginDate, params.endDate)) {
        ElMessage.warning(t('export_month_message'))
        return
      }

      exportLoading.value = true
      logExport(params, `${t('exchange_rate_logs')}.xlsx`).then(() => {
        exportLoading.value = false
      })
    }
    return {
      tablePaginationRef,
      tableConfig,
      paginationConfig,
      statusText,
      filterConfig,
      searchHandle,
      resetHandle,
      isLoading,
      toExport,
      exportLoading,
      // props,
      // emit,
      toBack
    }
  },
})
</script>

<style lang="scss" scoped>
.success {
  color: #67c23a;
}

.fail {
  color: #f56c6c;
}

</style>
