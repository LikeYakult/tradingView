<template>
  <div class="page-container">
    <el-form v-if="showForm" :model="form" label-width="120px">
      <el-form-item :label="$t('exchange_rate_config')">
        <el-button v-permission="'sys:rateLog:list'" type="primary" link @click="showChangeLog">{{
          $t('change_log')
        }}</el-button>
      </el-form-item>
      <el-form-item :label="$t('please_select_base')">
        <el-radio-group v-model="form.base" class="ml-4" @change="redioChange">
          <el-radio label="HKD" size="large">{{ $t('hkd') }}</el-radio>
          <el-radio label="USD" size="large">{{ $t('dollar') }}</el-radio>
          <el-radio label="CNY" size="large">{{ $t('rmb') }}</el-radio>
        </el-radio-group>
      </el-form-item>

      <el-form-item :label="$t('hkd')">
        <el-input-number
          v-model="form.HKD"
          :disabled="'HKD' === currencyType"
          :precision="4"
          :step="0.1"
        />
        <span class="text">1{{ t('hkd') }}={{ form.HKD }}{{ currency }}</span>
      </el-form-item>
      <el-form-item :label="$t('dollar')">
        <el-input-number
          v-model="form.USD"
          :disabled="'USD' === currencyType"
          :precision="4"
          :step="0.1"
        />
        <span class="text">1{{ t('dollar') }}={{ form.USD }}{{ currency }}</span>
      </el-form-item>
      <el-form-item :label="$t('rmb')">
        <el-input-number
          v-model="form.CNY"
          :disabled="'CNY' === currencyType"
          :precision="4"
          :step="0.1"
        />
        <span class="text">1{{ t('rmb') }}={{ form.CNY }}{{ currency }}</span>
      </el-form-item>
      <el-form-item>
        <el-button v-permission="'sys:rateSetting:save'" type="primary" @click="onSubmit">{{
          $t('save')
        }}</el-button>
      </el-form-item>
    </el-form>
    <ChangeLog v-else :showlog="showForm" @close-changelog="closeChangeLog" />
  </div>
</template>

<script lang="ts" setup>
import { ref, reactive, onMounted, onBeforeUnmount } from 'vue'
import { onBeforeRouteLeave } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { ElMessageBox, ElMessage } from 'element-plus'
import { getRateList, saveRate } from '@/api/exchangeRate/exchangeRate'
import ChangeLog from './exchange-rate-changelog.vue'

const { t } = useI18n()
const isSave = ref(false)
const showForm = ref(true)
const currency = ref(t('hkd'))
const currencyType = ref('hkd')

const getBaseConfig = () => {
  getRateList().then((res) => {
    console.log('res', res)
    const { code, result } = res
    if (code === 0) {
      result.forEach((item: any) => {
        if (item.baseCcy === 'Y') {
          currency.value = currencyMap[item.ccy]
          currencyType.value = item.ccy
          form[item.ccy] = 1
          form.base = item.ccy
        } else {
          form[item.ccy] = +item.rate
        }
        // if (item?.ccy === 'HKD') {
        //   currency.value = currencyMap[item.ccy]
        //   currencyType.value = item.ccy
        //   form[item.ccy] = 1
        //   form.base = 'HKD'
        // } else {
        //   form[item.ccy] = +item.rate
        // }
      })
      console.log('form', form)
    }
  })
}

const currencyMap: { [key: string]: string } = {
  HKD: t('hkd'),
  USD: t('dollar'),
  CNY: t('rmb'),
}

const form = reactive<{ [key: string]: string | number }>({
  base: 'hkd',
  HKD: 1,
  USD: 0,
  CNY: 0,
})

// 选择基准
const redioChange = (val: string) => {
  currency.value = currencyMap[val]
  currencyType.value = val
  Object.keys(currencyMap).forEach((key) => {
    form[key] = key !== val ? form[key] : 1
  })
}

const showChangeLog = () => {
  console.log('showChangeLog')
  showForm.value = false
  isSave.value = true
}

// 关闭表格
const closeChangeLog = (val: boolean) => {
  showForm.value = val
  isSave.value = false
}

// 如果接口保存成功,不用拦截
const beforeUnload = async () => {
  if (isSave.value) {
    return true
  }
  const res = await ElMessageBox.confirm(t('leave_tip'), t('tip'), {
    confirmButtonText: t('determine'),
    cancelButtonText: t('cancel'),
    type: 'warning',
  })
    .then(() => {
      return true
    })
    .catch(() => {
      return false
    })
  return res
}

// 浏览器默认关闭事件
const browserClose = (e: any) => {
  if (isSave.value) {
    return
  }
  e.preventDefault()
  e.returnValue = ''
}

onMounted(() => {
  getBaseConfig()
  window.addEventListener('beforeunload', browserClose, false)
})

onBeforeUnmount(() => {
  window.removeEventListener('beforeunload', browserClose, false)
})

onBeforeRouteLeave(async (to, from) => {
  console.log(to, from)
  const res = await beforeUnload()
  if (!res) return false
})
const onSubmit = () => {
  console.log('submit!', form)
  const params = Object.keys(currencyMap).map((item) => {
    if (form.base === item) {
      return {
        baseCcy: 'Y',
        ccy: item,
        rate: 1,
      }
    } else {
      return {
        baseCcy: 'N',
        ccy: item,
        rate: form[item],
      }
    }
  })
  console.log('params', params)
  saveRate(params).then((res) => {
    console.log('res', res)
    const { code } = res
    if (code === 0) {
      ElMessage.success(t('save_success'))
      isSave.value = true
      // showChangeLog()
    }
  })
}
</script>

<style lang="scss" scoped>
:deep(.el-form-item) {
  align-items: center;
}

.text {
  margin-left: 10px;
}

:deep(.el-form .el-form-item .el-input) {
  width: auto;
}

:deep(.el-input-number .el-input__inner) {
  padding: 0;
}
</style>
