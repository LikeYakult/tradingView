<template>
  <div class="page-container">
    <baseFilter
      :loading="isLoading"
      :config="filterConfig"
      @onSearch="searchHandle"
      @onReset="resetHandle"
    ></baseFilter>
    <div class="operate-buttons">
      <el-button
        class="toolbar-add-button"
        type="primary"
        @click="openNewRolesDialog"
        v-permission="'role:info:add'"
        >{{ $t('new') }}</el-button
      >
      <el-popconfirm
        :width="280"
        cancel-button-type=""
        :title="$t('sure_to_batch_deleted')"
        hide-icon
        :visible="visible"
        @confirm="batchDeleteConfirm"
        @cancel="visible = false"
      >
        <template #reference
          ><el-button
            plain
            type="info"
            v-permission="'role:info:deleteBatch'"
            @click="showDelete"
            >{{ $t('batch_deleted') }}</el-button
          ></template
        >
      </el-popconfirm>
    </div>
    <baseTable
      ref="tablePaginationRef"
      :config="tableConfig"
      :pagination="paginationConfig"
      :isTableLoading="isLoading"
    >
      <template v-slot:operate>
        <el-table-column :label="$t('operation')" width="240" align="center" fixed="right">
          <template #default="scope">
            <span
              @click="openEditRolesDialog(scope.row)"
              v-if="scope.row.id == 1"
              class="text-primary mr10"
              v-permission="'role:info:permission:list'"
              aria-disabled="true"
              style="pointer-events: none"
              >{{ $t('permissions') }}</span
            >
            <span
              @click="openModifyPermissionsDialog(scope.row)"
              v-permission="'role:info:permission:list'"
              v-else
              class="text-primary mr10"
              >{{ $t('permissions') }}</span
            >
            <span
              @click="openEditRolesDialog(scope.row)"
              v-if="scope.row.id == 1"
              class="text-primary mr10"
              v-permission="'role:info:modify'"
              aria-disabled="true"
              style="pointer-events: none"
              >{{ $t('modify') }}</span
            >
            <span
              @click="openEditRolesDialog(scope.row)"
              v-permission="'role:info:modify'"
              v-else
              class="text-primary mr10"
              >{{ $t('modify') }}</span
            >
            <el-popconfirm
              :width="280"
              cancel-button-type=""
              :title="$t('determine_deleted')"
              hide-icon
              @confirm="deleteRoleConfirm"
            >
              <template #reference>
                <span
                  class="text-primary mr10"
                  v-if="scope.row.id == 1"
                  v-permission="'role:info:delete'"
                  aria-disabled="true"
                  style="pointer-events: none"
                  >{{ $t('delete') }}</span
                >
                <span class="text-primary mr10" v-permission="'role:info:delete'" v-else>{{
                  $t('delete')
                }}</span>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </template>
    </baseTable>
    <!-- 新建/修改角色 -->
    <el-dialog
      v-model="isShowNewEditRoles"
      :close-on-click-modal="false"
      width="500px"
      :title="newEditRolesType === 'new' ? $t('new_role') : $t('modify_role')"
      center
      append-to-body
      @close="closeEditDialog"
    >
      <el-form
        ref="newEditRolesRef"
        :model="newEditRolesForm"
        :rules="newEditRolesRule"
        label-width="100px"
        style="width: 80%; margin: 0 auto"
      >
        <el-form-item :label="`${$t('superior_role')}：`" prop="parentId">
          <el-select v-model="newEditRolesForm.parentId" @change="onChangeRoleId">
            <el-option
              v-for="roleItem of superiorRoleList"
              :key="roleItem.value"
              :label="roleItem.label"
              :value="roleItem.value"
              :disabled="
                newEditRolesType !== 'new' && selectedRow.id && selectedRow.id === roleItem.value
              "
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="`${$t('role_name')}：`" prop="name">
          <el-input v-model="newEditRolesForm.name" maxlength="20"></el-input>
        </el-form-item>
        <el-form-item
          :label="`${$t('permissions')}：`"
          prop="menuIds"
          v-if="newEditRolesType === 'new'"
        >
          <el-button @click="clickSettingPermission">{{ $t('click_settings') }}</el-button>
        </el-form-item>
        <el-form-item :label="`${$t('remarks')}：`" prop="remark">
          <el-input v-model="newEditRolesForm.remark" maxlength="100"></el-input>
        </el-form-item>
      </el-form>
      <el-dialog
        v-model="isShowNewEditRolesInner"
        :close-on-click-modal="false"
        :title="$t('permissions')"
        center
        append-to-body
        width="800px"
        @close="handleDialogClose"
      >
        <permission-selector
          ref="permissionsTreeRef"
          :data="permissionsTree"
          :node-props="defaultTreeProps"
          :modules="tabList"
          :active-module="currentTab"
          :default-checked-keys="defaultCheckedKeys"
          :loading="permissionLoading"
          @moduleChange="tabClickForModify"
          @check="handleCheck"
        />
        <template #footer>
          <span class="dialog-footer">
            <el-button
              type="primary"
              :disabled="permissionLoading || !permissionReady"
              @click="permissionsTreeConfirm"
              >{{ $t('determine') }}</el-button
            >
            <el-button @click="isShowNewEditRolesInner = false">{{ $t('cancel') }}</el-button>
          </span>
        </template>
      </el-dialog>
      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" :loading="loading" @click="toNewEditRoles">{{
            $t('determine')
          }}</el-button>
          <el-button @click="isShowNewEditRoles = false">{{ $t('cancel') }}</el-button>
        </span>
      </template>
    </el-dialog>
    <!-- 修改权限 -->
    <el-dialog
      v-model="isShowModifyPermissions"
      :close-on-click-modal="false"
      :title="$t('modify_permissions')"
      @close="handleDialogClose"
      center
      append-to-body
      width="800px"
    >
      <permission-selector
        ref="permissionsTreeRef"
        :data="permissionsTree"
        :node-props="defaultTreeProps"
        :modules="tabList"
        :active-module="currentTab"
        :loading="permissionLoading"
        :default-checked-keys="defaultCheckedKeys"
        @moduleChange="tabClickForModify"
        @check="handleCheck"
      />
      <template #footer>
        <span class="dialog-footer">
          <el-button
            type="primary"
            :loading="permissionSaving"
            :disabled="permissionLoading || !permissionReady"
            @click="modifyPermissionsConfirm"
            >{{ $t('determine') }}</el-button
          >
          <el-button @click="isShowModifyPermissions = false">{{ $t('cancel') }}</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>
<script lang="ts">
import { defineComponent, nextTick, onBeforeMount, reactive, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage } from 'element-plus'
import baseFilter from '@/components/base-filter/base-filter'
import baseTable from '@/components/base-table/base-table'
import permissionSelector from '@/components/permission-selector/permission-selector.vue'

import {
  getUserRoleList,
  getUserManagementRoleList,
  deleteRole,
  batchDeleteRole,
  getRolePermissions,
  newRolesApi,
  editRolesApi,
  modifyPermissions,
  getModulesByRole,
} from '@/api/subPro/subPro'

export default defineComponent({
  name: 'account-role-management',
  components: {
    baseFilter,
    baseTable,
    permissionSelector,
  },
  setup() {
    const { t } = useI18n()
    const tablePaginationRef = ref()
    const pageSize = ref(20)
    const currentPage = ref(1)
    const searchData = ref()
    const isLoading = ref<boolean>(false)
    const ordering = ref({
      asc: true,
      column: '',
    })

    /* 表格-start */
    // 选中行数
    let tableSelectionRows: any[] = []
    const tableSelectionChange = (selection: []) => {
      tableSelectionRows = selection
    }
    // 选中行
    const selectedRow = ref()
    const tableConfig = reactive({
      tableProps: {
        data: [] as Record<string, any>[],
      },
      tableEvent: {
        onSelectionChange: tableSelectionChange,
        onRowClick: (row: object) => {
          selectedRow.value = row
        },
        onSortChange: (column: Record<string, any>) => {
          const { order, prop } = column
          ordering.value.column = ''
          currentPage.value = 1
          paginationConfig.value.paginationProps.currentPage = 1

          if (order) {
            ordering.value = {
              asc: order === 'ascending',
              column: prop,
            }
          }
          return toGetUserRoleList()
        },
      },
      customColumns: [
        { type: 'selection', align: 'center' },
        { label: t('add_time'), prop: 'createTime', sortable: 'custom' },
        { label: t('role_name'), prop: 'name', sortable: 'custom' },
        { label: t('superior_role'), prop: 'parentName', sortable: 'custom' },
        { label: t('remarks'), prop: 'remark' },
        { slot: 'operate' },
      ],
    })

    /* 表格-end */

    /* 分页-start */
    const paginationConfig = ref({
      paginationProps: { total: 0, 'page-size': 20, currentPage: 1 },
      paginationEvent: {
        onSizeChange: handleSizeChange,
        onCurrentChange: handleCurrentChange,
      },
    })
    function handleSizeChange(currentSize: number) {
      paginationConfig.value.paginationProps['page-size'] = currentSize
      tablePaginationRef.value?.toFirstPage()
      currentPage.value = 1
      pageSize.value = currentSize
      toGetUserRoleList()
    }
    function handleCurrentChange(theCurrentPage: number) {
      currentPage.value = theCurrentPage
      paginationConfig.value.paginationProps.currentPage = theCurrentPage
      toGetUserRoleList()
    }
    /* 分页-end */

    function toGetUserRoleList() {
      isLoading.value = true
      const params = {
        ...searchData.value,
        pageSize: pageSize.value,
        pageNum: currentPage.value,
      }

      if (ordering.value.column) {
        Object.assign(params, {
          orders: [ordering.value],
        })
      }

      getUserRoleList(params)
        .then((res: { [key: string]: any }) => {
          tableConfig.tableProps.data = res.result?.records
          paginationConfig.value.paginationProps.total = res.result?.total || 0
        })
        .finally(() => {
          isLoading.value = false
        })
    }

    /* 过滤表单-start */
    const filterConfig = ref({
      formProps: {
        model: {
          keyword: '',
          parentId: '',
        },
      },
      formItems: [
        {
          prop: 'keyword',
          label: t('role_name'),
          innerEl: {
            elType: 'input',
            props: { placeholder: t('please_enter_role_name') },
          },
        },
        {
          prop: 'parentId',
          label: t('superior_role'),
          innerEl: {
            elType: 'select',
            options: [],
            width: '200px',
          },
        },
      ],
    })

    const superiorRoleList = ref()
    const getRuleList = () => {
      getUserManagementRoleList({
        pageSize: 100000,
        showCurrent: true,
      }).then((res) => {
        const options = (res.result?.records || []).map((record: { [key: string]: any }) => ({
          label: record.name,
          value: record.id,
        }))
        superiorRoleList.value = options
        filterConfig.value.formItems[1].innerEl.options = options
      })
    }

    const searchHandle = (data: { [name: string]: any }) => {
      currentPage.value = 1
      tablePaginationRef.value?.toFirstPage()
      // 携带自定义插槽数据并请求查询
      searchData.value = { ...data }
      toGetUserRoleList()
    }

    const resetHandle = (data: { [name: string]: any }) => {
      currentPage.value = 1
      tablePaginationRef.value?.toFirstPage()
      // 重置自定义插槽数据并请求查询
      searchData.value = { ...data }
      toGetUserRoleList()
    }
    /* 过滤表单-end */

    // 批量删除
    const toBatchDeleteRole = () => {
      if (tableSelectionRows?.length === 0) return ElMessage.error(t('select_batch_delete_data'))
      const ids = tableSelectionRows.map((item) => item.id)
      return batchDeleteRole({ ids })
        .then(() => {
          ElMessage.success(t('delete_success'))
          toGetUserRoleList()
        })
        .finally(() => {
          visible.value = false
        })
    }
    const batchDeleteConfirm = () => {
      toBatchDeleteRole()
      return true
    }

    // 模块列表
    const tabList = ref<{ label: string; value: string }[]>([])
    const currentTab = ref('')
    const permissionLoading = ref(false)
    const permissionReady = ref(false)
    const permissionSaving = ref(false)
    let permissionRequestId = 0
    const getModulesByRoles = async (parentRoleId: number | string, roleId?: number | string) => {
      const requestId = ++permissionRequestId
      permissionLoading.value = true
      permissionReady.value = false
      const getRulesParams = {
        parentId: parentRoleId,
      }

      if (roleId) {
        Object.assign(getRulesParams, {
          id: roleId,
        })
      }

      try {
        const res = await getModulesByRole({
          id: parentRoleId,
        })
        if (requestId !== permissionRequestId) return
        const result = res.result || []
        tabList.value = result.map((item: Record<string, any>) => ({
          label: item.name,
          value: item.code,
        }))

        const codeVal = tabList.value[0]?.value || ''
        currentTab.value = codeVal
        if (codeVal) {
          await toGetRolePermissions(codeVal, getRulesParams)
        } else {
          permissionsTree.value = []
          defaultCheckedKeys.value = []
          permissionLoading.value = false
        }
      } catch {
        if (requestId === permissionRequestId) permissionLoading.value = false
      }
    }

    /* 新建/修改角色-start */
    const isShowNewEditRoles = ref(false)
    const isShowNewEditRolesInner = ref(false)
    const newEditRolesRef = ref()
    const newEditRolesForm = ref({
      parentId: '',
      name: '',
      remark: '',
    })
    const newEditRolesRule = {
      parentId: [{ required: true, message: t('please_select_superior_role'), trigger: 'change' }],
      name: [{ required: true, message: t('please_enter_role_name'), trigger: 'blur' }],
    }

    // 权限树
    const permissionsTreeRef = ref()
    const defaultTreeProps = {
      children: 'children',
      label: 'name',
      disabled: 'disabled',
    }

    // 选中的树节点
    const permissionsTree = ref<any[]>([])
    const defaultCheckedKeys = ref<(string | number)[]>([])
    const modulesCheckedMenuId = ref<Record<string, (string | number)[]>>({})
    const cacheModulesChecked = ref<Record<string, (string | number)[]>>({})

    const handleCheck = (data: Record<string, any>, checked: Record<string, any>) => {
      if (permissionLoading.value || !permissionReady.value) return
      const { halfCheckedKeys, checkedKeys } = checked

      modulesCheckedMenuId.value[currentTab.value] = [...halfCheckedKeys, ...checkedKeys]
    }

    const filterMenuId = (menus: any[] = [], menuIds: (string | number)[] = []) => {
      menus.forEach((menu) => {
        const { id, children = [] } = menu

        if (children.length) {
          menuIds.push(id)
          filterMenuId(children, menuIds)
        }
      })

      return menuIds
    }

    const toGetRolePermissions = async (moduleCode: string, params?: object) => {
      const requestId = ++permissionRequestId
      permissionLoading.value = true
      permissionReady.value = false
      permissionsTree.value = []
      defaultCheckedKeys.value = []
      try {
        const res = await getRolePermissions(moduleCode, params)
        if (requestId !== permissionRequestId || moduleCode !== currentTab.value) return
        const { permissions = [], checkedList = [] } = res.result || {}
        const menuIds = filterMenuId(permissions)
        const checked = modulesCheckedMenuId.value[moduleCode] ?? checkedList
        modulesCheckedMenuId.value[moduleCode] = [...checked]
        permissionsTree.value = permissions
        // 父节点只用于提交，回显仅勾选叶节点，避免把半选父节点的所有子项选中。
        defaultCheckedKeys.value = checked.filter((id: string | number) => !menuIds.includes(id))
        await nextTick()
        if (requestId !== permissionRequestId) return
        await permissionsTreeRef.value?.setCheckedKeys(defaultCheckedKeys.value, false)
        permissionReady.value = true
      } catch {
        // 请求层显示业务错误；加载失败时禁止提交空权限。
      } finally {
        if (requestId === permissionRequestId) permissionLoading.value = false
      }
    }

    const permissionsTreeConfirm = () => {
      cacheModulesChecked.value = Object.assign({}, modulesCheckedMenuId.value)

      isShowNewEditRolesInner.value = false
    }

    const tabClickForModify = (tab: string) => {
      currentTab.value = tab

      if (isShowNewEditRoles.value) {
        // 新增
        const { parentId } = newEditRolesForm.value
        toGetRolePermissions(tab, { parentId })
        return
      }

      if (selectedRow.value) {
        const { id, parentId } = selectedRow.value
        toGetRolePermissions(tab, { id, parentId })
        return
      }
    }

    const clickSettingPermission = () => {
      const { parentId } = newEditRolesForm.value
      if (!parentId) {
        ElMessage.warning(t('select_upper_level_role_first'))
        return
      }

      const cacheChecked = cacheModulesChecked.value
      if (cacheChecked) {
        modulesCheckedMenuId.value = Object.assign({}, cacheChecked)
      }

      isShowNewEditRolesInner.value = true
      getModulesByRoles(parentId)
    }

    // 打开新建角色对话框
    const newEditRolesType = ref('new')

    const openNewRolesDialog = () => {
      // 获取所有角色
      getRuleList()

      newEditRolesType.value = 'new'
      isShowNewEditRoles.value = true
    }

    const getModulesCheckedMenuId = () => {
      const modulesCheckedMenus = modulesCheckedMenuId.value
      const modulesKeys = Object.keys(modulesCheckedMenus)

      if (modulesKeys.length) {
        const modulesChecked = modulesKeys.map((key) => {
          return { code: key, menuIds: modulesCheckedMenus[key] }
        })

        return modulesChecked
      }

      const cacheCheckedMenus = cacheModulesChecked.value
      return Object.keys(cacheCheckedMenus).map((key) => {
        return { code: key, menuIds: cacheCheckedMenus[key] }
      })
    }

    const loading = ref(false)

    const toNewEditRoles = () => {
      newEditRolesRef.value.validate((validate: boolean) => {
        if (!validate) {
          return
        }
        loading.value = true
        if (newEditRolesType.value === 'new') {
          const modules = getModulesCheckedMenuId()
          const params = {
            modules,
            ...newEditRolesForm.value,
          }

          newRolesApi(params)
            .then(() => {
              ElMessage.success(t('add_success'))
              isShowNewEditRoles.value = false

              getRuleList()
              toGetUserRoleList()
            })
            .finally(() => {
              loading.value = false
            })
          return
        }

        const { id } = selectedRow.value
        editRolesApi({ id, ...newEditRolesForm.value })
          .then(() => {
            ElMessage.success(t('modify_success'))
            isShowNewEditRoles.value = false

            getRuleList()
            toGetUserRoleList()
          })
          .finally(() => {
            loading.value = false
          })
      })
    }

    const openEditRolesDialog = (row: any) => {
      selectedRow.value = row
      // 获取所有角色
      getRuleList()

      newEditRolesType.value = 'edit'

      const { parentId, name, remark } = row
      newEditRolesForm.value.parentId = parentId
      newEditRolesForm.value.name = name
      newEditRolesForm.value.remark = remark
      isShowNewEditRoles.value = true
    }
    /* 新建/修改角色-end */

    /* 操作列 */

    // 修改权限
    const isShowModifyPermissions = ref(false)

    const openModifyPermissionsDialog = (row: any) => {
      selectedRow.value = row
      modulesCheckedMenuId.value = {}
      isShowModifyPermissions.value = true
      getModulesByRoles(row.parentId, row.id)
    }

    const modifyPermissionsConfirm = () => {
      if (permissionLoading.value || !permissionReady.value || permissionSaving.value) return
      const modules = getModulesCheckedMenuId()
      const { id } = selectedRow.value
      const params = {
        id,
        modules,
      }

      permissionSaving.value = true
      modifyPermissions(currentTab.value, params)
        .then(() => {
          isShowModifyPermissions.value = false
          ElMessage.success(t('modify_permissions_success'))

          getRuleList()
          toGetUserRoleList()
        })
        .finally(() => {
          permissionSaving.value = false
        })
    }

    // 选择权限Dialog关闭时
    const handleDialogClose = () => {
      ++permissionRequestId
      permissionLoading.value = false
      permissionReady.value = false
      modulesCheckedMenuId.value = {}

      tabList.value = []
      currentTab.value = ''

      permissionsTree.value = []
      defaultCheckedKeys.value = []
      permissionsTreeRef.value?.setCheckedKeys([], false)
    }

    const toDeleteRole = () => {
      const { id } = selectedRow.value
      deleteRole({ id }).then(() => {
        ElMessage.success(t('delete_success'))

        getRuleList()
        toGetUserRoleList()
      })
    }

    const deleteRoleConfirm = () => {
      toDeleteRole()
      return true
    }

    // 上级角色发生改变时
    const onChangeRoleId = () => {
      cacheModulesChecked.value = {}
      modulesCheckedMenuId.value = {}
    }

    // 新增/编辑 角色弹窗关闭时
    const closeEditDialog = () => {
      newEditRolesRef.value?.resetFields()
      isShowNewEditRolesInner.value = false
      handleDialogClose()
      newEditRolesForm.value = {
        parentId: '',
        name: '',
        remark: '',
      }

      onChangeRoleId()
    }

    onBeforeMount(() => {
      getRuleList()
      toGetUserRoleList()
    })

    const visible = ref<boolean>(false)
    const showDelete = () => {
      if (!tableSelectionRows.length) {
        visible.value = false
        ElMessage.warning(t('selectItem'))
        return
      }
      visible.value = true
    }

    return {
      tableConfig,
      paginationConfig,
      filterConfig,
      searchHandle,
      resetHandle,
      superiorRoleList,
      batchDeleteConfirm,
      isShowModifyPermissions,
      tabList,
      openModifyPermissionsDialog,
      modifyPermissionsConfirm,
      handleDialogClose,
      deleteRoleConfirm,
      isShowNewEditRoles,
      newEditRolesRef,
      newEditRolesForm,
      newEditRolesRule,
      tabClickForModify,
      permissionsTreeRef,
      defaultTreeProps,
      permissionsTree,
      clickSettingPermission,
      permissionsTreeConfirm,
      newEditRolesType,
      openNewRolesDialog,
      openEditRolesDialog,
      isShowNewEditRolesInner,
      toNewEditRoles,
      loading,
      isLoading,
      permissionLoading,
      permissionReady,
      permissionSaving,
      currentTab,
      handleCheck,
      visible,
      showDelete,
      onChangeRoleId,
      defaultCheckedKeys,
      closeEditDialog,
      selectedRow,
    }
  },
})
</script>
<style lang="scss" scoped>
/* stylelint-disable selector-pseudo-class-no-unknown -- Vue scoped selectors. */
.mr10 {
  margin-right: 10px;
}

.base-filter {
  :deep(.el-select) {
    width: 200px;
  }
}
</style>
