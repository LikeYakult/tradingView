<template>
  <div class="page-container">
    <baseFilter :loading="loading" :config="filterConfig" @on-search="handle" @on-reset="handle"></baseFilter>
    <div class="operate-buttons">{{ $t('file_import_prompt') }}</div>
    <baseTable :config="tableConfig" :pagination="pagination" :is-table-loading="loading">
      <template #logName>
        <el-table-column :label="$t('import_logs')" align="center">
          <template #default="scope">
            <span class="text-primary" @click="toDownloadJournal(scope.row)">{{
              scope.row.logName
            }}</span>
          </template>
        </el-table-column>
      </template>
      <template #status>
        <el-table-column :label="$t('import_state')" align="center">
          <template #default="scope">
            {{ scope.row.status === 0 ? t('failure') : t('success') }}
          </template>
        </el-table-column>
      </template>
    </baseTable>
  </div>
</template>
<script lang="ts" setup>
import { reactive, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import baseFilter from '@/components/base-filter/base-filter'
import baseTable from '@/components/base-table/base-table'
import { toDownload } from '@/utils/common'
import { fileImportLogExport } from '@/api/subPro/subPro'
import useTableData from '@/hooks/useTableData'
import ConfigType from '@/types/requestType'
import { cloneDeep } from '@/utils/common'

const { t } = useI18n()

const searchData = ref()

const ordering = ref<Record<string, any>>({
  asc: true,
  column: '',
})

const reqConfig = reactive<ConfigType>({
  url: '/login/log/list',
  method: 'POST',
  data: {},
})

const { tableData, pagination, loading } = useTableData(reqConfig)

const tableConfig = reactive({
  tableProps: {
    data: tableData,
  },
  tableEvent: {
    onSortChange: (column: Record<string, any>) => {
      const { order, prop } = column
      ordering.value.column = prop
      if (!order) {
        ordering.value.column = undefined
        ordering.value.asc = undefined
      } else {
        ordering.value.asc = order === 'ascending' ? true : false
      }
      handle()
    },
  },
  customColumns: [
    { label: t('login_account'), prop: 'username' },
    { label: t('fullName'), prop: 'nickname' },
    { label: t('import_file'), prop: 'sourceName' },
    { slot: 'logName' },
    { slot: 'status' },
    { label: t('import_time'), prop: 'createTime' },
  ],
})

/* 过滤表单-start */
const filterConfig = ref({
  formProps: {
    model: {
      importTime: '',
      status: '',
      keyword: '',
    },
  },
  formItems: [
    {
      prop: 'importTime',
      label: t('import_time'),
      innerEl: {
        elType: 'datePicke',
        props: { type: 'daterange', 'value-format': 'YYYY-MM-DD' },
      },
    },
    {
      prop: 'status',
      label: t('import_state'),
      innerEl: {
        elType: 'select',
        options: [
          { value: '', label: t('all') },
          { label: t('success'), value: 1 },
          { label: t('failure'), value: 0 },
        ],
      },
    },
    {
      prop: 'keyword',
      label: '',
      innerEl: {
        elType: 'input',
        props: { placeholder: t('please_enter_keyword') },
      },
    },
  ],
})

/* 过滤表单-end */

const toDownloadJournal = (row: any) => {
  const { id, logName } = row
  fileImportLogExport({ id }).then((res) => {
    toDownload(res, `${logName}.xlsx`)
  })
}

const handle = () => {
  const params: Record<string, any> = cloneDeep(filterConfig.value.formProps.model)
  if (params.registerTime) {
    const [regBeginTime, regEndTime] = params.registerTime
    params.regBeginTime = regBeginTime
    params.regEndTime = regEndTime
  }
  if (ordering.value.column) {
    params.orders = [ordering.value]
  }
  searchData.value = cloneDeep(params)
  reqConfig.data = cloneDeep(params)
}
</script>
