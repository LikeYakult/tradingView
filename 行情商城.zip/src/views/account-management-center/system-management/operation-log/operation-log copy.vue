<template>
  <div class="page-container">
    <div class="operate-buttons">
      <el-button plain class="export-button">导出</el-button>
    </div>
    <baseTable ref="tablePaginationRef" :config="tableConfig" :pagination="paginationConfig">
    </baseTable>
  </div>
</template>
<script lang="ts">
import { defineComponent, reactive, ref } from 'vue'
// import baseFilter from '@/components/base-filter/base-filter'
import baseTable from '@/components/base-table/base-table'
import { getUserOperationLog } from '@/api/subPro/subPro'

export default defineComponent({
  name: 'account-operation-log',
  components: {
    // baseFilter,
    baseTable,
  },
  setup() {
    const tablePaginationRef = ref()
    const pageSize = ref(20)
    const currentPage = ref(1)
    const searchData = ref()

    /* 表格-start */
    const tableConfig = reactive({
      tableProps: {
        data: <{ date: string; name: string; address: string }[]>[],
      },
      tableEvent: {},
      customColumns: [
        { label: '登录账号', prop: 'username' },
        { label: '姓名', prop: 'nickname' },
        { label: '操作名称', prop: 'remark' },
        { label: '操作状态', prop: 'status' },
        { label: 'IP地址', prop: 'ip' },
        { label: '操作时间', prop: 'createTime' },
        // { slot: 'operate' }
      ],
    })
    /* 表格-end */

    /* 分页-start */
    const paginationConfig = ref({
      paginationProps: { total: 0, 'page-size': 20 },
      paginationEvent: {
        onSizeChange: handleSizeChange,
        onCurrentChange: handleCurrentChange,
      },
    })
    function handleSizeChange(currentSize: number) {
      paginationConfig.value.paginationProps['page-size'] = currentSize
      tablePaginationRef.value?.toFirstPage()
      currentPage.value = 1
      pageSize.value = currentSize
      // toGetUserRoleList()
    }
    function handleCurrentChange(theCurrentPage: number) {
      currentPage.value = theCurrentPage
      // toGetUserRoleList()
    }
    /* 分页-end */

    function toGetUserOperationLog() {
      const params = {
        ...searchData.value,
        pageSize: pageSize.value,
        pageNum: currentPage.value,
      }
      getUserOperationLog(params).then((res: { [key: string]: any }) => {
        tableConfig.tableProps.data = res.result?.records
        paginationConfig.value.paginationProps.total = res.result?.total || 0
      })
    }
    toGetUserOperationLog()

    return {
      tableConfig,
      paginationConfig,
    }
  },
})
</script>
