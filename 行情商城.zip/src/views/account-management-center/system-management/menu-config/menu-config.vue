<template>
  <div class="menu-config">
    <div class="handler-box">
      <div>
        <el-button
          v-permission="'sys:menuConfig:restoreInit'"
          type="primary"
          plain
          :disabled="!customList.length"
          @click="handlerResetClick"
        >
          {{ $t('restore_init_config') }}
        </el-button>
      </div>
      <check-lang v-model="lang" />
    </div>
    <div class="container">
      <div class="content">
        <div class="content-title">{{ $t('init_config') }}</div>
        <el-tree :data="menuList" :props="defaultProps" class="tree-item" render-after-expand>
          <template #default="{ node, data }">
            <div class="el-tree-node__label flex-start">
              <el-icon v-show="node.level === 1"><FolderOpened /></el-icon>
              <el-icon v-show="node.level === 2"><Files /></el-icon>
              <el-icon v-show="node.level === 3"><Document /></el-icon>
              {{ currLangMenuName(data.nameList) }}
            </div>
          </template>
        </el-tree>
      </div>
      <el-divider direction="vertical" />
      <div class="content">
        <div class="content-title">
          {{ $t('custom_config') }}
          <span class="title-hint">
            {{ $t('custom_confit_drag_hint_text') }}
          </span>
        </div>
        <el-tree
          :draggable="enableEdit"
          render-after-expand
          :data="customList"
          :props="defaultProps"
          class="tree-item"
          :allow-drag="handleAllowDrag"
          :allow-drop="handlelAllowDrop"
          @node-drag-end="handleAllowDragEnd"
          @node-drop="handleAllowDrop"
        >
          <template #default="{ node, data }">
            <el-input
              v-if="editFlagObj[data.code]"
              v-model="data.nameList[editLangIndex].name"
              class="item-input"
              @click.stop
              @blur="handleItemBlur(data)"
              @keydown.enter="editFlagObj[data.code] = false"
            />
            <div v-else class="el-tree-node__label" @dblclick="handleItemDblClick(node, data)">
              <div @click.stop="setLangIndex(data)">
                <el-icon v-show="node.level === 1"><FolderOpened /></el-icon>
                <el-icon v-show="node.level === 2"><Files /></el-icon>
                <el-icon v-show="node.level === 3"><Document /></el-icon>
                {{ currLangMenuName(data.nameList) }}
              </div>
              <div
                v-if="node.level === 1"
                class="icon-uploader"
                @click.stop="Object.assign(currectEditData, data)"
              >
                <el-image v-if="data.icon" :src="data.icon" :preview-src-list="[data.icon]">
                </el-image>
                <el-upload
                  action=""
                  :show-file-list="false"
                  :auto-upload="false"
                  :on-change="handleIconSuccess"
                >
                  <el-button type="text" size="small">{{ $t('upload_logo') }}</el-button>
                </el-upload>
                <el-button v-if="data.icon" type="text" size="small" @click="handleIconDel">
                  {{ $t('delete') }}
                </el-button>
              </div>
            </div>
          </template>
        </el-tree>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { computed, reactive, ref, watch } from 'vue'
import { useAppStore } from '@/store'
import { TreeNodeData } from 'element-plus/lib/components/tree-v2/src/types'
import { ElMessageBox, ElMessage } from 'element-plus'
import { FolderOpened, Files, Document } from '@element-plus/icons-vue'
import {
  ModifyNameParam,
  updateCostomTree,
  getCostomTree,
  getInitTree,
  modifyMenuName,
  restoreInit,
  uploadFiles,
} from '@/api/menuConfig/menuConfig'
import CheckLang from '@/components/check-lang/check-lang'
import { langType } from '@/utils/request/request'
import { useI18n } from 'vue-i18n'
import { cloneDeep, get, isNil } from 'lodash-es'
import { UploadProps } from 'element-plus/lib/components/upload/src/upload'

const { t } = useI18n()
const appStore = useAppStore()

const defaultProps = {
  children: 'children',
  label: 'code',
}

const lang = ref(langType[appStore.language])

const enableEdit = computed(() => {
  const permission = appStore.permissions['sys:menuConfig:modify']
  return isNil(permission) ? false : permission
})

const enableView = computed(() => {
  const permission = appStore.permissions['sys:menuConfig:view']
  return isNil(permission) ? false : permission
})

const currLangMenuName = (nameList: Record<string, string>[]) => {
  const name = get(
    nameList.find((item) => item.lang === lang.value),
    'name',
    ''
  )
  return name
}

const menuList = ref<any[]>([])

/* 请求获取初始配置 */
const fetcuMenuList = async () => {
  if (!enableView.value) return
  try {
    const { code, result } = await getInitTree({})
    if (code === 0) {
      menuList.value = result
    }
  } catch (err) {
    console.error('获取初始配置失败', err)
  }
}

fetcuMenuList()

const customList = ref<any[]>([])

/* 请求获取个性化配置 */
const fetcuCustomList = async () => {
  if (!enableView.value) return
  try {
    const { code, result } = await getCostomTree({})
    if (code === 0) {
      customList.value = result
    }
  } catch (err) {
    console.error('获取个性化配置失败', err)
  }
}

fetcuCustomList()

/* 请求恢复初始配置 */
const fetchRestoreInit = async () => {
  try {
    const { code, message } = await restoreInit({})
    ElMessage.success(message)
    if (code === 0) {
      fetcuCustomList()
    }
  } catch (error) {
    ElMessage.error('恢复异常')
  }
}

const handlerResetClick = () => {
  ElMessageBox.confirm(t('restore_init_config_hint_text'), t('operation_confirm'), {
    confirmButtonText: t('determine'),
    cancelButtonText: t('cancel'),
    showClose: false,
  }).then(() => {
    fetchRestoreInit()
  })
}

// 发送请求更新目录
const fetchUpdateMenu = async () => {
  try {
    const { code, message } = await updateCostomTree(customList.value)
    ElMessage.success(message)
    if (code !== 0) {
      fetcuCustomList()
    }
  } catch (error) {
    fetcuCustomList()
    console.error('请求异常', error)
  }
}

enum DrapType {
  PREV = 'prev',
  INNER = 'inner',
  NEXT = 'next',
}

const handleAllowDrag = (node: TreeNodeData) => {
  /* 编辑中不可拖动 */
  return editFlagObj[node.data.code] ? false : true
}

/* 是否移动中 */
const dragging = ref(false)
const isHighMoveLow = ref(false)

watch(dragging, () => {
  if (isHighMoveLow.value && !dragging.value) {
    ElMessage.warning(t('high_not_support_moving_low'))
  }
})

const handlelAllowDrop = (draggingNode: TreeNodeData, dropNode: TreeNodeData, type: DrapType) => {
  dragging.value = true
  isHighMoveLow.value = false
  // 父级目录不能拖放到子级目录
  if (draggingNode.level < dropNode.level) {
    isHighMoveLow.value = true
    return false
  }
  // 平级不能拖入，只能排序
  if (
    draggingNode.level === dropNode.level &&
    type === DrapType.INNER &&
    draggingNode.level + dropNode.level !== 2
  ) {
    return false
  }
  return true
}

const handleAllowDrop = (draggingNode: TreeNodeData, dropNode: TreeNodeData, type: DrapType) => {
  // 一级目录拖放到一级目录，将拖拽目录合并到目标目录
  if (draggingNode.level === 1 && dropNode.level === 1 && type === DrapType.INNER) {
    customList.value = customList.value.map((item: any) => {
      return item.code === dropNode.data.code
        ? {
            ...item,
            children: item.children
              .concat(...draggingNode.data.children)
              .filter((item: any) => item.code !== draggingNode.data.code),
          }
        : item
    })
  }

  fetchUpdateMenu()
}

watch(
  customList,
  (list) => {
    console.log('🚀 ~ file: menu-config.vue:74 ~ watch ~ list', list)
  },
  { deep: true }
)

const handleAllowDragEnd = () => {
  dragging.value = false
}

/* 编辑开关列表 */
const editFlagObj = reactive<Record<string, boolean>>({})
/* 当前编辑的菜单数据 */
const currectEditData = reactive<Record<string, any>>({})

const editLangIndex = ref(0)

const setLangIndex = (data: any) => {
  let langIndex = data.nameList.findIndex((item: any) => item.lang === lang.value)
  if (langIndex < 0) {
    data.nameList.push({ lang: lang.value, name: '' })
    langIndex = data.nameList.length - 1
  }
  editLangIndex.value = langIndex
  console.log('🚀 ~ file: menu-config.vue:272 ~ setLangIndex ~ langIndex', langIndex)
}

const updateMenuName = async (param: ModifyNameParam) => {
  try {
    const { code, message } = await modifyMenuName(param)
    ElMessage.success(message)
    if (code !== 0) {
      fetcuCustomList()
    }
  } catch (error) {
    fetcuCustomList()
    console.error('请求异常', error)
  }
}

const handleItemDblClick = (node: TreeNodeData, data: any) => {
  if (enableEdit.value) {
    Object.assign(editFlagObj, { [data.code]: true })
    Object.assign(currectEditData, cloneDeep(data))
  }
}

const handleItemBlur = (data: any) => {
  Object.assign(editFlagObj, { [data.code]: false })
  if (data.nameList[editLangIndex.value].name) {
    updateMenuName({
      id: data.id,
      moduleCode: data.moduleCode,
      lang: lang.value,
      name: data.nameList[editLangIndex.value].name,
    })
  } else {
    /* 新名称为空时，恢复修改前的名称 */
    data.nameList[editLangIndex.value].name = currectEditData.nameList[editLangIndex.value].name
  }
}

const handleIconSuccess: UploadProps['onChange'] = (file) => {
  const fileSuffix = file.name.substring(file.name.lastIndexOf('.') + 1)

  const whiteList = ['jpeg', 'jpg', 'png']
  if (whiteList.indexOf(fileSuffix) == -1) {
    ElMessage.warning(t('upload_logo_file_type_tip'))
    return false
  }
  if (!file.size) return
  const isLt2M = file.size / 1024 / 1024 < 2
  if (!isLt2M) {
    ElMessage.warning(t('upload_logo_max_size_tip'))
    return false
  }

  const formData = new FormData()
  if (file.raw) {
    formData.append('file', file.raw)
  }

  uploadFiles(formData).then((res: any) => {
    console.log('🚀 ~ file: menu-config.vue:334 ~ uploadFiles ~ res', res)
    if (res.code === 0) {
      customList.value = customList.value.map((item: any) => {
        return item.code === currectEditData.code ? { ...item, icon: res.result.url } : item
      })
      fetchUpdateMenu()
    }
  })
}

const handleIconDel = () => {
  customList.value = customList.value.map((item: any) => {
    return item.code === currectEditData.code ? { ...item, icon: '' } : item
  })
  fetchUpdateMenu()
}
</script>

<style lang="scss" scoped>
/* stylelint-disable selector-class-pattern */
/* stylelint-disable selector-pseudo-class-no-unknown */
.menu-config {
  padding: 0 20px;
}

.handler-box {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 0;
  border-bottom: 1px solid rgb(221 221 221);
}

.container {
  margin: 10px 0;
  display: flex;

  > div {
    height: calc(100vh - 150px);
  }

  > .content {
    flex: 1 0;

    > .el-tree {
      height: calc(100% - 30px);
      overflow: auto;
    }
  }

  .content-title {
    font-weight: 700;
  }

  .title-hint {
    font-size: 14px;
    color: #aaa;
    font-weight: 400;
    padding-left: 10px;
  }

  .costom-hint {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: calc(100% - 50px);
  }
}

.item-input {
  width: 250px;
}

.tree-item :deep .el-tree-node__label {
  display: flex;
  justify-items: start;
  align-items: center;
  min-width: 100px;

  .el-icon {
    margin-right: 5px;
  }
}

.tree-item :deep .el-tree-node__content {
  height: 40px;

  .el-tree-node__label {
    flex: 1;
    justify-content: space-between;

    &.flex-start {
      justify-content: flex-start;
    }
  }

  .icon-uploader {
    display: flex;
    justify-content: flex-end;
    align-items: center;

    .el-image {
      width: 25px;
      height: 25px;
      border-radius: 50%;
    }

    .el-button {
      min-width: auto;
    }
  }
}
</style>
