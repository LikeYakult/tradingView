<template>
  <div>
    <el-dialog
      v-model="isShow"
      title="新建"
      :close-on-click-modal="false"
      width="600px"
      center
      destroy-on-close
    >
      <div class="main">
        <el-form :model="form" label-width="80px">
          <el-form-item label="敏感词" prop="words" required>
            <el-input
              v-model="form.words"
              type="textarea"
              :rows="4"
              placeholder="请输入敏感词，逗号隔开"
            >
            </el-input>
          </el-form-item>
        </el-form>
      </div>
      <div class="btns">
        <el-button type="danger" @click="handlerCancel">{{ t('cancel') }}</el-button>
        <el-popconfirm
          :width="280"
          cancel-button-type=""
          title="您确定要提交吗？" @confirm="handlerSubmit">
          <template #reference>
            <el-button type="primary">确认</el-button>
          </template>
        </el-popconfirm>
      </div>
    </el-dialog>
  </div>
</template>

<script lang="ts" setup>
import { reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { useI18n } from 'vue-i18n'
import baseFilter from '@/components/base-filter/base-filter'
import baseTable from '@/components/base-table/base-table'
import useTableData from '@/hooks/useTableData'
import { cloneDeep } from '@/utils/common'

const { t } = useI18n()

interface LinkItem {
  value: string
  link: string
}
const isShow = ref(false)

const form = reactive({
  words: '',
})

const handleOpen = () => {
  isShow.value = true
}

const handlerCancel = () => {
  isShow.value = false
}

const handlerSubmit = () => {
  console.log('handlerSubmit')
  if (form.words === '') return
  const newWords = JSON.parse(JSON.stringify(form.words)).trim().replace(' ', '').split(',')
  console.log(newWords)
}

defineExpose({
  handleOpen,
})
</script>

<style scoped lang="scss">
:deep(.el-dialog > .el-dialog__body) {
  height: 600px !important;
  overflow-y: auto !important;
}

.main {
  padding: 50px 0;
}

.btns {
  width: 300px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
}
</style>
