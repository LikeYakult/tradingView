<script setup lang="ts">
import { reactive, onBeforeMount, ref } from 'vue'
import { useI18n } from 'vue-i18n'
// import { ElMessage } from 'element-plus'
import baseFilter from '@/components/base-filter/base-filter'
import dzTable from '@/components/dz-table/dz-table'

// import { loginLogList, loginListExport } from '@/api/quotation/customer'
import { formToParams } from '@/utils'
// import { timeDiff } from '@/utils/common'
import {
  exportLoginLogsList,
  fetchDicts,
  ITradeLoginLogsListParams,
  loginLogsList,
} from '@/api-v2/nuc/query'
import { extractDict } from '@/utils/options-dictionary'
import { SelectOptions } from '@/types'

const { t } = useI18n()
// #region options
const terminalOptions = ref<SelectOptions>([])

function initDicts() {
  fetchDicts(['terminal']).then((res) => {
    extractDict(res?.result?.terminal, terminalOptions)
  })
}
// #endregion

onBeforeMount(() => {
  initDicts()
})

const isLoading = ref<boolean>(false)
const ordering = ref({
  asc: false,
  column: 'createTime',
})

// 表单配置
const formItems = [
  {
    prop: 'keyword',
    label: t('user_account_keyword'),
    innerEl: { elType: 'input', props: { placeholder: t('please_enter_user_account_phone') } },
  },
  {
    prop: 'terminal',
    label: t('client'),
    innerEl: {
      elType: 'select',
      options: terminalOptions,
    },
  },
  {
    prop: 'country',
    label: t('country_region'),
    innerEl: { elType: 'input', props: { placeholder: t('please_enter_country_area_keyword') } },
  },
  {
    prop: 'searchTime',
    label: t('login_time'),
    innerEl: { elType: 'datePicke', props: { type: 'daterange', 'value-format': 'YYYY-MM-DD' } },
  },
]

const tableConfig = reactive({
  tableProps: {
    data: [],
    height: '580',
  },
  tableEvent: {
    onSortChange: (column: Record<string, any>) => {
      const { order, prop } = column
      ordering.value.column = ''
      pagination.paginationProps.currentPage = 1

      if (order) {
        ordering.value = {
          asc: order === 'ascending',
          column: prop,
        }
      }
      return getData(filterConfig.formProps.model)
    },
  },
  customColumns: [
    { label: t('login_log_id'), prop: 'id', minWidth: '120' },
    { label: t('login_time'), prop: 'createTime', minWidth: '120', sortable: 'custom' },
    { label: t('mobile_number'), prop: 'mobile', minWidth: '120' },
    { label: t('internet_account'), prop: 'cusNo', minWidth: '120' },
    { label: t('device_number'), prop: 'deviceId', minWidth: '200' },
    { label: t('client'), prop: 'terminal' },
    { label: t('version_number'), prop: 'version', minWidth: '120' },
    { label: t('operating_system'), prop: 'os', minWidth: '100' },
    { label: t('ip_address'), prop: 'ip', minWidth: '100' },
    { label: t('country_region'), prop: 'country', minWidth: '100' },
    { slot: 'status' },
  ],
})

/** 表单数据 */
const filterConfig = reactive({
  formProps: {
    model: {
      keyword: '',
      terminal: '',
      country: '',
      searchTime: [],
    },
  },
  // eslint-disable-next-line no-use-before-define
  formItems,
})

const pagination: Record<string, any> = reactive({
  paginationProps: {
    currentPage: 1,
    pageSize: 20,
    total: 0,
  },
  paginationEvent: {
    onSizeChange: (v: number | string) => {
      pagination.paginationProps.pageSize = v
      getData(filterConfig.formProps.model)
    },
    onCurrentChange: (v: number | string) => {
      pagination.paginationProps.currentPage = v
      getData(filterConfig.formProps.model)
    },
  },
})

/**
 * 获取表格数据
 * @param data 传入数据
 */
function getData(data: Record<string, any> = {}) {
  isLoading.value = true
  const page: Record<string, any> = {}
  let beginTime, endTime
  page.pageNum = pagination.paginationProps.currentPage
  page.pageSize = pagination.paginationProps.pageSize
  if (data.searchTime) {
    ;[beginTime, endTime] = data.searchTime
  }

  const params = {
    ...formToParams({ ...page, ...data, beginTime, endTime }),
  } as ITradeLoginLogsListParams

  if (ordering.value.column) {
    Object.assign(params, {
      orders: [ordering.value],
    })
  }

  loginLogsList(params)
    .then((res: Record<string, any>) => {
      tableConfig.tableProps.data = res.result.records
      pagination.paginationProps.currentPage = res.result.current
      pagination.paginationProps.pageSize = res.result.size
      pagination.paginationProps.total = res.result.total
      isLoading.value = false
    })
    .catch((err) => {
      console.log(err)
      isLoading.value = false
    })
}

/** 导出接口 */
const isExportLoading = ref(false)
function exportFunc() {
  const { searchTime = [] } = filterConfig.formProps.model
  // if (!searchTime || !searchTime.length) {
  //   ElMessage.warning(t('export_message'))
  //   return
  // }

  const [beginTime, endTime] = searchTime
  // if (timeDiff(beginTime, endTime)) {
  //   ElMessage.warning(t('export_month_message'))
  //   return
  // }

  const params = { ...filterConfig.formProps.model, beginTime, endTime }
  if (ordering.value.column) {
    Object.assign(params, {
      orders: [ordering.value],
    })
  }

  isExportLoading.value = true
  exportLoginLogsList(params).then(() => {
    isExportLoading.value = false
  })
}

function searchHandle(data: Record<string, any>) {
  const [beginTime, endTime] = data.searchTime
  getData({ beginTime, endTime, ...data })
}

function resetHandle() {
  getData()
}

onBeforeMount(() => {
  getData()
})

const statusText = (num: boolean) => {
  return num ? t('succeed') : t('failure')
}
</script>

<template>
  <el-card>
    <base-filter :loading="isLoading" :config="filterConfig" @on-search="searchHandle" @on-reset="resetHandle" />
    <div class="operate-buttons">
      <el-button
        v-permission="'nuc:loginLog:export'"
        type="primary"
        plain
        :loading="isExportLoading"
        @click="exportFunc"
        >{{ $t('export') }}</el-button
      >
    </div>
    <div class="table">
      <dz-table :config="tableConfig" :pagination="pagination" :is-table-loading="isLoading">
        <template #status>
          <el-table-column :label="$t('login_state')" width="100">
            <template #default="scope">
              <span>{{ statusText(scope.row.loginStatus) }}</span>
            </template>
          </el-table-column>
        </template>
      </dz-table>
    </div>
  </el-card>
</template>
