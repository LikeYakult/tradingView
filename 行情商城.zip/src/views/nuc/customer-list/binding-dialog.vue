<template>
  <el-dialog
    v-model="dialogVisible"
    destroy-on-close
    :title="$t('binding_transaction_account')"
    width="500"
    @closed="onClosed"
  >
    <div class="form-container">
      <el-form :model="form" label-width="auto">
        <el-form-item :label="$t('internet_account')">
          <el-input v-model="form.cusNo" disabled autocomplete="off" />
        </el-form-item>
        <el-form-item :label="$t('trading_name')">
          <el-select-v2
            v-model="selectTradeAccount"
            clearable
            :options="options"
            :loading="loading"
            :placeholder="$t('please_enter_trading_account')"
          />
        </el-form-item>
      </el-form>
    </div>
    <template #footer>
      <div class="dialog-footer">
        <el-button
          type="primary"
          :disabled="!selectTradeAccount"
          :loading="isSubmitting"
          @click="handleConfirm"
        >
          {{ $t('confirm') }}
        </el-button>
        <el-button @click="close">{{ $t('cancel') }}</el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script lang="ts" setup>
import { ElMessage, ElMessageBox } from 'element-plus'

import { fetchRelatedTradeAccount } from '@/api-v2/nuc/query'
import { reactive, ref, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import { SelectOptions } from '@/types'
import { bindTradeAccount } from '@/api-v2/nuc/mutation'

const { t } = useI18n()

const isSubmitting = ref(false)
const dialogVisible = ref(false)
const form = reactive({
  id: 0,
  cusNo: '',
  userName: '',
})

const selectTradeAccount = ref('')
const loading = ref(false)

const options = ref<SelectOptions>([])

function onClosed() {
  form.id = 0
  form.cusNo = ''
  form.userName = ''
  selectTradeAccount.value = ''
  options.value = []
}

watch(
  () => form.id,
  () => {
    if (form.id) {
      fetchRelatedTradeAccount(form.id).then((res: any) => {
        options.value = res.result.map((item: Record<string, any>) => ({
          value: item.tradeAccount,
          label: item.tradeAccount,
        }))
      })
      return
    }

    options.value = []
  },
  {
    immediate: true,
  }
)

const close = () => {
  dialogVisible.value = false
}

const emit = defineEmits(['bindSuccess'])

const handleConfirm = () => {
  isSubmitting.value = true
  bindTradeAccount({
    id: form.id,
    accountInfo: [
      {
        tradeAccount: selectTradeAccount.value,
      },
    ],
  })
    .then(() => {
      ElMessage.success(t('bind_success'))
      emit('bindSuccess')

      dialogVisible.value = false
    })
    .catch((error) => {
      console.error(error)

      if (error?.code === 990305) {
        ElMessageBox.confirm(error.message, t('remind'), {
          confirmButtonText: t('i_know'),
          showCancelButton: false,
          type: 'warning',
          center: true,
        }).catch(() => {
          console.log('cancel')
        })
        return
      }

      ElMessage.error(error?.message)
    })
    .finally(() => {
      isSubmitting.value = false
    })
}

const open = (formData: typeof form) => {
  form.id = formData.id
  form.cusNo = formData.cusNo
  form.userName = formData.userName
  dialogVisible.value = true
}

defineExpose({
  open,
})
</script>
<style scoped>
.form-container {
  padding: 0 80px;
}
</style>
