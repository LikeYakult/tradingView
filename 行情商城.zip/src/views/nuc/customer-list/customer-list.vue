<template>
  <!-- 客户列表 -->
  <div class="page-container">
    <baseFilter :loading="loading"
      :config="filterConfig"
      @on-search="searchDataList"
      @on-reset="searchDataList"
    ></baseFilter>
    <div class="operate-buttons">
      <el-popconfirm
        :width="280"
        cancel-button-type=""
        :title="$t('sure_to_batch_enable')"
        hide-icon
        :visible="batchVisible"
        @confirm="batchChangeStatus('action')"
        @cancel="
          () => {
            batchVisible = false
          }
        "
      >
        <template #reference>
          <el-button plain
            v-permission="'nuc:internet:enableBatch'"
            type="info"
            @click="showBatchOperationConfirmPopup('startUp')"
            >{{ $t('batch_enabled') }}</el-button
          >
        </template>
      </el-popconfirm>
      <el-popconfirm
        :width="280"
        cancel-button-type=""
        :title="$t('sure_to_batch_disable')"
        hide-icon
        :visible="forbidVisible"
        @confirm="batchChangeStatus('disable')"
        @cancel="
          () => {
            forbidVisible = false
          }
        "
      >
        <template #reference>
          <el-button plain
            v-permission="'nuc:internet:disableBatch'"
            type="info"
            @click="showBatchOperationConfirmPopup('forbid')"
            >{{ $t('batch_disabled') }}</el-button
          >
        </template>
      </el-popconfirm>
      <el-button plain
        v-permission="'nuc:internet:export'"
        :loading="exportLoading"
        type="info"
        @click="toExport"
        >{{ $t('export') }}</el-button
      >
    </div>
    <dz-table :config="tableConfig" :pagination="pagination" :is-loading="loading">
      <template #status>
        <el-table-column :label="$t('status')" width="100" align="center">
          <template #default="scope">
            <span>{{ scope.row.statusName }}</span>
          </template>
        </el-table-column>
      </template>
      <template #operate>
        <el-table-column :label="$t('operate')" width="100" align="center" fixed="right">
          <template #default="scope">
            <el-popconfirm
              :width="280"
              cancel-button-type=""
              v-if="scope.row.status === '1'"
              hide-icon
              :title="$t('determine_disabled')"
              @confirm="toOperate(scope.row.id, 'disable')"
            >
              <template #reference>
                <span v-permission="'nuc:internet:disable'" class="text-primary mr10">{{
                  $t('disabled')
                }}</span>
              </template>
            </el-popconfirm>
            <el-popconfirm
              :width="280"
              cancel-button-type=""
              v-if="scope.row.status === '0'"
              hide-icon
              :title="$t('determine_enabled')"
              @confirm="toOperate(scope.row.id, 'action')"
            >
              <template #reference>
                <span v-permission="'nuc:internet:enable'" class="text-primary mr10">{{
                  $t('enable')
                }}</span>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </template>
      <template #tradeAccount>
        <el-table-column :label="$t('trading_name')" width="100" align="center">
          <template #default="scope">
            <div>
              <el-button
                v-permission="'nuc:internet:bind'"
                link
                type="primary"
                @click="openBindingDialog(scope.row)"
                >绑定</el-button
              >
              <div>
                {{ scope.row.tradeAccount }}
              </div>
            </div>
          </template>
        </el-table-column>
      </template>
    </dz-table>
  </div>
  <BindingDialog ref="bindingDialogRef" @bind-success="searchDataList" />
</template>
<script lang="ts" setup>
import { onBeforeMount, reactive, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage } from 'element-plus'

import baseFilter from '@/components/base-filter/base-filter'
import dzTable from '@/components/dz-table/dz-table'
import { timeDiff } from '@/utils/common'

import useTableData from '@/hooks/useTableData'
import ConfigType from '@/types/requestType'
import { cloneDeep } from 'lodash'
import {
  batchChangeInternetAccountStatus,
  changeInternetAccountStatus,
} from '@/api-v2/nuc/mutation'
import { exportCustomerList, fetchDicts } from '@/api-v2/nuc/query'
import { extractDict } from '@/utils/options-dictionary'
import BindingDialog from './binding-dialog.vue'

const { t } = useI18n()

// #region options
const registerFromOptions = ref([])
const accountTypeOptions = ref([])
const statusOptions = ref([])
const isDeactivateOptions = ref([])

function initDicts() {
  fetchDicts(['registerFrom', 'client_type', 'status', 'is_deactivate']).then((res) => {
    extractDict(res?.result?.registerFrom, registerFromOptions)
    extractDict(res?.result?.client_type, accountTypeOptions)
    extractDict(res?.result?.status, statusOptions)
    extractDict(res?.result?.is_deactivate, isDeactivateOptions)
  })
}
// #endregion

onBeforeMount(() => {
  initDicts()
})

const bindingDialogRef = ref<any>()

const ordering = reactive<Record<string, any>>({
  asc: true,
  column: '',
})

const reqConfig = reactive<ConfigType>({
  url: '/nuc/internet/list',
  method: 'POST',
  data: {},
})

const { tableData, pagination, loading } = useTableData(reqConfig)
console.log('tableData, pagination, loading====>', tableData, pagination, loading)

// 选中行数
let tableSelectionRows: any[] = []
const tableSelectionChange = (selection: []) => {
  tableSelectionRows = selection
}

const tableConfig = reactive({
  tableProps: {
    data: tableData,
    height: '580',
  },
  tableEvent: {
    onSelectionChange: tableSelectionChange,
    onSortChange: (column: Record<string, any>) => {
      const { order, prop } = column
      ordering.column = prop
      if (!order) {
        ordering.column = undefined
        ordering.asc = undefined
      } else {
        ordering.asc = order === 'ascending' ? true : false
      }
      searchDataList()
    },
  },
  customColumns: [
    { type: 'selection', align: 'center' },
    { label: t('registration_time'), prop: 'createTime', width: '200', sortable: 'custom' },
    { label: t('internet_account'), prop: 'cusNo', minWidth: '120' },
    { label: t('mobile_number'), prop: 'mobile', minWidth: '120' },
    { slot: 'tradeAccount' },
    { label: t('email'), prop: 'email', minWidth: '120' },
    { label: t('registered_source'), prop: 'registerFrom', minWidth: '100' },
    { slot: 'status' },
    { label: t('is_deactivate'), prop: 'isDeactivate', minWidth: '100' },
    { slot: 'operate' },
  ],
})

/* 过滤表单-start */
const filterConfig = reactive({
  formProps: {
    model: {},
  },
  formItems: [
    {
      prop: 'registerTime',
      label: t('registration_time'),
      innerEl: {
        elType: 'datePicke',
        props: { type: 'daterange', 'value-format': 'YYYY-MM-DD' },
      },
    },
    {
      prop: 'accountType',
      innerEl: {
        elType: 'select',
        props: { placeholder: t('account_type') },
        options: accountTypeOptions,
      },
    },
    {
      prop: 'registerFrom',
      innerEl: {
        elType: 'select',
        props: { placeholder: t('registered_source') },
        options: registerFromOptions,
      },
    },
    {
      prop: 'keyword',
      innerEl: {
        elType: 'input',
        props: {
          placeholder: t('please_input_customer_list_keyword'),
          style: { minWidth: '280px' },
        },
      },
    },
    {
      prop: 'status',
      innerEl: {
        elType: 'select',
        props: { placeholder: t('state') },
        options: statusOptions,
      },
    },
    {
      prop: 'isDeactivate',
      innerEl: {
        elType: 'select',
        props: { placeholder: t('is_deactivate') },
        options: isDeactivateOptions,
      },
    },
  ],
})

function getSearchParams() {
  const params: Record<string, any> = cloneDeep(filterConfig.formProps.model)
  if (params.registerTime) {
    const [startDate, endDate] = params.registerTime
    params.startDate = startDate
    params.endDate = endDate

    delete params.registerTime
  }
  if (ordering.column) {
    params.orders = [ordering]
  }

  return params
}

const searchDataList = () => {
  reqConfig.data = getSearchParams()
}

const exportLoading = ref(false)
const toExport = () => {
  const params = getSearchParams()
  // const params = {
  //   ...getSearchParams(),
  //   pageSize: pagination.paginationProps.pageSize,
  //   pageNum: pagination.paginationProps.currentPage,
  // } as any

  // if (ordering.column) {
  //   Object.assign(params, {
  //     orders: [ordering],
  //   })
  // }

  if (!params.startDate && !params.endDate) {
    ElMessage.warning(t('export_message'))
    return
  }

  if (timeDiff(params.startDate, params.endDate)) {
    ElMessage.warning(t('export_month_message'))
    return
  }

  if (params?.registerTime) {
    delete params?.registerTime
  }

  exportLoading.value = true
  exportCustomerList(params).finally(() => {
    exportLoading.value = false
  })
}

const batchVisible = ref<boolean>(false)

// action:启动;disable禁用
const batchChangeStatus = async (type: 'action' | 'disable') => {
  if (tableSelectionRows?.length === 0) {
    ElMessage.error(
      type === 'action' ? t('select_batch_enable_data') : t('select_batch_disable_data')
    )
    return
  }
  const ids = tableSelectionRows.map((item) => item.id)
  const res = await batchChangeInternetAccountStatus({ ids, status: type === 'action' ? '1' : '0' })

  if (res.code === 0) {
    ElMessage.success(type === 'action' ? t('enable_success') : t('disable_success'))
    type === 'action' ? (batchVisible.value = false) : (forbidVisible.value = false)
    searchDataList()
  }
}

// startUp:启用 forbid:禁用
const showBatchOperationConfirmPopup = (apiStr: string) => {
  if (tableSelectionRows.length === 0) {
    apiStr === 'startUp' ? (batchVisible.value = false) : null
    apiStr === 'forbid' ? (forbidVisible.value = false) : null
    ElMessage.warning(t(apiStr === 'startUp' ? 'batch_audit_prompt' : 'batch_forbid_prompt'))
    return
  }
  apiStr === 'startUp' ? (batchVisible.value = true) : null
  apiStr === 'forbid' ? (forbidVisible.value = true) : null
}
// 启用:action:禁用:disable

const toOperate = async (id: number, type: 'action' | 'disable') => {
  const msg = type === 'action' ? t('enable_success') : t('disable_success')

  const res = await changeInternetAccountStatus({ id, status: type === 'action' ? '1' : '0' })
  if (res.code === 0) {
    ElMessage.success(msg)
    searchDataList()
  }
}

const forbidVisible = ref<boolean>(false)

const openBindingDialog = (row: Record<string, any>) => {
  bindingDialogRef.value.open(row)
}
</script>
<style lang="scss" scoped>
.mr10 {
  margin-right: 10px;
}

.unbind-box {
  background: #f5f6f8;
  margin-bottom: 10px;

  .left,
  .right {
    display: inline-block;
    vertical-align: top;
    text-align: right;
    width: 348px;
    padding: 10px 20px 20px 20px;

    .detail-item {
      display: flex;
      justify-content: space-between;
      margin-bottom: 10px;

      .label {
        display: inline-block;
        min-width: 56px;
      }
    }
  }
}

:deep(.el-input-group__prepend) {
  width: 72px;
}

:deep(.el-input__inner) {
  padding: 0;
}

:deep(.el-input__suffix) {
  width: 14px;
}

:deep(.el-pagination > .el-input__suffix) {
  right: 10px;
}
</style>
