<script setup lang="ts">
import { reactive, onBeforeMount, ref } from 'vue'
import { useI18n } from 'vue-i18n'
// import { ElMessage } from 'element-plus'
import baseFilter from '@/components/base-filter/base-filter'
import dzTable from '@/components/dz-table/dz-table'

// import { loginLogList, loginListExport } from '@/api/quotation/customer'
import { formToParams } from '@/utils'
// import { timeDiff } from '@/utils/common'
import { exportRiskList, fetchDicts, riskList } from '@/api-v2/nuc/query'
import { extractDict } from '@/utils/options-dictionary'
import { SelectOptions } from '@/types'

const { t } = useI18n()
// #region options
const riskLevelOptions = ref<SelectOptions>([])

function initDicts() {
  fetchDicts(['riskLevel']).then((res) => {
    extractDict(res?.result?.riskLevel, riskLevelOptions)
  })
}
// #endregion

onBeforeMount(() => {
  initDicts()
})

const isLoading = ref<boolean>(false)
const ordering = ref({
  asc: false,
  column: 'createTime',
})

// 表单配置
const formItems = [
  {
    prop: 'keyword',
    label: t('user_account_keyword'),
    innerEl: {
      elType: 'input',
      props: { placeholder: t('please_enter_user_account_phone') },
    },
  },
  {
    prop: 'desc',
    label: t('event_desc'),
    innerEl: {
      elType: 'input',
      props: { placeholder: t('event_desc_input_placeholder') },
    },
  },
  {
    prop: 'riskLevel',
    label: t('risk_level'),
    innerEl: {
      elType: 'select',
      options: riskLevelOptions,
    },
  },
  {
    prop: 'searchTime',
    label: t('event_time'),
    innerEl: { elType: 'datePicke', props: { type: 'daterange', 'value-format': 'YYYY-MM-DD' } },
  },
]

const tableConfig = reactive({
  tableProps: {
    data: [],
    height: '580',
  },
  tableEvent: {
    onSortChange: (column: Record<string, any>) => {
      const { order, prop } = column
      ordering.value.column = ''
      pagination.paginationProps.currentPage = 1

      if (order) {
        ordering.value = {
          asc: order === 'ascending',
          column: prop,
        }
      }
      return getData(filterConfig.formProps.model)
    },
  },
  customColumns: [
    { label: t('event_id'), prop: 'id', minWidth: '120' },
    { label: t('mobile_number'), prop: 'mobile', minWidth: '120' },
    { label: t('internet_account'), prop: 'cusNo', minWidth: '120' },
    { label: t('event_time'), prop: 'createTime', minWidth: '140', sortable: 'custom' },
    { slot: 'riskLevel' },
    { label: t('risk_type'), prop: 'riskType', minWidth: '120' },
    { label: t('event_desc'), prop: 'desc', minWidth: '200' },
    { label: t('login_ip'), prop: 'ip', minWidth: '100' },
    { label: t('login_geo_info'), prop: 'country', minWidth: '120' },
    { label: t('related_login_log_id'), prop: 'loginLogId', minWidth: '180' },
  ],
})

/** 表单数据 */
const filterConfig = reactive({
  formProps: {
    model: {
      keyword: '',
      channelType: '',
      country: '',
      searchTime: [],
    },
  },
  // eslint-disable-next-line no-use-before-define
  formItems,
})

const pagination: Record<string, any> = reactive({
  paginationProps: {
    currentPage: 1,
    pageSize: 20,
    total: 0,
  },
  paginationEvent: {
    onSizeChange: (v: number | string) => {
      pagination.paginationProps.pageSize = v
      getData(filterConfig.formProps.model)
    },
    onCurrentChange: (v: number | string) => {
      pagination.paginationProps.currentPage = v
      getData(filterConfig.formProps.model)
    },
  },
})

/**
 * 获取表格数据
 * @param data 传入数据
 */
function getData(data: Record<string, any> = {}) {
  isLoading.value = true
  const page: Record<string, any> = {}
  let beginTime, endTime
  page.pageNum = pagination.paginationProps.currentPage
  page.pageSize = pagination.paginationProps.pageSize
  if (data.searchTime) {
    ;[beginTime, endTime] = data.searchTime
  }

  const params = {
    ...formToParams({ ...page, ...data, beginTime, endTime }),
  } as any

  if (ordering.value.column) {
    Object.assign(params, {
      orders: [ordering.value],
    })
  }

  riskList(params)
    .then((res: Record<string, any>) => {
      tableConfig.tableProps.data = res.result.records
      pagination.paginationProps.currentPage = res.result.current
      pagination.paginationProps.pageSize = res.result.size
      pagination.paginationProps.total = res.result.total
      isLoading.value = false
    })
    .catch((err) => {
      console.log(err)
      isLoading.value = false
    })
}

/** 导出接口 */
const isExportLoading = ref(false)
function exportFunc() {
  const { searchTime = [] } = filterConfig.formProps.model
  // if (!searchTime || !searchTime.length) {
  //   ElMessage.warning(t('export_message'))
  //   return
  // }

  const [beginTime, endTime] = searchTime
  // if (timeDiff(beginTime, endTime)) {
  //   ElMessage.warning(t('export_month_message'))
  //   return
  // }

  const params = { ...filterConfig.formProps.model, beginTime, endTime }
  if (ordering.value.column) {
    Object.assign(params, {
      orders: [ordering.value],
    })
  }

  isExportLoading.value = true
  exportRiskList(params).finally(() => {
    isExportLoading.value = false
  })
}

function searchHandle(data: Record<string, any>) {
  const [beginTime, endTime] = data.searchTime
  getData({ beginTime, endTime, ...data })
}

function resetHandle() {
  getData()
}

onBeforeMount(() => {
  getData()
})

const riskLevelText = (num: string) => {
  return riskLevelOptions.value.find((item) => item.value === num)?.label
}
</script>

<template>
  <el-card>
    <base-filter :loading="isLoading" :config="filterConfig" @on-search="searchHandle" @on-reset="resetHandle" />
    <div class="operate-buttons">
      <el-button
        v-permission="'nuc:report:export'"
        type="primary"
        plain
        :loading="isExportLoading"
        @click="exportFunc"
        >{{ $t('export') }}</el-button
      >
    </div>
    <div class="table">
      <dz-table :config="tableConfig" :pagination="pagination" :is-table-loading="isLoading">
        <template #riskLevel>
          <el-table-column :label="$t('risk_level')" width="100" align="center">
            <template #default="scope">
              <span>{{ riskLevelText(scope.row.riskLevel) }}</span>
            </template>
          </el-table-column>
        </template>
      </dz-table>
    </div>
  </el-card>
</template>
