<template>
  <div class="dashboard-container">
  </div>
</template>

<script lang="ts">
import { defineComponent, computed } from 'vue'
import { useAppStore } from '@/store'
import { useRouter } from 'vue-router'

export default defineComponent({
  name: 'dashboard',
  setup() {
    const router = useRouter()
    const appStore = useAppStore()
    const menu = computed(() => appStore.menu)
    const dashboard = menu.value[0]
    if (dashboard) {
      if (Object.prototype.hasOwnProperty.call(dashboard, 'children')) {
        router.push(dashboard.children[0]?.path || dashboard?.path)
      } else {
        router.push(dashboard.path)
      }
    }

    return {}
  }
})
</script>

<style lang="scss" scoped>
.dashboard-container {
  .user-info {
    display: flex;
    align-items: center;
    padding-bottom: 20px;
    border-bottom: 2px solid #ccc;
    margin-bottom: 20px;
    .user-avator {
      width: 120px;
      height: 120px;
      border-radius: 50%;
    }
    .user-info-cont {
      padding-left: 50px;
      flex: 1;
      font-size: 14px;
      color: #999;
      .user-info-name {
        font-size: 30px;
        color: #222;
      }
    }
  }
  .user-info-list {
    font-size: 14px;
    color: #999;
    line-height: 25px;
    span {
      margin-left: 70px;
    }
  }
  .grid-content {
    display: flex;
    align-items: center;
    height: 100px;
    .grid-content-icon {
      font-size: 50px;
      width: 100px;
      height: 100px;
      line-height: 100px;
      text-align: center;
      color: #fff;
      &.user-icon {
        background-color: rgb(45, 140, 240);
      }
      &.bell-icon {
        background-color: rgb(242, 94, 67);
      }
      &.goods-icon {
        background-color: rgb(100, 213, 114);
      }
    }
    .grid-cont-right {
      flex: 1;
      text-align: center;
      font-size: 14px;
      color: #999;
      .grid-num {
        font-size: 30px;
        font-weight: bold;
        color: rgb(45, 140, 240);
      }
    }
  }
}
</style>
