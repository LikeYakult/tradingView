import { PUBLIC_PATH } from '@/constants/config'

const getUrlParams = (url: string) => {
  // 获取？后面第一个字符串的索引
  const index = url.indexOf('?') + 1
  // 取得url后面的字符串name=zs&age=18&b=2
  const params = url.substr(index)
  // 使用&切割字符串，返回一个数组
  const arr = params.split('&')
  // 定义一个空对象
  const o: { [name: string]: any } = {}
  // 数组中每一项的样子 key=value
  // eslint-disable-next-line no-plusplus
  for (let i = 0; i < arr.length; i++) {
    // 临时数组
    const tmpArr = arr[i].split('=')
    const key = tmpArr[0]
    const value = tmpArr[1]
    o[key] = value
  }
  return o
}

const getDmsPrefix = () => {
  const { pathname } = window.location
  if (pathname.startsWith('/dms') || PUBLIC_PATH.startsWith('/dms')) {
    return '/dms'
  }
  return ''
}

// 确保为浏览器地址栏提供带完整前缀（如 /dms）的绝对路径
const getFullPath = (path: string) => {
  if (!path) return ''
  const prefix = getDmsPrefix()
  if (!prefix) return path
  if (path === prefix || path.startsWith(`${prefix}/`)) {
    return path
  }
  const cleanPath = path.startsWith('/') ? path : `/${path}`
  return `${prefix}${cleanPath}`
}

// 确保去除前缀，供 vue-router（已有 base 前缀）内部使用
const getRouterPath = (path: string) => {
  if (!path) return ''
  const prefix = getDmsPrefix()
  if (prefix && (path === prefix || path.startsWith(`${prefix}/`))) {
    const stripped = path.slice(prefix.length)
    return stripped.startsWith('/') ? stripped : `/${stripped}`
  }
  return path.startsWith('/') ? path : `/${path}`
}

// 获取静态资源完整路径（如 /dms/public-images/logo.svg）
const getPublicAssetUrl = (path: string) => {
  const cleanPath = path.startsWith('/') ? path.slice(1) : path
  const base = PUBLIC_PATH.endsWith('/') ? PUBLIC_PATH : `${PUBLIC_PATH}/`
  return `${base}${cleanPath}`
}

export default {
  getUrlParams,
  getDmsPrefix,
  getFullPath,
  getRouterPath,
  getPublicAssetUrl
}
