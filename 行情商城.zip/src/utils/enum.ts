// 订购人
export const subTypeSelect = [
  {
    label: '系统',
    value: '0',
  },
  {
    label: '客户',
    value: '1',
  },
  {
    label: '管理员',
    value: '2',
  },
]

// 生效状态
export const enableStatusSelect = [
  {
    label: '已生效',
    value: '1',
  },
  {
    label: '待生效',
    value: '2',
  },
  {
    label: '已失效',
    value: '5',
  },
  {
    label: '无效',
    value: '3',
  },
  {
    label: '空',
    value: '4',
  },
]

// 审核状态
export const statusSelect = [
  {
    label: '驳回',
    value: 'REJECT',
  },
  {
    label: '待审核',
    value: 'REVIEW_ING',
  },
  {
    label: '审核通过',
    value: 'SUCCESS',
  },
]
// 是否赠送
export const isGiveSelect = [
  {
    label: '是',
    value: 'true',
  },
  {
    label: '否',
    value: 'false',
  },
]
