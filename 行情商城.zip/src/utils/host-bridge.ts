/**
 * 与 qiankun 主项目通信的桥接层。
 *
 * 嵌入新主项目时，登录态由主项目持有：
 * - 主项目通过 globalState 下发 token，子应用换取自己的中台 token
 * - 子应用需要登录 / 登出时反向通知主项目
 */

type SetGlobalState = (state: Record<string, any>) => void

let hostSetGlobalState: SetGlobalState | undefined

/** 由 main.ts 在 mount 时注入 qiankun 提供的 setGlobalState */
export const bindHostGlobalState = (setter?: SetGlobalState) => {
  hostSetGlobalState = setter
}

/** 向主项目回传状态（未嵌入时静默忽略） */
export const notifyHost = (state: Record<string, any>) => {
  const setter =
    hostSetGlobalState || (window as any).setQianKunGlobalState || undefined

  if (typeof setter === 'function') {
    setter(state)
  }
}

/** 从主项目下发的 globalState 中解析宿主 token（兼容常见字段名） */
export const pickHostToken = (state?: Record<string, any>): string => {
  if (!state) return ''

  const token = state.token || state.ssoToken || state.accessToken || state.access_token

  return typeof token === 'string' ? token : ''
}
