import { Ref } from 'vue'

type Extractor = (items: [any, string][]) => any

const defaultExtractor: Extractor = (items) =>
  items.map((item) => ({
    value: item[0],
    label: item[1],
  }))

export function extractDict(
  source: [any, string][] | undefined | null,
  targetRef: Ref<any>,
  extractor: Extractor = defaultExtractor
) {
  if (!source) {
    return
  }

  targetRef.value = extractor(source)
}
