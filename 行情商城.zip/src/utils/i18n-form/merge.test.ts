import { describe, expect, test } from 'vitest'
import { autoPickValuesIfNotPresent, pickMissValuesFromEachOther } from './merge'

describe('autoPickValuesIfNotPresent, 合并对象', () => {
  test('当目标对象的值为空时，自动从源对象中取值', () => {
    const zhCN = {
      addressUrl: 'https://www.baidu.com',
      content: '中文',
      lang: 'zh-CN',
      title: '测试标题',
      newStocks: [],
    }
    const zhHK = {
      addressUrl: '',
      content: '繁体',
      lang: 'zh-HK',
      title: '',
      newStocks: [],
    }

    expect(autoPickValuesIfNotPresent(zhCN, zhHK)).toEqual({
      addressUrl: 'https://www.baidu.com',
      content: '繁体',
      lang: 'zh-HK',
      title: '测试标题',
      newStocks: [],
    })

    expect(autoPickValuesIfNotPresent(zhCN, {})).toEqual(zhCN)
  })

  test('当目标对象都有值时，不应该覆盖值', () => {
    const zhCN = {
      addressUrl: 'https://www.baidu.com',
      content: '中文',
      lang: 'zh-CN',
      title: '测试标题',
      newStocks: [],
    }
    const zhHK = {
      addressUrl: 'https://www.baidu.com',
      content: '中文',
      lang: 'zh-CN',
      title: '测试标题',
      newStocks: [],
    }

    expect(autoPickValuesIfNotPresent(zhCN, zhHK)).toEqual(zhHK)
    expect(autoPickValuesIfNotPresent(zhHK, zhCN)).toEqual(zhCN)
  })

  test('数组对应属性应该一一对应合并', () => {
    const zhCN = {
      addressUrl: 'https://www.baidu.com',
      content: '中文',
      lang: 'zh-CN',
      title: '测试标题',
      newStocks: [
        {
          name: '新股中文',
        },
      ],
    }
    const zhHK = {
      addressUrl: 'https://www.baidu.com',
      content: '中文',
      lang: 'zh-CN',
      title: '测试标题',
      newStocks: [
        {
          name: '',
        },
      ],
    }

    expect(autoPickValuesIfNotPresent(zhCN, zhHK)).toEqual({
      addressUrl: 'https://www.baidu.com',
      content: '中文',
      lang: 'zh-CN',
      title: '测试标题',
      newStocks: [
        {
          name: '新股中文',
        },
      ],
    })
  })

  test('数组对应属性已有值不应该覆盖', () => {
    const zhCN = {
      addressUrl: 'https://www.baidu.com',
      content: '内容',
      lang: 'zh-CN',
      title: '测试标题',
      newStocks: [
        {
          name: '新股1简体',
        },
        {
          name: '新股2简体',
        },
      ],
    }
    const zhHK = {
      addressUrl: 'https://www.google.com',
      content: '内容',
      lang: 'zh-HK',
      title: '测试标题',
      newStocks: [
        {
          name: '',
        },
        {
          name: '新股2繁体',
        },
      ],
    }

    expect(autoPickValuesIfNotPresent(zhCN, zhHK)).toEqual({
      addressUrl: 'https://www.google.com',
      content: '内容',
      lang: 'zh-HK',
      title: '测试标题',
      newStocks: [
        {
          name: '新股1简体',
        },
        {
          name: '新股2繁体',
        },
      ],
    })
  })
})

describe('pickMissValuesFromEachOther, 互相合并连续数组对象', () => {
  test('当目标对象的值为空时，自动从源对象中取值', () => {
    const zhCN = {
      addressUrl: 'https://www.baidu.com',
      content: '内容',
      lang: 'zh-CN',
      title: '测试标题',
      newStocks: [
        {
          name: '新股1简体',
        },
        {
          name: '新股2简体',
        },
      ],
    }
    const zhHK = {
      addressUrl: 'https://www.google.com',
      content: '繁体内容',
      lang: 'zh-HK',
      title: '',
      newStocks: [
        {
          name: '',
        },
        {
          name: '新股2繁体',
        },
      ],
    }

    expect(pickMissValuesFromEachOther([zhCN, zhHK])).toEqual([
      zhCN,
      {
        addressUrl: 'https://www.google.com',
        content: '繁体内容',
        lang: 'zh-HK',
        title: '测试标题',
        newStocks: [
          {
            name: '新股1简体',
          },
          {
            name: '新股2繁体',
          },
        ],
      },
    ])
  })
})
