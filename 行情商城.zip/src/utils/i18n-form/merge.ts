import mergeWith from 'lodash/mergeWith'
import isArray from 'lodash/isArray'
import isString from 'lodash/isString'
import cloneDeep from 'lodash/cloneDeep'

export function autoPickValuesIfNotPresent(
  defaults: Record<string, any>,
  mayEmptyValues: Record<string, any>
) {
  return mergeWith(cloneDeep(defaults), mayEmptyValues, (objValue, srcValue) => {
    const isArrayData = isArray(srcValue)
    // 空数组或空字符串应该取默认值
    if ((isArrayData || isString(srcValue)) && srcValue.length === 0) {
      return objValue
    }
  })
}

export function pickMissValuesFromEachOther(arr: Record<string, any>[]) {
  const copyArr = [...arr]
  copyArr.forEach((item, index) => {
    const temp = [...copyArr]
    let target = temp.splice(index, 1)[0]

    temp.forEach((source) => {
      target = autoPickValuesIfNotPresent(source, target)
    })
    copyArr[index] = target
  })

  return copyArr
}
