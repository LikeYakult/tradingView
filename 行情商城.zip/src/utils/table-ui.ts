import { cloneVNode, Fragment, isVNode, VNode } from 'vue'

/** Keep action slots visible while retaining page-specific widths and explicit fixed settings. */
export function tableSlot(nodes: VNode[] = [], name: string): VNode[] {
  if (!/^(operate|operation|operations|action|actions|marketAuthorization)$/i.test(name))
    return nodes
  return nodes.map((node) => {
    if (!isVNode(node)) return node
    if (node.type === Fragment && Array.isArray(node.children)) {
      const copy = cloneVNode(node)
      copy.children = tableSlot(node.children as VNode[], name)
      return copy
    }
    return cloneVNode(node, {
      fixed: node.props?.fixed ?? 'right',
      width: node.props?.width ?? node.props?.minWidth ?? node.props?.['min-width'] ?? 180,
      className: [node.props?.className ?? node.props?.['class-name'], 'table-operation-column']
        .filter(Boolean)
        .join(' '),
    })
  })
}
