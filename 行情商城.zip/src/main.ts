import '@/constants/config'
import { PUBLIC_PATH } from '@/constants/config'

if ((window as any).__POWERED_BY_QIANKUN__) {
  // eslint-disable-next-line no-undef
  __webpack_public_path__ =
    (window as any).__INJECTED_PUBLIC_PATH_BY_QIANKUN__ || PUBLIC_PATH
}

import { createApp } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'
import { appStore, pinia } from './store/index'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import App from './App.vue'
import routes from './router/constant-route'
import registerApp from './global'
import { getDefaultModulePath } from '@/utils/common'
import locationUtil from '@/utils/location'
import { bindHostGlobalState, notifyHost, pickHostToken } from '@/utils/host-bridge'
import { LANGUAGE_SERVER_MAP } from '@/constants/language'
import 'normalize.css'
import '@/assets/css/index.scss'

let router: any = null
let instance: any = null
let history: any = null
const getRouterBase = (routerBase?: string) => {
  if (window.__POWERED_BY_QIANKUN__) {
    return routerBase || '/'
  }
  return PUBLIC_PATH
}

/* 已同步过的主项目 token，避免重复处理 */
let appliedHostToken = ''

/**
 * 采用主项目下发的 token。
 * 主项目与本系统共用同一套中台账号体系（同一个 /uc 接口），token 可直接复用；
 * 切换账号后需清掉菜单/权限/动态路由，并重新走一次导航让守卫重新拉取。
 */
function applyHostToken(hostToken: string) {
  if (!hostToken || hostToken === appliedHostToken) return

  appliedHostToken = hostToken

  const store = appStore()
  store.setToken(hostToken)
  // 切换账号后菜单/权限/动态路由需重新拉取
  store.resetDynamicRoute()

  // 首次挂载时 router 还没创建，交给 render 后的首次导航处理
  if (!router) return

  // force: 当前已在 '/' 时也重新导航，让守卫重新拉模块并落到默认页
  router.replace({ path: '/', force: true }).catch(() => {
    // 导航被守卫中断属于正常情况，忽略即可
  })
}

/**
 * 订阅主项目下发的登录态。
 * - 主项目通过 props.getCurrentGlobalState 提供当前 token / 语言
 * - 登录、登出、切语言等变化通过 qiankun 的 globalState 推送
 */
function setupHostAuth(props: any) {
  const { onGlobalStateChange, getCurrentGlobalState, setGlobalState } = props || {}

  bindHostGlobalState(setGlobalState)

  const applyHostState = (state?: Record<string, any>) => {
    // 宿主可能下发 zh-CN 这类服务端语言码，需转成本地 key（cn/hk/us）
    if (state?.language) {
      appStore().setLanguage(LANGUAGE_SERVER_MAP[state.language] || state.language)
    }
    if (state?.languageList) appStore().setLanguageList(state.languageList)
    applyHostToken(pickHostToken(state))
  }

  // 先取一次当前状态：props 里的 getCurrentGlobalState 才是 token 的权威来源
  if (typeof getCurrentGlobalState === 'function') {
    applyHostState(getCurrentGlobalState())
  }

  if (typeof onGlobalStateChange === 'function') {
    // 之后跟随主项目的 globalState 变化（登录 / 登出 / 切语言）
    onGlobalStateChange((state: Record<string, any>) => applyHostState(state), true)
  }
}

function render(props = {}) {
  const { container, routerBase } = props as any

  history = createWebHistory(getRouterBase(routerBase))

  router = createRouter({
    history,
    routes,
  })

  // 设置白名单, 未登录可访问，前提条件是路由在constant-route.ts配置过，不适合动态挂载路由
  const whiteList = ['/login', '/whitePage']
  router.beforeEach(
    async (to: Record<string, any>, from: Record<string, any>, next: (...args: any[]) => any) => {
      if (appStore().token) {
        if (to.path === '/login') {
          const redirect = to.query.redirect as string
          if (redirect) {
            return next(redirect)
          }
          return next('/')
        }

        if (appStore().hadDynamicRoute) {
          appStore().setLastModuleRoutePath({
            moduleCode: appStore().currentModule.code,
            routePath: to.path,
          })
          return next()
        }

        if (!appStore().hadDynamicRoute) {
          await appStore().initMultiModuleList({ router, shouldPush: true })
          appStore().setLastModuleRoutePath({
            moduleCode: appStore().currentModule.code,
            routePath: to.path,
          })

          // 访问根路径时，重定向到当前模块默认路由；深链则继续导航到目标路由
          if (to.path === '/') {
            const defaultPath = getDefaultModulePath(appStore().currentModule)
            if (defaultPath) {
              return next(locationUtil.getRouterPath(defaultPath))
            }
          }
          return next({ ...to, replace: true })
        }

        return next()
      }

      // 嵌入主项目时不渲染自己的登录页，交给主项目处理登录
      if (window.__POWERED_BY_QIANKUN__) {
        notifyHost({ jumpLogin: true })
        return next(false)
      }

      if (whiteList.includes(to.path)) {
        return next()
      }

      return next(`/login?redirect=${to.path}`)
    }
  )

  instance = createApp(App)
  instance.use(router)
  instance.use(pinia).use(ElementPlus)
  registerApp(instance)
  instance.mount(container ? container.querySelector('#app') : document.getElementById('app'))

  appStore().setIsByQiankun(window.__POWERED_BY_QIANKUN__)
  if (window.__POWERED_BY_QIANKUN__) {
    console.log('我正在作为子应用运行')
  }
}

if (!window.__POWERED_BY_QIANKUN__) {
  render({})
}

export async function mount(props: any) {
  console.log('mount ===========》 props', props)

  setupHostAuth(props)
  render(props)
}
export async function bootstrap() {
  console.log('bootstrap')
}
export async function unmount() {
  console.log('unmount')
  instance.unmount()
  instance._container.innerHTML = ''
  history.destroy() // 不卸载  router 会导致其他应用路由失败
  router = null
  instance = null
  appliedHostToken = ''
}
