import { createPinia, defineStore } from 'pinia'
import {
  login as loginApi,
  getMenuBtnList as getMenuBtnListApi,
  getMultiModuleList,
} from '@/api-v2/authority/authority'
import { Imenu } from '@/project'
import { generateRoute } from '@/utils/authority'
import { createInternalPath } from '@/micro-app'
import { LANGUAGE_LOCAL_DICT } from '@/constants/language'

interface rootState {
  language: string
  languageList: any
  isCollapse: boolean
  token: string
  menu: Imenu[]
  permissions: Record<string, boolean>
  hadDynamicRoute: boolean
  currentModule: { [key: string]: any }
  multiModuleList: any[]
  currentModulePath: string
  accountInfo: Record<string, any>
  isByQiankun: boolean
  moduleLoading: boolean
  lastModuleRoutePath: Record<string, string>
}
type stateType = rootState

const defaultState: stateType = {
  language: localStorage.getItem('lang') || LANGUAGE_LOCAL_DICT.CN,
  languageList: localStorage.getItem('languageList') || [
    ['zh-CN', '简体'],
    ['zh-TW', '繁体'],
    ['en-US', 'English'],
  ],
  isCollapse: false,
  token: localStorage.getItem('token') || '',
  menu:
    (localStorage.getItem('menu') !== 'undefined' &&
      JSON.parse(localStorage.getItem('menu') as string)) ||
    [],
  permissions:
    (localStorage.getItem('permissions') !== 'undefined' &&
      JSON.parse(localStorage.getItem('permissions') as string)) ||
    {},
  hadDynamicRoute: false,
  currentModule:
    (localStorage.getItem('currentModule') !== 'undefined' &&
      JSON.parse(localStorage.getItem('currentModule') as string)) ||
    {},
  multiModuleList:
    (localStorage.getItem('multiModuleList') !== 'undefined' &&
      JSON.parse(localStorage.getItem('multiModuleList') as string)) ||
    [],
  currentModulePath: localStorage.getItem('currentModulePath') || '',
  accountInfo:
    (localStorage.getItem('accountInfo') !== 'undefined' &&
      JSON.parse(localStorage.getItem('accountInfo') as string)) ||
    {},
  isByQiankun: false,
  moduleLoading: false,
  lastModuleRoutePath: {},
}

// 单体应用：汇总所有模块的权限码（各模块 permission 独立下发）
const collectPermissions = (multiModuleList: any[] = []): string[] => {
  const codes = new Set<string>()
  multiModuleList.forEach((md: any) => {
    ;(md?.permission || []).forEach((code: string) => {
      if (code) codes.add(code)
    })
  })
  return Array.from(codes)
}

export const pinia = createPinia()

export const useAppStore = defineStore('app', {
  state: (): stateType => ({ ...defaultState }),
  getters: {
    simpleModulesList(state): { code: string; name: string }[] {
      return state.multiModuleList.map((item: { [key: string]: any }) => ({
        code: item.code,
        name: item.name,
      }))
    },
  },
  actions: {
    setLanguage(data: string) {
      this.language = data
      localStorage.setItem('lang', data)
    },
    setLanguageList(data: any) {
      this.languageList = data
    },
    setIsCollapse(data: boolean) {
      this.isCollapse = data
    },
    setToken(data: string) {
      this.token = data
      localStorage.setItem('token', data)
    },
    setMenu(data: Imenu[]) {
      this.menu = data
      localStorage.setItem('menu', JSON.stringify(data))
    },
    setPermissions(data: string[]) {
      const permissionMap = data.reduce((pre: Record<string, boolean>, cur: string) => {
        pre[cur] = true
        return pre
      }, {})

      this.permissions = permissionMap
      localStorage.setItem('permissions', JSON.stringify(permissionMap))
    },
    setHadDynamicRoute(data: boolean) {
      this.hadDynamicRoute = data
    },
    setCurrentModule(data: object) {
      this.currentModule = data
      localStorage.setItem('currentModule', JSON.stringify(data))
    },
    setIsByQiankun(data: boolean) {
      this.isByQiankun = data
    },
    setModuleLoading(data: boolean) {
      this.moduleLoading = data
    },
    setMultiModuleList(data: any[]) {
      this.multiModuleList = data
      localStorage.setItem('multiModuleList', JSON.stringify(data))
    },
    setCurrentModulePath(data: string) {
      this.currentModulePath = data
      localStorage.setItem('currentModulePath', data)
    },
    setLastModuleRoutePath(data: Record<string, string>) {
      this.lastModuleRoutePath[data.moduleCode] = data.routePath
    },
    setAccountInfo(data: Record<string, any>) {
      this.accountInfo = data
      localStorage.setItem('accountInfo', JSON.stringify(data))
    },

    login(data: any) {
      return loginApi(data).then((res) => {
        this.setToken(res.result.token)
      })
    },
    /** 登录成功后重置动态路由，守卫会重新拉菜单/权限 */
    resetDynamicRoute() {
      this.setHadDynamicRoute(false)
      this.setMenu([])
      this.setPermissions([])
      this.setMultiModuleList([])
      this.setCurrentModule({})
      this.setCurrentModulePath('')
    },
    logout() {
      // 此处可能调用登出接口
      localStorage.clear()
      this.setToken('')
      this.setMenu([])
      this.setPermissions([])
      this.setMultiModuleList([])
      this.setCurrentModule({})
      this.setCurrentModulePath('')
    },
    initMultiModuleList(payload: { router: any; shouldPush?: boolean }) {
      const { router: _router } = payload
      return getMultiModuleList().then((res) => {
        const multiModuleList = res.result
          .sort((a: any, b: any) => {
            if (a.isExternal && !b.isExternal) {
              return 1
            }
            if (!a.isExternal && b.isExternal) {
              return -1
            }
            return 0
          })
          .map((md: any) => {
            const menu = createInternalPath(md.menu, md.code)
            const dynamicRoute = generateRoute(menu)
            dynamicRoute?.forEach((route) => _router.addRoute('layout', route))

            return {
              ...md,
              menu
            }
          })

        this.setHadDynamicRoute(true)

        // 优先使用本次拉取到的模块（避免旧缓存 currentModule 里菜单结构过期，导致默认路径解析错误）
        const module =
          multiModuleList.find((md: any) => md.code === this.currentModule.code) ||
          multiModuleList[0]

        this.setMultiModuleList(multiModuleList)

        const { menu = [] } = module
        this.setMenu(menu)
        // 单体应用内所有模块页面同时可见，权限取全部模块并集：
        // 否则非当前模块（如系统管理）的按钮会被 v-permission 移除
        this.setPermissions(collectPermissions(multiModuleList))
        this.setCurrentModule(module)

        return Promise.resolve(module)
      })
    },
    getMenuBtnList(data?: any) {
      return getMenuBtnListApi(data).then((res) => {
        const { menu = [], permission = [] } = res.result
        this.setMenu(menu)
        this.setPermissions(permission)
      })
    },
  },
})

/**
 * 在组件 / setup 之外（api、utils、自定义指令等）获取 store 实例。
 * 组件内请直接使用 useAppStore()。
 */
export const appStore = () => useAppStore(pinia)

/* —— 账户管理中心（原 vuex namespaced module）—— */
export const useAccountManagementCenterStore = defineStore('accountManagementCenter', {
  state: () => ({
    customerList: [] as any[],
  }),
  actions: {
    setCustomerList(data: any[]) {
      this.customerList = data
    },
  },
})
