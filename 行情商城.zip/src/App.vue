<template>
  <el-config-provider :locale="locale">
    <router-view />
  </el-config-provider>
</template>

<script lang="ts">
import { defineComponent, computed, watch } from 'vue'
import { useAppStore } from '@/store'

import zhCn from 'element-plus/es/locale/lang/zh-cn'
import zhHk from 'element-plus/es/locale/lang/zh-tw'
import enUS from 'element-plus/es/locale/lang/en'

import { LANGUAGE_LOCAL_DICT } from '@/constants/language'
import { i18n } from '@/global/register-i18n'
import '@/assets/css/index.scss'

export default defineComponent({
  name: 'App',
  setup() {
    const appStore = useAppStore()

    const locale = computed(() => {
      const langMap: Record<string, any> = {
        [LANGUAGE_LOCAL_DICT.CN]: zhCn,
        [LANGUAGE_LOCAL_DICT.TW]: zhHk,
        [LANGUAGE_LOCAL_DICT.US]: enUS
      }

      return langMap[appStore.language] || zhCn
    })

    // 语言变更时同步 vue-i18n（宿主下发 / 本地切换都走这里）
    watch(
      () => appStore.language,
      (lang) => {
        const nextLang = lang || LANGUAGE_LOCAL_DICT.CN
        if (i18n.global.locale.value !== nextLang) {
          i18n.global.locale.value = nextLang
        }
      },
      { immediate: true }
    )

    return {
      locale
    }
  }
})
</script>
