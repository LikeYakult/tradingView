export interface SelectOption<T = string> {
  value: T
  label: string
}

export type SelectOptions<T = string> = SelectOption<T>[]
