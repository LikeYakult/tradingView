import { RouteRecordRaw } from 'vue-router'

import CustomerList from '@/views/nuc/customer-list/customer-list.vue'
import LoginLog from '@/views/nuc/login-log/login-log.vue'
import TradeLoginLog from '@/views/nuc/trade-login-log/trade-login-log.vue'
import RiskList from '@/views/nuc/risk-list/risk-list.vue'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/internet/customer/list',
    name: 'internet-customer-list',
    meta: {
      title: '互联网账户列表',
    },
    component: CustomerList,
  },
  {
    path: '/internet/customer/login-log',
    name: 'internet-customer-login-log',
    meta: {
      title: '登录日志',
    },
    component: LoginLog,
  },
  {
    path: '/internet/trade/login-log',
    name: 'internet-trade-login-log',
    meta: {
      title: '交易登录日志',
    },
    component: TradeLoginLog,
  },
  {
    path: '/internet/risk/list',
    name: 'internet-risk-list',
    meta: {
      title: '风险列表',
    },
    component: RiskList,
  },
]

export default routes
