import { RouteRecordRaw } from 'vue-router'

import DepartmentManagement from '@/views/account-management-center/system-management/department-management/department-management.vue'
import LoginLog from '@/views/account-management-center/system-management/login-log/login-log.vue'
import OperationLog from '@/views/account-management-center/system-management/operation-log/operation-log.vue'
import RoleManagement from '@/views/account-management-center/system-management/role-management/role-management.vue'
import UserManagement from '@/views/account-management-center/system-management/user-management/user-management.vue'
import FileImportLog from '@/views/account-management-center/system-management/file-import-log/file-import-log.vue'
import SensitiveWordFiltration from '@/views/account-management-center/system-management/sensitive-word-filtration/sensitive-word-filtration.vue'
import MenuConfig from '@/views/account-management-center/system-management/menu-config/menu-config.vue'
import ExchangerateMaganement from '@/views/account-management-center/system-management/exchange-rate-management/exchange-rate-management.vue'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/account-management-center/department-management',
    name: 'account-management-center-department-management',
    meta: {
      title: '部门管理',
    },
    component: DepartmentManagement,
  },
  {
    path: '/account-management-center/login-log',
    name: 'account-management-center-login-log',
    meta: {
      title: '登录日志',
    },
    component: LoginLog,
  },
  {
    path: '/account-management-center/operation-log',
    name: 'account-management-center-operation-log',
    meta: {
      title: '操作日志',
    },
    component: OperationLog,
  },
  {
    path: '/account-management-center/role-management',
    name: 'account-management-center-role-management',
    meta: {
      title: '角色管理',
    },
    component: RoleManagement,
  },
  {
    path: '/account-management-center/user-management',
    name: 'account-management-center-user-management',
    meta: {
      title: '用户管理',
    },
    component: UserManagement, // UserManagement
  },
  {
    path: '/account-management-center/file-import-log',
    name: 'account-management-center-file-import-log',
    meta: {
      title: '文件导入日志',
    },
    component: FileImportLog,
  },
  {
    path: '/account-management-center/sensitive-word-filtering',
    name: 'sensitive-word-filtration',
    meta: {
      title: '敏感词过滤',
    },
    component: SensitiveWordFiltration,
  },
  {
    path: '/account-management-center/menu-config',
    name: 'account-management-center-menu-config',
    meta: {
      title: '菜单项配置',
    },
    component: MenuConfig,
  },
  {
    path: '/account-management-center/rate-setting',
    name: 'account-management-center-rate-setting',
    meta: {
      title: '汇率设置',
    },
    component: ExchangerateMaganement,
  },
  /* 账户管理中心-end */
]
export default routes
