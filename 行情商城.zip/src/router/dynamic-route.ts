import { RouteRecordRaw } from 'vue-router'
import quotation from './market-subscription'
import accountManagementCenter from './account-management-center'
import nuc from './nuc'

const routes: Array<RouteRecordRaw> = [...quotation, ...accountManagementCenter, ...nuc]
export default routes
