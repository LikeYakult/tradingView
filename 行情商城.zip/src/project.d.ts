export interface Imenu {
  path: string
  title: string
  code?: string
  icon?: string
  children?: Array<Imenu>
}
