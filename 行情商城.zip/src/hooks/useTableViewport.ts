import { onBeforeUnmount, onMounted, onUpdated, ref, Ref } from 'vue'

/** Fit list tables below their actual toolbar; embedded dialog tables retain their own height. */
export default function useTableViewport(table: Ref<any>, hasPagination: () => boolean) {
  const height = ref<number>()
  let observer: ResizeObserver | undefined
  let frame = 0

  const measure = () => {
    const element = table.value?.$el as HTMLElement | undefined
    if (!element || element.closest('.el-dialog, .el-message-box')) return
    const main = element.closest('.main') as HTMLElement | null
    if (!main) return
    const bottom = Math.min(window.innerHeight, main.getBoundingClientRect().bottom)
    const padding = parseFloat(getComputedStyle(main).paddingBottom) || 0
    const pagination = element.nextElementSibling as HTMLElement | null
    const footer = pagination?.classList.contains('el-pagination')
      ? pagination.offsetHeight + (parseFloat(getComputedStyle(pagination).marginTop) || 0)
      : hasPagination()
      ? 40
      : 0
    const nextHeight = Math.max(
      96,
      Math.floor(bottom - padding - element.getBoundingClientRect().top - footer - 2)
    )
    if (nextHeight !== height.value) height.value = nextHeight
  }

  const schedule = () => {
    cancelAnimationFrame(frame)
    frame = requestAnimationFrame(measure)
  }

  onMounted(() => {
    const element = table.value?.$el as HTMLElement | undefined
    if (!element) return
    const main = element.closest('.main')
    observer = new ResizeObserver(schedule)
    // Search expansion, responsive wrapping and navigation must all recalculate the table.
    let parent = element.parentElement
    while (parent) {
      observer.observe(parent)
      if (parent === main) break
      parent = parent.parentElement
    }
    main
      ?.querySelectorAll('.base-filter, .operate-buttons, .operation-buttons, .el-tabs__header')
      .forEach((node) => observer?.observe(node))
    const pagination = element.nextElementSibling
    if (pagination?.classList.contains('el-pagination')) observer.observe(pagination)
    window.addEventListener('resize', schedule)
    schedule()
  })

  onUpdated(schedule)
  onBeforeUnmount(() => {
    observer?.disconnect()
    cancelAnimationFrame(frame)
    window.removeEventListener('resize', schedule)
  })

  return height
}
