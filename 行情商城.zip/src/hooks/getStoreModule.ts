import { computed } from 'vue'
import { appStore, useAccountManagementCenterStore } from '@/store'

/**
 * 获取出入金管理全局状态数据
 * @param keys state Arr
 */
export function useAccountFundManagement(keys: string[]): Record<string, any> {
  const store = appStore()
  const state = computed(() => {
    const source = (store.$state as any).accountFundManagement || {}
    const data: Record<string, any> = {}
    Object.keys(source).forEach((v: string) => {
      if (keys.includes(v)) {
        data[v] = source[v]
      }
    })
    return data
  })

  return state
}

export function useAccountManagementCenter(keys: string[]) {
  const store = useAccountManagementCenterStore()
  const state = computed(() => {
    const source = store.$state as Record<string, any>
    const data: Record<string, any> = {}
    Object.keys(source).forEach((v: string) => {
      if (keys.includes(v)) {
        data[v] = source[v]
      }
    })
    return data
  })

  return state
}
