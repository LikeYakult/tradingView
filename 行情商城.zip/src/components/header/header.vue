<template>
  <div class="main-app-header">
    <div class="header-left">
      <div class="logo">
        <img :src="logoUrl" alt="中信证券" width="120" height="34" />
        <h1 :title="$t('quotationAppTitle')">{{ $t('quotationAppTitle') }}</h1>
      </div>
    </div>
    <div class="header-right">
      <el-popover placement="bottom" :width="360" trigger="click">
        <template #reference>
          <div class="user-avator">
            <!-- 用户头像 -->
            <img src="@/assets/images/avator.png" />
            <div class="name-role">
              <div class="name" :title="user?.nickname">{{ user?.nickname }}</div>
              <div class="role" :title="user?.roleName">{{ user?.roleName }}</div>
            </div>
          </div>
        </template>
        <div class="dropdown-box">
          <div class="brief-info">
            <img src="@/assets/images/avator.png" class="avator" />
            <div class="brief">
              <div class="brief-left">
                <div class="name">{{ user?.nickname }}</div>
                <div class="role">{{ user?.roleName }}</div>
              </div>
              <div class="brief-right">
                <span class="text-primary" @click="showChangePwdDialog = true">{{
                  $t('modifyPassword')
                }}</span>
              </div>
            </div>
          </div>
          <div class="line"></div>
          <div class="module-list">
            <ul>
              <li
                v-for="item of multiModules"
                :key="item.id"
                :class="currentModule?.code === item?.code ? 'active' : ''"
                @click="clickModule(item)"
              >
                <SvgIcon :path="getCurrentMenuIconName(item)" />
                <span>{{ item.name }}</span>
              </li>
            </ul>
          </div>
          <div class="logout-box">
            <el-button type="primary" @click="toLogout">{{ $t('logOff') }}</el-button>
          </div>
        </div>
      </el-popover>
    </div>
    <div class="line"></div>
    <el-dialog
      v-model="showChangePwdDialog"
      :title="$t('modifyPassword')"
      :close-on-click-modal="false"
      width="800px"
      center
      @close="closeChangePwdDialog"
    >
      <el-form
        ref="changePassRef"
        :model="changePassForm"
        :rules="resetPassRule"
        label-width="100px"
        class="update-password-form"
      >
        <el-form-item :label="`${$t('user_name')}：`">
          <span>{{ user?.nickname }}</span>
        </el-form-item>
        <el-form-item :label="`${$t('user_role_name')}：`">
          <span>{{ user?.roleName }}</span>
        </el-form-item>
        <el-form-item :label="`${$t('enter_password')}：`" prop="password">
          <el-input
            v-model="changePassForm.password"
            type="password"
            :placeholder="$t('check_password')"
          ></el-input>
        </el-form-item>
        <el-form-item :label="`${$t('confirm_password')}：`" prop="confirmPassword">
          <el-input
            v-model="changePassForm.confirmPassword"
            type="password"
            :placeholder="$t('check_password')"
          ></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" :loading="changePwdBtnLoading" @click="confirmChangePass">{{
            $t('determine')
          }}</el-button>

          <el-button @click="showChangePwdDialog = false">{{ $t('cancel') }}</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { defineComponent, computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAppStore } from '@/store'
import { useI18n } from 'vue-i18n'

import { ElMessageBox, ElMessage } from 'element-plus'
import { getMenuIconName } from '@/utils/icon'

import { microAppDict } from '@/constants/micro-app'
import { systemLoginInfo, getExternalModuleUrl, changePassword } from '@/api-v2/authority/authority'
import { notifyHost } from '@/utils/host-bridge'
import { LANGUAGE_LOCAL_DICT } from '@/constants/language'
import { getDefaultModulePath, passwordEncrypt } from '@/utils/common'
import locationUtil from '@/utils/location'

export default defineComponent({
  name: 'VHeader',
  setup() {
    // 侧边栏折叠/展开切换事件
    const appStore = useAppStore()
    const router = useRouter()
    const { t, locale } = useI18n()
    const logoUrl = locationUtil.getPublicAssetUrl('/public-images/logo-header.svg')

    const isCollapse = computed(() => appStore.isCollapse)
    const toggleCollapse = () => {
      appStore.setIsCollapse(!isCollapse.value)
    }

    // 嵌入主项目时由主项目接管登录页，登出需通知主项目
    const handleLogout = () => {
      appStore.logout()

      if (appStore.isByQiankun) {
        notifyHost({ jumpLogin: true })
        return
      }

      router.push(`/login`)
    }

    // 下拉框逻辑
    const toLogout = () => {
      ElMessageBox.confirm(t('logout_prompt'), t('logOff'), {
        confirmButtonText: t('determine'),
        cancelButtonText: t('cancel'),
        type: 'warning'
      }).then(() => {
        handleLogout()
      })
    }

    // 切换语言
    const toggleTranslation = () => {
      const lang = appStore.language || LANGUAGE_LOCAL_DICT.CN

      const langMap: Record<string, string> = {
        [LANGUAGE_LOCAL_DICT.CN]: LANGUAGE_LOCAL_DICT.TW,
        [LANGUAGE_LOCAL_DICT.TW]: LANGUAGE_LOCAL_DICT.CN
      }

      const nextLang = langMap[lang]
      locale.value = nextLang

      appStore.setLanguage(nextLang)
    }

    /* 用户信息 和 模块 -start */
    const user = ref()
    const modules = ref()

    systemLoginInfo({}, true).then((res) => {
      const systemInfo = res?.result || {}
      const userInfo = systemInfo.user || {}

      user.value = userInfo
      modules.value = systemInfo.modules || []

      appStore.setAccountInfo(userInfo)
    })

    const multiModules = computed(() => appStore.multiModuleList)

    // let microPath = ''
    // const setMicroPath = (code: string) => {
    //   for (let microName in microAppDict) {
    //     const microInfo = microAppDict[microName]
    //     if (microInfo.beCode === code) {
    //       microPath = microInfo.routerBase
    //     }
    //   }
    // }

    const currentModule = computed(() => appStore.currentModule)

    const clickModule = (theModule: { [key: string]: any }) => {
      if (theModule?.isExternal) {
        // 跳转外部模块
        const moduleCode = theModule?.code
        getExternalModuleUrl({ moduleCode }).then((res) => {
          window.location.href = res.result
        })
        return
      }

      appStore.setCurrentModule(theModule)
      // setMicroPath(theModule?.code)
      const path = getDefaultModulePath(theModule)

      console.log(path, '-------> microPath')

      if (path) {
        const fullPath = locationUtil.getFullPath(path)
        appStore.setCurrentModulePath(fullPath)
        router.push(locationUtil.getRouterPath(fullPath))
      }
    }

    const getCurrentMenuIconName = (module: Record<string, any>) => {
      const moduleName = getMenuIconName(module, currentModule.value)
      return locationUtil.getPublicAssetUrl(`/public-images/${moduleName}.svg`)
    }

    /* 用户信息 和 模块 -end */

    // 修改密码
    const showChangePwdDialog = ref(false)
    const changePwdBtnLoading = ref(false)

    const changePassRef = ref()
    const changePassForm = ref({
      password: '',
      confirmPassword: ''
    })

    const validatorPassWrod = (rule: object, value: string, callback: any) => {
      const isExtent = /^.{8,16}$/.exec(value)
      const reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9a-zA-Z]{8,16}$/
      if (!reg.test(value)) {
        return callback(new Error(t('check_password')))
      }
      if (!isExtent) {
        return callback(new Error(t('check_password')))
      }

      const { password, confirmPassword } = changePassForm.value
      const isExist = password && confirmPassword
      const isUnlikeness = password !== confirmPassword

      if (isExist && isUnlikeness) {
        return callback(new Error(t('inconsistent_passwords')))
      }

      return callback()
    }

    const resetPassRule = ref({
      password: [{ required: true, validator: validatorPassWrod, trigger: 'blur' }],
      confirmPassword: [{ required: true, validator: validatorPassWrod, trigger: 'blur' }]
    })

    const confirmChangePass = () => {
      changePassRef.value.validate((validate: boolean) => {
        if (!validate) {
          return false
        }
        changePwdBtnLoading.value = true

        // console.log('changePassForm.value', changePassForm.value)
        const pramas = JSON.parse(JSON.stringify(changePassForm.value))
        const newPramas = {
          password: passwordEncrypt(pramas.password),
          confirmPassword: passwordEncrypt(pramas.confirmPassword)
        }
        // console.log('newPramas', newPramas)
        changePassword(newPramas)
          .then((res) => {
            if (res.code === 0) {
              ElMessage.success(t('change_password_success'))
              handleLogout()
            }
          })
          .finally(() => {
            changePwdBtnLoading.value = false
          })
      })
    }

    const closeChangePwdDialog = () => {
      changePassRef.value.resetFields()
    }

    return {
      isCollapse,
      toggleCollapse,
      toLogout,
      toggleTranslation,
      user,
      currentModule,
      multiModules,
      clickModule,
      showChangePwdDialog,
      changePwdBtnLoading,
      changePassRef,
      changePassForm,
      resetPassRule,
      confirmChangePass,
      closeChangePwdDialog,
      getCurrentMenuIconName,
      logoUrl
    }
  }
})
</script>

<style lang="scss" scoped>
// 同路径组件在开发环境可能生成相同的 scoped 标识，使用主应用专属类名避免子应用覆盖。
.main-app-header {
  width: 100%;
  height: var(--ui-header-height, 50px);
  min-width: 0;
  padding: 0 20px;
  gap: 20px;
  flex-shrink: 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: relative;
  border-bottom: 1px solid var(--el-border-color-light);
  background: #fff;
  .line {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 1px;
  }
  .header-left {
    flex: 1;
    min-width: 0;

    .logo {
      display: flex;
      align-items: center;
      gap: 16px;
      min-width: 0;

      img {
        width: 120px;
        height: 34px;
        object-fit: contain;
        display: block;
        flex-shrink: 0;
        margin: 0;
      }

      h1 {
        min-width: 0;
        margin: 0;
        padding: 0;
        overflow: hidden;
        font-size: 18px;
        line-height: 24px;
        white-space: nowrap;
        text-overflow: ellipsis;
        font-family: PingFangHK, PingFangHK-Medium;
        font-weight: 500;
        color: #000000;
      }
    }
    .collapse-btn {
      padding: 0 20px;
      cursor: pointer;
    }
  }
  .header-right {
    display: flex;
    flex-shrink: 0;
    align-items: center;
    .user-info {
      .item {
        font-size: 15px;
        margin-right: 10px;
      }
    }
    .translation {
      cursor: pointer;
    }
    .user-avator {
      display: flex;
      align-items: center;
      gap: 8px;
      min-height: 40px;
      cursor: pointer;
      color: #212121;
      img {
        display: block;
        flex-shrink: 0;
        width: 32px;
        height: 32px;
        border-radius: 50%;
      }
      .name-role {
        min-width: 0;
        max-width: 160px;
        font-size: 14px;
        line-height: 18px;
        color: #212121;
        .name,
        .role {
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
        .role {
          font-size: 12px;
          line-height: 16px;
          color: #999999;
        }
      }
    }
  }
}

@media (max-width: 768px) {
  .main-app-header {
    padding: 0 12px;
    gap: 12px;

    .header-left .logo {
      gap: 12px;

      img {
        width: 106px;
        height: 30px;
      }

      h1 {
        font-size: 16px;
        line-height: 22px;
      }
    }

    .header-right .user-avator .name-role {
      max-width: 120px;
    }
  }
}

@media (max-width: 480px) {
  .main-app-header {
    .header-left .logo {
      gap: 10px;

      img {
        width: 96px;
        height: 28px;
      }

      h1 {
        font-size: 14px;
        line-height: 20px;
      }
    }

    .header-right .user-avator .name-role {
      display: none;
    }
  }
}

.dropdown-box {
  .brief-info {
    display: flex;
    align-items: center;
    margin: 10px 0 20px;

    .avator {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      margin-right: 12px;
    }
    .brief {
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .brief-left {
        flex: 1;
      }
      .brief-right {
        margin-left: 15px;
        width: 28%;
        white-space: nowrap;
      }
      .name {
        font-size: 16px;
        font-family: PingFangHK, PingFangHK-Regular;
        color: #212121;
      }
      .role {
        font-size: 14px;
        font-family: PingFangHK, PingFangHK-Regular;
        color: #999999;
      }
      .modify-password {
        font-size: 14px;
        font-family: PingFangSC, PingFangSC-Regular;
        color: #d20a10;
        cursor: pointer;
      }
      // .brief-one {
      //   display: flex;
      //   justify-content: space-between;
      //   margin-bottom: 8px;
      //   .modify-password {
      //     color: #2d8cf0;
      //     cursor: pointer;
      //   }
      // }
    }
  }
  .line {
    height: 1px;
    border: 1px dashed #f4f4f4;
  }
  .module-list {
    margin: 10px -12px;

    ul {
      padding: 0;

      li {
        display: flex;
        align-items: center;
        height: 50px;
        line-height: 50px;
        padding-left: 20px;
        color: #212121;
        font-size: 16px;
        cursor: pointer;

        span {
          padding: 0 12px;
        }

        &.active,
        &:hover {
          color: #d20a10;
          background-color: #fde8e8;
        }
      }
    }
  }
  .logout-box {
    padding: 10px 0;
    text-align: center;
  }
}

.update-password-form {
  width: 400px;
  margin: 0 auto;

  :deep(.el-form-item--default) {
    margin-bottom: 30px;
  }

  :deep(.el-form-item--default .el-form-item__label) {
    line-height: 40px;
  }

  :deep(.el-input__inner) {
    height: 40px;
    padding: 0 10px;
    // border: 1px solid #c8cad2;
    border-radius: 4px;
  }

  :deep(.el-form-item__error) {
    padding-top: 6px;
  }
}
</style>
