<template>
  <div class="sidebar">
    <div class="left">
      <ul>
        <li
          v-for="theModule of multiModuleListAll"
          :key="theModule.code"
          :class="currentModule?.code === theModule?.code ? 'active' : ''"
          @click="clickModule(theModule)"
        >
          <SvgIcon :path="getCurrentMenuIconName(theModule)" />
          <div class="title">{{ theModule.name }}</div>
        </li>
      </ul>

      <transition name="el-fade-in">
        <div v-show="isShowAll" class="transition-box" @click.stop="() => {}">
          <el-scrollbar>
            <div v-for="theModule of multiModuleList" :key="theModule?.code" class="the-module">
              <div class="icon-name">
                <SvgIcon :path="require('@/images/translation.svg')" />
                <span class="name">{{ theModule?.name }}</span>
              </div>
              <div v-for="menu of theModule?.menu" :key="menu?.id">
                <div class="menu-name">{{ menu?.name }}</div>
                <div v-for="menuItem of menu.children" :key="menuItem?.id">
                  <div class="menu-item" @click="menuItemClick(theModule, menuItem)">
                    {{ menuItem?.title }}
                  </div>
                </div>
              </div>
            </div>
          </el-scrollbar>
        </div>
      </transition>
    </div>

    <div class="right">
      <el-scrollbar>
        <!-- <div class="module-name">{{ currentModule.name }}</div> -->

        <el-menu
          active-text-color="#d20a10"
          text-color="#303133"
          class="el-menu-vertical-demo"
          :collapse-transition="false"
          :default-active="activeMenuIndex"
          @select="select"
        >
          <MenuList :list="menu" />
        </el-menu>
      </el-scrollbar>
    </div>
  </div>
</template>
<script lang="ts">
import { defineComponent, ref, PropType, computed, onBeforeMount, onDeactivated } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAppStore } from '@/store'
import { useI18n } from 'vue-i18n'
import { ElMessage } from 'element-plus'
import { getExternalModuleUrl } from '@/api-v2/authority/authority'
import { getMenuIconName } from '@/utils/icon'
import MenuList from './menu-list.vue'
import { getDefaultModulePath } from '@/utils/common'
import locationUtil from '@/utils/location'

export default defineComponent({
  name: 'ModuleList',
  props: {
    multiModuleList: {
      type: Array as PropType<any[]>,
      default: () => []
    }
  },
  components: { MenuList },
  setup(props) {
    const appStore = useAppStore()
    const router = useRouter()
    const isShowAll = ref(false)

    const currentModule = computed(() => appStore.currentModule)

    const getMenu = (module: { [key: string]: any }) => {
      const quotationModule = props.multiModuleList.find((item) => item?.code === 'quotation')
      const moduleMenu =
        module?.code === 'sys' ? quotationModule?.menu || module?.menu || [] : module?.menu || []
      const systemModule = props.multiModuleList.find((item) => item?.code === 'sys')
      const systemMenu = systemModule?.menu || []
      const systemMenuGroup = systemMenu.length
        ? [
            {
              id: `${systemModule.code}-menu`,
              internalPath: '/system-management',
              title: systemModule.name,
              children: systemMenu
            }
          ]
        : []

      return [...moduleMenu, ...systemMenuGroup]
    }

    const menu = computed(() => getMenu(currentModule.value))

    const { t } = useI18n({ useScope: 'global' })
    const route = useRoute()
    const currentRoutePath = computed(() => route.path)
    const activeMenuIndex = ref(currentRoutePath.value)

    const getCurrentMenuIconName = (module: Record<string, any>) => {
      const moduleName = getMenuIconName(module, currentModule.value)
      return locationUtil.getPublicAssetUrl(`/public-images/${moduleName}.svg`)
    }

    const path = getDefaultModulePath(currentModule.value)
    if (!currentRoutePath.value && path) {
      const fullPath = locationUtil.getFullPath(path)
      appStore.setCurrentModulePath(fullPath)
      router.push(locationUtil.getRouterPath(fullPath))
    }

    const multiModuleListAll = computed(() => {
      return [
        {
          code: 'all',
          name: t('all')
        },
        ...props.multiModuleList
      ]
    })

    const clickModule = (theModule: { [key: string]: any }) => {
      const isAll = theModule?.code === 'all'

      console.log(theModule, '<0-- theModule')

      if (isAll && isShowAll.value) {
        isShowAll.value = false
        return
      }

      if (isAll) {
        setTimeout(() => {
          isShowAll.value = true
        })
        return
      }

      isShowAll.value = false
      if (theModule?.isExternal) {
        // 跳转外部模块
        const moduleCode = theModule?.code
        getExternalModuleUrl({ moduleCode }).then((res) => {
          if (res?.result) {
            window.open(res.result, '_blank')
          } else {
            ElMessage.error(t('path_error'))
          }
        })
        return
      }

      appStore.setCurrentModule(theModule)

      const path = getDefaultModulePath(theModule)
      if (path) {
        const fullPath = locationUtil.getFullPath(path)
        appStore.setCurrentModulePath(fullPath)
        router.push(locationUtil.getRouterPath(fullPath))
      }
    }

    const menuItemClick = (theModule: { [key: string]: any }, menuItem: { [key: string]: any }) => {
      currentModule.value = theModule

      isShowAll.value = false
      appStore.setCurrentModule(theModule)

      const { internalPath } = menuItem
      if (internalPath) {
        const fullPath = locationUtil.getFullPath(internalPath)
        appStore.setCurrentModulePath(fullPath)
        router.push(locationUtil.getRouterPath(fullPath))
      }
    }

    const closeMenuInfo = () => {
      if (isShowAll.value) isShowAll.value = false
    }

    onBeforeMount(() => {
      document.addEventListener('click', closeMenuInfo)
    })

    onDeactivated(() => {
      document.removeEventListener('click', closeMenuInfo)
    })

    const hasMenuPath = (menuList: any[], path: string): boolean =>
      menuList.some((item) => item.internalPath === path || hasMenuPath(item.children || [], path))

    const select = (index) => {
      activeMenuIndex.value = index
      const selectedModule = props.multiModuleList.find((module) =>
        hasMenuPath(module.menu || [], index)
      )
      if (selectedModule) {
        appStore.setCurrentModule(selectedModule)
      }
      const fullPath = locationUtil.getFullPath(index)
      appStore.setCurrentModulePath(fullPath)
      router.push(locationUtil.getRouterPath(fullPath))
    }

    return {
      currentModule,
      clickModule,
      multiModuleListAll,
      isShowAll,
      menuItemClick,
      currentRoutePath,
      activeMenuIndex,
      getCurrentMenuIconName,
      menu,
      select
    }
  }
})
</script>
<style lang="scss" scoped>
.sidebar {
  display: flex;
  .left {
    display: none;
    position: relative;
    width: 80px;
    ul {
      padding: 0;
      margin: 0;
      li {
        color: #868890;
        text-align: center;
        margin-top: 28px;
        cursor: pointer;
        &.active {
          color: #d20a10;
        }
        .title {
          font-size: 14px;
          font-family: PingFangSC, PingFangSC-Regular;
        }
      }
    }
  }

  .right {
    flex-shrink: 0;
    border-right: 1px solid var(--el-border-color-light);
    background: #fff;
    :deep(.el-menu) { padding: 8px; }
    width: var(--ui-sidebar-width);
    position: relative;
    background-color: #fff;

    .module-name {
      display: flex;
      align-items: center;
      padding: 0 20px;
      width: var(--ui-sidebar-width);
      height: 40px;
      background: #e9eaee;
      color: #212121;
      font-size: 16px;
    }

    .transition-box {
      position: absolute;
      top: 0;
      z-index: 10;
      height: 100%;
      min-width: 680px;
      padding: 20px;
      padding-right: 0px;
      background-color: #fff;
      .the-module {
        display: inline-block;
        vertical-align: top;
        margin-right: 50px;
        .icon-name {
          display: flex;
          align-items: center;
          font-size: 16px;
          font-family: PingFangHK, PingFangHK-Medium;
          font-weight: 500;
          color: #212121;
          .name {
            margin-left: 9px;
          }
        }

        .menu-name {
          padding: 6px 0 6px 28px;
          color: #212121;
          font-size: 14px;
          font-family: PingFangSC, PingFangSC-Regular;
          line-height: 1.5;
        }

        .menu-item {
          width: 150px;
          padding: 6px 0 6px 28px;
          color: #8c8e96;
          font-size: 14px;
          font-family: PingFangSC, PingFangSC-Regular;
          line-height: 1.5;
          cursor: pointer;

          &:hover {
            color: #d20a10;
            background-color: var(--el-color-primary-light-9);
          }
        }
      }
    }

    // el-menu 内联子菜单在首帧自动展开时，折叠动画可能停在起始状态（max-height: 0），
    // 导致子菜单高度为 0 并与父级菜单重叠；这里强制展开到内容高度。
    :deep(.el-menu--inline) {
      max-height: none !important;
      height: auto !important;
      overflow: visible !important;
      transition: none !important;
    }

    :deep(.el-menu-item.is-active) {
      background-color: var(--el-color-primary-light-9) !important;
      color: #d20a10 !important;
    }

    :deep(.el-menu-item:hover),
    :deep(.el-sub-menu__title:hover) {
      background-color: #fff !important;
      color: #d20a10 !important;
    }
  }

  .transition-box {
    position: absolute;
    top: 0;
    left: 80px;
    z-index: 10;
    height: 100%;
    min-width: 680px;
    padding: 20px;
    padding-right: 0px;
    background-color: #fff;
    .the-module {
      display: inline-block;
      vertical-align: top;
      margin-right: 50px;
      .icon-name {
        display: flex;
        align-items: center;
        font-size: 16px;
        font-family: PingFangHK, PingFangHK-Medium;
        font-weight: 500;
        color: #212121;
        .name {
          margin-left: 9px;
        }
      }

      .menu-name {
        color: #212121;
        font-size: 14px;
        font-family: PingFangSC, PingFangSC-Regular;
        padding: 6px 0 6px 28px;
        line-height: 1.5;
      }

      .menu-item {
        width: 150px;
        padding: 6px 0 6px 28px;
        color: #8c8e96;
        font-size: 14px;
        font-family: PingFangSC, PingFangSC-Regular;
        line-height: 1.5;
        cursor: pointer;

        &:hover {
          color: #d20a10;
          background-color: var(--el-color-primary-light-9);
        }
      }
    }
  }
}
</style>
