<template>
  <template v-for="item of list" :key="item.internalPath">
    <el-menu-item v-if="!item.children?.length" :index="item.internalPath">
      <el-icon v-if="level === 0" class="menu-icon"><component :is="getMenuIcon(item)" /></el-icon>
      <template #title>{{ item.title }}</template>
    </el-menu-item>
    <el-sub-menu v-else :index="item.internalPath">
      <template #title>
        <el-icon v-if="level === 0" class="menu-icon"
          ><component :is="getMenuIcon(item)"
        /></el-icon>
        <span>{{ item.title }}</span>
      </template>
      <menu-list :list="item.children" :level="level + 1" />
    </el-sub-menu>
  </template>
</template>

<script lang="ts">
import { defineComponent, PropType } from 'vue'
import { ElIcon } from 'element-plus'
import { Box, Document, Folder, Setting, Tickets, User } from '@element-plus/icons-vue'
import { Imenu } from '@/project'

export default defineComponent({
  name: 'MenuList',
  components: { ElIcon },
  props: {
    list: { type: Array as PropType<Imenu[]>, required: true },
    level: { type: Number, default: 0 },
  },
  setup() {
    const getMenuIcon = (item: Imenu) => {
      const code = item.code || item.path || ''
      if (/system|role|setting/i.test(code)) return Setting
      if (/user|customer|account/i.test(code)) return User
      if (/package/i.test(code)) return Box
      if (/order/i.test(code)) return Tickets
      if (/report|log/i.test(code)) return Document
      return Folder
    }
    return { getMenuIcon }
  },
})
</script>

<style lang="scss" scoped>
.menu-icon {
  width: 16px;
  height: 16px;
  margin-right: 10px;
}
</style>
