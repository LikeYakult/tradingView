import { computed, defineComponent, getCurrentInstance, PropType, ref, unref, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import {
  ElForm,
  ElFormItem,
  ElInput,
  ElDatePicker,
  ElSelect,
  ElOption,
  ElButton,
  ElIcon,
} from 'element-plus'
import { ArrowDown, ArrowUp } from '@element-plus/icons-vue'
import './base-filter.scss'

interface FilterConfig {
  formProps: Record<string, any>
  formItems: any[]
}

export default defineComponent({
  components: {
    ElForm,
    ElFormItem,
    ElInput,
    ElDatePicker,
    ElSelect,
    ElOption,
    ElButton,
    ElIcon,
  },
  props: {
    config: { type: Object as PropType<FilterConfig>, required: true },
    tabActive: { type: String, default: '' },
    loading: { type: Boolean, default: false },
  },
  emits: ['onSearch', 'onReset'],
  setup(props, { slots, emit }) {
    const { t } = useI18n()
    const model = computed(() => props.config.formProps.model || {})
    const items = computed(() => props.config.formItems || [])
    const expanded = ref(false)
    const collapsedFieldCount = 4
    const canCollapse = computed(() => items.value.length > collapsedFieldCount)
    const fieldPanelId = `base-filter-fields-${getCurrentInstance()?.uid}`
    watch(canCollapse, () => (expanded.value = false))
    const onSearch = () => {
      if (!props.loading) emit('onSearch', model.value)
    }
    const onKeydown = (event: KeyboardEvent) => {
      if (
        event.key !== 'Enter' ||
        event.isComposing ||
        event.keyCode === 229 ||
        event.defaultPrevented
      ) {
        return
      }
      const target = event.target as HTMLElement | null
      // 下拉框和日期控件使用回车确认选项，文本域保留换行行为。
      if (
        target?.tagName !== 'INPUT' ||
        target.closest('.el-select, .el-date-editor, .el-autocomplete')
      ) {
        return
      }
      event.preventDefault()
      if (!event.repeat) onSearch()
    }
    const onReset = () => {
      Object.keys(model.value).forEach((key) => {
        const value = model.value[key]
        model.value[key] = Array.isArray(value) ? [] : typeof value === 'boolean' ? false : ''
      })
      emit('onReset', model.value)
    }
    watch(
      () => props.tabActive,
      () => {
        expanded.value = false
        onReset()
      }
    )

    const renderItem = (item: any) => {
      if (item.slot) return slots[item.slot]?.()
      const { innerEl, ...params } = item
      let control
      switch (innerEl?.elType) {
        case 'input':
          control = <el-input clearable v-model={model.value[item.prop]} {...innerEl.props} />
          break
        case 'datePicke':
        case 'datePicker':
          control = (
            <el-date-picker
              v-model={model.value[item.prop]}
              type="datetimerange"
              range-separator="—"
              start-placeholder={t('start_date')}
              end-placeholder={t('end_date')}
              {...innerEl.props}
            />
          )
          break
        case 'select':
          control = (
            <el-select
              clearable
              v-model={model.value[item.prop]}
              placeholder={t('please_select')}
              {...innerEl.props}
            >
              {(unref(innerEl.options) || []).map((option: any) => (
                <el-option key={option.value} label={option.label} value={option.value} />
              ))}
            </el-select>
          )
          break
      }
      return (
        <el-form-item key={item.prop} {...params}>
          {control}
        </el-form-item>
      )
    }

    const actions = () => (
      <div class="base-filter__actions">
        <el-button
          class="base-filter__search"
          type="primary"
          native-type="submit"
          loading={props.loading}
          aria-label={t('query')}
        >
          {t('query')}
        </el-button>
        <el-button onClick={onReset}>{t('reset')}</el-button>
        {canCollapse.value && (
          <el-button
            class="base-filter__toggle"
            native-type="button"
            aria-expanded={expanded.value}
            aria-controls={fieldPanelId}
            onClick={() => (expanded.value = !expanded.value)}
          >
            <ElIcon>{expanded.value ? <ArrowUp /> : <ArrowDown />}</ElIcon>
            <span>{t(expanded.value ? 'collapse_filters' : 'expand_filters')}</span>
          </el-button>
        )}
      </div>
    )

    return () => (
      <div class="base-filter">
        <el-form
          {...props.config.formProps}
          model={model.value}
          labelPosition="right"
          labelWidth={props.config.formProps.labelWidth ?? 'auto'}
          class="base-filter__form"
          onKeydown={onKeydown}
          onSubmit={(event: Event) => {
            event.preventDefault()
            onSearch()
          }}
        >
          <div id={fieldPanelId} class="base-filter__fields">
            {items.value.map((item, index) => (
              <div
                key={item.prop || item.slot || index}
                v-show={expanded.value || index < collapsedFieldCount}
                class="base-filter__field"
              >
                {renderItem(item)}
              </div>
            ))}
            {actions()}
          </div>
        </el-form>
      </div>
    )
  },
})
