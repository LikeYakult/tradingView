import { cloneVNode, defineComponent } from 'vue'
import { ElMessageBox } from 'element-plus'
import { useI18n } from 'vue-i18n'

export default defineComponent({
  name: 'ActionConfirm',
  props: {
    title: { type: String, required: true },
    confirmButtonText: { type: String, default: '' },
    cancelButtonText: { type: String, default: '' },
  },
  emits: ['confirm', 'cancel'],
  setup(props, { slots, emit }) {
    const { t } = useI18n()
    let pending = false

    async function open(event: MouseEvent) {
      const target = event.target
      if (
        pending ||
        event.defaultPrevented ||
        (target instanceof Element &&
          target.closest(':disabled, [aria-disabled="true"], .is-disabled'))
      ) {
        return
      }

      pending = true
      try {
        await ElMessageBox.confirm(props.title, t('tip'), {
          customClass: 'list-action-message-box',
          type: 'warning',
          confirmButtonText: props.confirmButtonText || t('determine'),
          cancelButtonText: props.cancelButtonText || t('cancel'),
          closeOnClickModal: false,
        })
      } catch {
        emit('cancel', event)
        return
      } finally {
        pending = false
      }

      emit('confirm', event)
    }

    // Keep the original trigger element, permissions, and click handlers intact.
    return () => {
      const trigger = slots.reference?.()[0]
      return trigger ? cloneVNode(trigger, { onClick: open }, true) : null
    }
  },
})
