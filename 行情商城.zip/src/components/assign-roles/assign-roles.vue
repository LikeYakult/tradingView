<template>
  <div v-loading="loading" class="assign-roles">
    <div class="role-toolbar">
      <el-input v-model="keyword" clearable :placeholder="t('role_search_placeholder')">
        <template #prefix
          ><el-icon><Search /></el-icon
        ></template>
      </el-input>
      <el-tag type="info" effect="plain">{{
        t('selected_count', { count: selectedCount })
      }}</el-tag>
    </div>
    <div class="role-content">
      <div v-if="superAdmin && matches(superAdmin.name)" class="super-item">
        <el-checkbox-group v-model="superModel" :disabled="loading" @change="superChange">
          <el-checkbox :value="superAdmin.id">{{ superAdmin.name }}</el-checkbox>
        </el-checkbox-group>
        <p>{{ t('super_role_hint') }}</p>
      </div>
      <section v-for="group in filteredModules" :key="group.code" class="module-item">
        <div class="module-title">{{ group.name }}</div>
        <el-checkbox-group
          v-model="roleModel[group.code]"
          :disabled="disabledModules || loading"
          class="role-grid"
          @change="modulesChange"
        >
          <el-checkbox v-for="item in group.roles" :key="item.id" :value="item.id" border>
            {{ item.name }}
          </el-checkbox>
        </el-checkbox-group>
      </section>
      <el-empty
        v-if="!loading && !filteredModules.length && !(superAdmin && matches(superAdmin.name))"
        :description="t('temporarily_no_data')"
        :image-size="72"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import { Search } from '@element-plus/icons-vue'

type RoleId = string | number
interface Role {
  id: RoleId
  name: string
  checked?: boolean
}
interface RoleModule {
  code: string
  name: string
  roles?: Role[]
}
const props = defineProps<{
  data?: { superAdmin?: Role; modules?: RoleModule[] }
  selectedIds?: RoleId[]
  loading?: boolean
}>()
const emit = defineEmits(['roleChange'])
const { t } = useI18n()
const keyword = ref('')
const superAdmin = computed(() =>
  props.data?.superAdmin?.id != null ? props.data.superAdmin : undefined
)
const modules = computed(() => props.data?.modules || [])
const superModel = ref<RoleId[]>([])
const roleModel = reactive<Record<string, RoleId[]>>({})
const disabledModules = computed(() => superModel.value.length > 0)
const selectedCount = computed(() =>
  disabledModules.value ? superModel.value.length : Object.values(roleModel).flat().length
)
const matches = (name: string) =>
  String(name || '')
    .toLowerCase()
    .includes(keyword.value.trim().toLowerCase())
const filteredModules = computed(() =>
  modules.value
    .map((group) => ({ ...group, roles: (group.roles || []).filter((role) => matches(role.name)) }))
    .filter((group) => group.roles.length)
)

function superChange() {
  if (disabledModules.value) Object.keys(roleModel).forEach((key) => (roleModel[key] = []))
  emit('roleChange', [...superModel.value])
}
function modulesChange() {
  emit('roleChange', Object.values(roleModel).flat())
}

// 数据异步到达、切换用户时重建选项；回显不触发用户选择事件。
watch(
  [() => props.data, () => props.selectedIds],
  () => {
    Object.keys(roleModel).forEach((key) => delete roleModel[key])
    const admin = superAdmin.value
    const selected = props.selectedIds
    superModel.value =
      admin && (selected ? selected.includes(admin.id) : admin.checked) ? [admin.id] : []
    modules.value.forEach((group) => {
      roleModel[group.code] = disabledModules.value
        ? []
        : (group.roles || [])
            .filter((role) => (selected ? selected.includes(role.id) : role.checked))
            .map((role) => role.id)
    })
  },
  { immediate: true }
)
watch(
  () => props.data,
  () => (keyword.value = '')
)
</script>

<style lang="scss" scoped>
/* stylelint-disable selector-class-pattern, selector-pseudo-class-no-unknown -- Element Plus BEM and Vue scoped selectors. */
.role-toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;

  .el-input {
    flex: 1;
    min-width: 0;
  }

  .el-tag {
    flex-shrink: 0;
  }
}

.role-content {
  height: 320px;
  max-height: 48vh;
  overflow: auto;
  overscroll-behavior: contain;

  > .el-empty {
    height: 100%;
    box-sizing: border-box;
  }
}

.super-item {
  padding: 12px 16px;
  margin-bottom: 16px;
  border: 1px solid var(--el-color-primary-light-8);
  border-radius: 4px;
  background: var(--el-color-primary-light-9);

  p {
    margin: 4px 0 0 24px;
    color: var(--el-text-color-secondary);
    font-size: 12px;
    line-height: 20px;
  }
}

.module-item + .module-item {
  margin-top: 20px;
}

.module-title {
  padding-left: 10px;
  margin-bottom: 12px;
  border-left: 3px solid var(--el-color-primary);
  color: var(--el-text-color-primary);
  font-weight: 500;
  line-height: 20px;
}

.role-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 10px;

  .el-checkbox {
    height: auto;
    min-height: 40px;
    padding: 8px 12px;
    margin: 0;
  }
}

.assign-roles :deep(.el-checkbox__label) {
  white-space: normal;
  line-height: 22px;
  overflow-wrap: anywhere;
}

@media (max-width: 540px) {
  .role-grid {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
