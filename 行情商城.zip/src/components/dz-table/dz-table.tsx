import { tableSlot } from '@/utils/table-ui'
import useTableViewport from '@/hooks/useTableViewport'
import { defineComponent, toRefs, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElTable, ElTableColumn, ElPagination } from 'element-plus'

export default defineComponent({
  components: { ElTable, ElTableColumn, ElPagination },
  props: {
    config: {
      type: Object,
    },
    pagination: {
      type: Object,
    },
    isTableLoading: {
      type: Boolean,
      default: false,
    },
  },
  setup(props, { slots, expose }: { [name: string]: any }) {
    const { t } = useI18n()
    const { config, pagination, isTableLoading } = toRefs(props)
    const currentPage = ref(1)
    const toFirstPage = () => {
      currentPage.value = 1
    }
    const baseTable = ref()
    const viewportHeight = useTableViewport(baseTable, () => Boolean(pagination.value))
    expose({
      toFirstPage,
      baseTable,
    })
    return () => (
      <>
        <el-table
          ref={baseTable}
          empty-text={isTableLoading.value ? ' ' : t('temporarily_no_data')}
          v-loading={isTableLoading.value}
          border
          {...{ ...config.value?.tableProps, ...config.value?.tableEvent }}
          height={viewportHeight.value ?? config.value?.tableProps?.height}
          stripe
        >
          {config.value?.customColumns.map((column: typeof ElTableColumn, columnIndex: number) => {
            if (column.slot) return tableSlot(slots[column.slot]?.(), column.slot)
            if (column.type)
              return (
                <el-table-column align="center" {...column} key={columnIndex}></el-table-column>
              )
            return (
              <el-table-column align="center" {...column} key={columnIndex}>
                {{
                  default: (scope: any) => {
                    if (column.render) {
                      return column.render(scope)
                    }

                    const value = scope.row[column.prop]
                    return value === null || value === undefined || value === '' ? '--' : value
                  },
                }}
              </el-table-column>
            )
          })}
        </el-table>

        {pagination.value && (
          <el-pagination
            background
            pager-count={7}
            v-model:currentPage={currentPage.value}
            page-sizes={[20, 50, 100, 200]}
            page-size={100}
            layout="total, sizes, prev, pager, next, jumper"
            total={400}
            onSizeChange={() => {}}
            onCurrentChange={() => {}}
            {...{ ...pagination.value?.paginationProps, ...pagination.value?.paginationEvent }}
            class="ui-table-pagination"
          />
        )}
      </>
    )
  },
})
