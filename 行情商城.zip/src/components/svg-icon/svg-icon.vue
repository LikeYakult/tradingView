<template>
  <svg :width="size" :height="size" aria-hidden="true" :style="{ fill: 'currentColor' }">
    <image :href="image" style="width: 100%; height: 100%" />
  </svg>
</template>

<script lang="ts">
import { defineComponent, computed } from 'vue'

export default defineComponent({
  name: 'SvgIcon',

  props: {
    path: {
      type: String,
      required: true
    },
    size: {
      type: Number,
      default: 20
    }
  },
  setup(props: any) {
    const image = computed(() => props.path)
    return { image }
  }
})
</script>
