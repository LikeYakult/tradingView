<template>
  <div class="permission-selector">
    <el-tabs
      v-if="modules.length"
      :model-value="activeModule"
      class="permission-selector__tabs"
      @tab-change="emit('moduleChange', $event)"
    >
      <el-tab-pane
        v-for="item in modules"
        :key="item.value"
        :label="item.label"
        :name="item.value"
      />
    </el-tabs>
    <div class="permission-selector__toolbar">
      <el-input v-model="keyword" clearable :placeholder="t('permission_search_placeholder')">
        <template #prefix
          ><el-icon><Search /></el-icon
        ></template>
      </el-input>
      <el-button @click="toggleExpanded">{{
        t(expanded ? 'collapse_all' : 'expand_all')
      }}</el-button>
    </div>
    <div v-loading="loading" class="permission-selector__content">
      <el-tree
        :key="activeModule"
        ref="tree"
        :data="data"
        :props="nodeProps"
        :node-key="nodeKey"
        :default-checked-keys="defaultCheckedKeys"
        :default-expand-all="expanded"
        :filter-node-method="filterNode"
        :empty-text="loading ? ' ' : t('temporarily_no_data')"
        show-checkbox
        @check="(node, checked) => emit('check', node, checked)"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
/* global withDefaults */
import { nextTick, ref, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import { Search } from '@element-plus/icons-vue'

const props = withDefaults(
  defineProps<{
    data?: any[]
    nodeProps?: Record<string, any>
    nodeKey?: string
    defaultCheckedKeys?: (string | number)[]
    modules?: { label: string; value: string }[]
    activeModule?: string
    loading?: boolean
  }>(),
  {
    data: () => [],
    nodeProps: () => ({ children: 'children', label: 'name' }),
    nodeKey: 'id',
    defaultCheckedKeys: () => [],
    modules: () => [],
    activeModule: '',
    loading: false,
  }
)
const emit = defineEmits(['check', 'moduleChange'])
const { t } = useI18n()
const tree = ref<any>()
const keyword = ref('')
const expanded = ref(true)

function filterNode(value: string, node: Record<string, any>) {
  const label = node[props.nodeProps.label || 'name']
  return (
    !value.trim() ||
    String(label ?? '')
      .toLowerCase()
      .includes(value.trim().toLowerCase())
  )
}

function toggleExpanded() {
  expanded.value = !expanded.value
  const visit = (nodes: any[]) => {
    nodes.forEach((item) => {
      const node = tree.value?.getNode(item[props.nodeKey])
      if (node) node.expanded = expanded.value
      visit(item[props.nodeProps.children || 'children'] || [])
    })
  }
  visit(props.data)
}

watch([keyword, () => props.data], () => {
  nextTick(() => tree.value?.filter(keyword.value))
})
watch(
  () => props.activeModule,
  () => {
    keyword.value = ''
    expanded.value = true
  }
)
watch(
  () => props.defaultCheckedKeys,
  (keys) => nextTick(() => tree.value?.setCheckedKeys(keys))
)

// 保留父页面读取、回显勾选项的接口，搜索和展开操作不改变选中结果。
defineExpose({
  getCheckedKeys: (leafOnly = false) => tree.value?.getCheckedKeys(leafOnly) || [],
  getHalfCheckedKeys: () => tree.value?.getHalfCheckedKeys() || [],
  setCheckedKeys: (keys: (string | number)[], leafOnly = false) =>
    nextTick(() => tree.value?.setCheckedKeys(keys, leafOnly)),
})
</script>

<style lang="scss" scoped>
/* stylelint-disable selector-class-pattern, selector-pseudo-class-no-unknown -- Element Plus BEM and Vue scoped selectors. */
.permission-selector__tabs :deep(.el-tabs__header) {
  margin: 0 0 16px;
}

.permission-selector__tabs :deep(.el-tabs__item) {
  height: 40px;
  font-weight: 500;
}

.permission-selector__toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;

  .el-input {
    min-width: 0;
    flex: 1;
  }
}

.permission-selector__content {
  height: min(42vh, 360px);
  padding: 12px;
  overflow: auto;
  border: 1px solid var(--el-border-color-light);
  border-radius: var(--el-border-radius-base);
  overscroll-behavior: contain;

  :deep(.el-tree-node__content) {
    height: auto;
    min-height: 34px;
    padding-top: 6px;
    padding-right: 8px;
    padding-bottom: 6px;
    border-radius: 4px;
  }

  :deep(.el-tree > .el-tree-node + .el-tree-node) {
    margin-top: 8px;
  }

  :deep(.el-tree > .el-tree-node > .el-tree-node__content) {
    background: var(--el-fill-color-light);
    font-weight: 500;
  }

  :deep(.el-tree-node__label) {
    min-width: 0;
    white-space: normal;
    line-height: 22px;
    overflow-wrap: anywhere;
  }

  :deep(.el-checkbox),
  :deep(.el-tree-node__expand-icon) {
    flex-shrink: 0;
  }
}
</style>
