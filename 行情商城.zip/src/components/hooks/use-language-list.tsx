import { computed } from 'vue'
import { useAppStore } from '@/store'

export const useLanguageList = () => {
  const appStore = useAppStore()
  const languageList = computed(
    () => window.APP_CONFIG.LANGUAGE_LIST || appStore.languageList || []
  )
  return languageList
}
