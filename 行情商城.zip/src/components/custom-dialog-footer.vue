<template>
  <div class="custom-dialog-footer">
    <slot></slot>
  </div>
</template>

<style lang="scss" scoped>
.custom-dialog-footer {
  padding-top: var(--dialog-footer-gap, 24px);
  display: flex;
  justify-content: center;
}
</style>
