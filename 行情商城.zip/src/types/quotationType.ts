// 弹窗类型,操作状态
export enum DialogType {
  /**
   * 添加
   */
  Add = 'Add',
  /**
   * 编辑
   */
  Edit = 'Edit',
  /**
   * 详情
   */
  Detail = 'Detail',
  /**
   * 审核
   */
  Auditing = 'Auditing',
}

// 启用状态
export enum EnableStatus {
  /**
   * 启用
   */
  Enable = 'enable',
  /**
   * 禁用
   */
  Disable = 'disable',
  /**
   * 失效
   */
  Failure = 'failure',
}

/** 订单生效状态，对应接口字段 orderEnableStatusOriginal。 */
export enum OrderEnableStatus {
  /** 待扣款 */
  PendingPay = 'PENDING_PAY',
  /** 扣款失败 */
  PayFail = 'PAY_FAIL',
  /** 待生效 */
  Pending = 'PENDING',
  /** 已生效 */
  Effective = 'EFFECTIVE',
  /** 已失效 */
  Failure = 'FAILURE',
  /** 待审核 */
  ReviewIng = 'REVIEW_ING',
  /** 审核驳回 */
  Reject = 'REJECT',
}

// 审核状态
export enum AuditStatus {
  /**
   * 审核驳回
   */
  Reject = 'REJECT',
  /**
   * 待审核
   */
  ReviewIng = 'REVIEW_ING',
  /**
   * 审核通过
   */
  Success = 'SUCCESS',
}
