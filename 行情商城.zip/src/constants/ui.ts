/** Shared dimensions from 前端开发UI规范. Keep in sync across independently deployed apps. */
export const UI_CONFIG = Object.freeze({
  mainPadding: 20,
  controlHeight: 32,
  fontSize: 14,
  gap: 20,
  controlGap: 8,
  sectionGap: 24,
})
