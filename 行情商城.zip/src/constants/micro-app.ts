import { APP_CONFIG } from './config'

export const microAppDict: Record<string, any> = APP_CONFIG.subModuleList ?? {}
