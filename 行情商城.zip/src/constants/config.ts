// 1. 唯一来源：Webpack 编译注入的 process.env.PUBLIC_PATH（区分开发与生产）
export const PUBLIC_PATH = process.env.PUBLIC_PATH || '/'

// 2. 项目默认内置配置
export const DEFAULT_APP_CONFIG = {
  title: '中信国际管理中台',
  login_title_cn: '',
  login_title_hk: '',
  login_title_en: '',
  PUBLIC_PATH,
  COMMON_SERVERS: {
    base: 'http://10.10.11.148:6003'
  },
  LANGUAGE_LIST: [
    ['zh-CN', '简体'],
    ['zh-TW', '繁体'],
    ['en-US', 'English']
  ]
}

// 3. 运行时融合：项目默认配置 + 外部 config.js 的配置（包含 subModuleList）
export const APP_CONFIG = {
  ...DEFAULT_APP_CONFIG,
  ...((window as any)?.APP_CONFIG || {}),
  PUBLIC_PATH,
  COMMON_SERVERS: {
    ...DEFAULT_APP_CONFIG.COMMON_SERVERS,
    ...((window as any)?.APP_CONFIG?.COMMON_SERVERS || {})
  },
  subModuleList: (window as any)?.APP_CONFIG?.subModuleList || {}
}

// 挂载到全局以兼容旧有代码直接访问 window.APP_CONFIG
if (typeof window !== 'undefined') {
  ;(window as any).APP_CONFIG = APP_CONFIG
}
