import { App } from 'vue'
import { createI18n } from 'vue-i18n'
import { LANGUAGE_LOCAL_DICT } from '@/constants/language'
import cn from '@/language/zh-cn.json'
import hk from '@/language/zh-hk.json'
import us from '@/language/en-us.json'

const messages = {
  cn,
  hk,
  us,
}

export const i18n: any = createI18n({
  globalInjection: true,
  legacy: false,
  messages,
})

export default function registerI18n(app: App) {
  i18n.global.locale.value = localStorage.getItem('lang') || LANGUAGE_LOCAL_DICT.CN

  app.use(i18n)
}
